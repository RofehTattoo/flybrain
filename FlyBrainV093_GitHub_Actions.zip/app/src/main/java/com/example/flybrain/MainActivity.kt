package com.example.flybrain

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import java.util.Random

class MainActivity : Activity() {
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 247, 247))
            clipToPadding = true
        }

        root.setOnApplyWindowInsetsListener { view, insets ->
            val bars = if (Build.VERSION.SDK_INT >= 30) {
                insets.getInsets(android.view.WindowInsets.Type.systemBars())
            } else null
            val top = bars?.top ?: insets.systemWindowInsetTop
            val bottom = bars?.bottom ?: insets.systemWindowInsetBottom
            view.setPadding(0, top, 0, bottom)
            insets
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6.dp(), 5.dp(), 6.dp(), 5.dp())
            setBackgroundColor(Color.rgb(226, 226, 226))
        }

        fun makeButton(label: String) = Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            minHeight = 0
            minWidth = 0
            setPadding(1.dp(), 0, 1.dp(), 0)
        }

        val food = makeButton("COMIDA")
        val light = makeButton("LUZ")
        val danger = makeButton("PELIGRO")
        val reset = makeButton("↻ RESET")
        val bh = 60.dp()
        listOf(food, light, danger, reset).forEach { button ->
            controls.addView(
                button,
                LinearLayout.LayoutParams(0, bh, 1f).apply {
                    setMargins(2.dp(), 0, 2.dp(), 0)
                }
            )
        }
        root.addView(controls, LinearLayout.LayoutParams(-1, 70.dp()))

        val info = TextView(this).apply {
            setPadding(14.dp(), 7.dp(), 14.dp(), 7.dp())
            setTextColor(Color.rgb(28, 28, 28))
            textSize = 12f
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                setStroke(2.dp(), Color.rgb(145, 145, 145))
                cornerRadius = 8.dp().toFloat()
            }
        }
        root.addView(
            info,
            LinearLayout.LayoutParams(-1, 132.dp()).apply {
                setMargins(8.dp(), 5.dp(), 8.dp(), 5.dp())
            }
        )

        val sim = FlyView(info)
        root.addView(sim, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refresh() {
            info.text = sim.infoText()
            sim.updateButtons()
        }

        food.setOnClickListener { sim.selectAndToggle(0); refresh() }
        light.setOnClickListener { sim.selectAndToggle(1); refresh() }
        danger.setOnClickListener { sim.selectAndToggle(2); refresh() }
        reset.setOnClickListener { sim.resetSimulation(); refresh() }

        sim.foodButton = food
        sim.lightButton = light
        sim.dangerButton = danger
        sim.resetButton = reset

        setContentView(root)
        root.requestApplyInsets()
        refresh()
    }

    inner class FlyView(private val info: TextView) : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rng = Random(9301)

        // V0.93 keeps exactly 16,669 simulated neurons (10% of the published
        // 166,691-neuron MaleCNS census). It is a structured computational
        // reduction, not a literal random 10% extraction of the biological graph.
        private val N = 16669

        // Functional populations preserved from the MaleCNS organization.
        private val VIS_START = 0
        private val VIS_END = 609
        private val OLF_START = 609
        private val OLF_END = 873
        private val GUST_START = 873
        private val GUST_END = 1016
        private val MECH_START = 1016
        private val SENSOR_END = 1600

        private val KENYON_START = 1600
        private val KENYON_END = 2006
        private val ALPN_START = 2006
        private val ALPN_END = 2075
        private val CX_START = 2075
        private val CX_END = 2370
        private val DESC_START = 2370
        private val DESC_END = 2502
        private val MOTOR_START = 2502
        private val MOTOR_END = 2584
        private val INTEGRATION_START = 2584
        private val INTEGRATION_END = N

        // Structured premotor state populations inside the integration pool.
        private val NAV_LEFT_START = INTEGRATION_START
        private val NAV_LEFT_END = INTEGRATION_START + 192
        private val NAV_RIGHT_START = NAV_LEFT_END
        private val NAV_RIGHT_END = NAV_RIGHT_START + 192
        private val NAV_FORWARD_START = NAV_RIGHT_END
        private val NAV_FORWARD_END = NAV_FORWARD_START + 192
        private val ESCAPE_STATE_START = NAV_FORWARD_END
        private val ESCAPE_STATE_END = ESCAPE_STATE_START + 160
        private val APPROACH_STATE_START = ESCAPE_STATE_END
        private val APPROACH_STATE_END = APPROACH_STATE_START + 160
        private val EXPLORE_STATE_START = APPROACH_STATE_END
        private val EXPLORE_STATE_END = EXPLORE_STATE_START + 160
        private val MEMORY_START = EXPLORE_STATE_END
        private val MEMORY_END = MEMORY_START + 256

        private val v = FloatArray(N) { -0.72f }
        private val adapt = FloatArray(N)
        private val fired = BooleanArray(N)
        private val prevFired = BooleanArray(N)
        private val refractory = FloatArray(N)

        private val incoming = Array(N) { IntArray(0) }
        private val incomingW = Array(N) { FloatArray(0) }
        private val baseW = Array(N) { FloatArray(0) }
        private val eligibility = Array(N) { FloatArray(0) }

        var foodOn = true
        var lightOn = false
        var dangerOn = false
        var selectedStimulus = 0
        var foodButton: Button? = null
        var lightButton: Button? = null
        var dangerButton: Button? = null
        var resetButton: Button? = null

        private var flyX = .24f
        private var flyY = .55f
        private var heading = -.15f
        private var flySpeed = .0035f

        private var foodX = .76f
        private var foodY = .35f
        private var lightX = .72f
        private var lightY = .72f
        private var dangerX = .30f
        private var dangerY = .30f

        private var simTime = 0f
        private var neuralAccumulator = 0f
        private var lastNs = System.nanoTime()
        private var fps = 60f
        private var foodHits = 0
        private var escapeEvents = 0
        private var satiety = 0f
        private var memoryTrace = 0f
        private var lastReward = 0f
        private var lastDangerLevel = 0f
        private var stableLocomotion = 0f

        private var sensoryDisplay = 0f
        private var centralDisplay = 0f
        private var motorDisplay = 0f
        private var foodSignalDisplay = 0f
        private var lightSignalDisplay = 0f
        private var dangerSignalDisplay = 0f

        private var leftMotor = 0f
        private var rightMotor = 0f
        private var forwardMotor = 0f
        private var escapeMotor = 0f
        private var brakeMotor = 0f
        private var exploreMotor = 0f

        private var foodDrive = 0f
        private var lightDrive = 0f
        private var dangerDrive = 0f

        init {
            setBackgroundColor(Color.rgb(250, 250, 250))
            buildBrain()
        }

        fun infoText() = buildString {
            append("FLYBRAIN V0.93\n")
            append("16.669 neuronas · MaleCNS reducido · LIF adaptativo + plasticidad\n")
            append("Sensores: visual · olfativo · gustativo · mecano/proprio · VNC\n")
            append("Comida ${if (foodOn) "ON" else "OFF"} · Luz ${if (lightOn) "ON" else "OFF"} · Peligro ${if (dangerOn) "ON" else "OFF"}\n")
            append("Comidas $foodHits · Escapes $escapeEvents · Saciedad ${(satiety * 100).toInt()}% · Memoria ${(memoryTrace * 100).toInt()}% · FPS ${fps.toInt()}\n")
            append("Conducta: ${behaviorLabel()} · Locomoción ${(stableLocomotion * 100).toInt()}%")
        }

        private fun behaviorLabel(): String = when {
            escapeMotor > .16f -> "ESCAPE"
            brakeMotor > .18f -> "FRENO"
            forwardMotor > .18f && foodDrive > .20f -> "APROXIMACIÓN A COMIDA"
            rightMotor > leftMotor + .08f -> "GIRO DERECHA"
            leftMotor > rightMotor + .08f -> "GIRO IZQUIERDA"
            forwardMotor > .16f -> "AVANCE"
            exploreMotor > .14f -> "EXPLORACIÓN"
            else -> "ORIENTACIÓN / EXPLORACIÓN"
        }

        fun selectAndToggle(s: Int) {
            if (selectedStimulus == s) {
                when (s) {
                    0 -> foodOn = !foodOn
                    1 -> lightOn = !lightOn
                    else -> dangerOn = !dangerOn
                }
            } else {
                selectedStimulus = s
                when (s) {
                    0 -> foodOn = true
                    1 -> lightOn = true
                    else -> dangerOn = true
                }
            }
            invalidate()
        }

        private fun styleButton(button: Button, active: Boolean, selected: Boolean, accent: Int) {
            button.background = GradientDrawable().apply {
                cornerRadius = 12.dp().toFloat()
                setColor(if (active) Color.rgb(232, 246, 235) else Color.rgb(245, 245, 245))
                setStroke(if (selected) 4 else 1, if (selected) accent else Color.rgb(155, 155, 155))
            }
            button.alpha = if (active) 1f else .68f
        }

        fun updateButtons() {
            foodButton?.let {
                it.text = if (foodOn) "COMIDA  ON" else "COMIDA"
                styleButton(it, foodOn, selectedStimulus == 0, Color.rgb(35, 120, 70))
            }
            lightButton?.let {
                it.text = if (lightOn) "LUZ  ON" else "LUZ"
                styleButton(it, lightOn, selectedStimulus == 1, Color.rgb(210, 145, 10))
            }
            dangerButton?.let {
                it.text = if (dangerOn) "PELIGRO  ON" else "PELIGRO"
                styleButton(it, dangerOn, selectedStimulus == 2, Color.rgb(190, 45, 45))
            }
        }

        fun resetSimulation() {
            for (i in 0 until N) {
                v[i] = -0.72f
                adapt[i] = 0f
                fired[i] = false
                prevFired[i] = false
                refractory[i] = 0f
                for (k in incomingW[i].indices) {
                    incomingW[i][k] = baseW[i][k]
                    eligibility[i][k] = 0f
                }
            }
            flyX = .24f
            flyY = .55f
            heading = -.15f
            flySpeed = .0035f
            foodX = .76f
            foodY = .35f
            lightX = .72f
            lightY = .72f
            dangerX = .30f
            dangerY = .30f
            simTime = 0f
            neuralAccumulator = 0f
            foodHits = 0
            escapeEvents = 0
            satiety = 0f
            memoryTrace = 0f
            lastReward = 0f
            lastDangerLevel = 0f
            stableLocomotion = 0f
            sensoryDisplay = 0f
            centralDisplay = 0f
            motorDisplay = 0f
            foodSignalDisplay = 0f
            lightSignalDisplay = 0f
            dangerSignalDisplay = 0f
            leftMotor = 0f
            rightMotor = 0f
            forwardMotor = 0f
            escapeMotor = 0f
            brakeMotor = 0f
            exploreMotor = 0f
            foodDrive = 0f
            lightDrive = 0f
            dangerDrive = 0f
            lastNs = System.nanoTime()
            info.text = infoText()
            invalidate()
        }

        private fun addEdge(target: Int, source: Int, weight: Float, l: Array<MutableList<Int>>, ws: Array<MutableList<Float>>) {
            l[target].add(source)
            ws[target].add(weight)
        }

        private fun connectRange(
            targetStart: Int,
            targetEnd: Int,
            sourceStart: Int,
            sourceEnd: Int,
            fanIn: Int,
            base: Float,
            l: Array<MutableList<Int>>,
            ws: Array<MutableList<Float>>,
            salt: Int
        ) {
            val sourceSize = sourceEnd - sourceStart
            for (target in targetStart until targetEnd) {
                repeat(fanIn) { k ->
                    val source = sourceStart + ((target * 37 + k * 101 + salt * 17) % sourceSize)
                    val sign = if (((target + k + salt) and 7) == 0) -1f else 1f
                    val w = sign * (base + ((target + k * 3 + salt) % 5) * base * .12f)
                    addEdge(target, source, w, l, ws)
                }
            }
        }

        private fun buildBrain() {
            val l = Array(N) { mutableListOf<Int>() }
            val ws = Array(N) { mutableListOf<Float>() }

            // Sensory streams -> integration: directional channels are preserved
            // so the same stimulus can drive left/right/front state populations.
            connectRange(INTEGRATION_START, INTEGRATION_START + 360, VIS_START, VIS_END, 8, .028f, l, ws, 1)
            connectRange(INTEGRATION_START + 360, INTEGRATION_START + 520, OLF_START, OLF_END, 8, .030f, l, ws, 2)
            connectRange(INTEGRATION_START + 520, INTEGRATION_START + 680, GUST_START, GUST_END, 7, .030f, l, ws, 3)
            connectRange(INTEGRATION_START + 680, INTEGRATION_START + 840, MECH_START, SENSOR_END, 7, .032f, l, ws, 4)

            // Higher-order centres: mushroom-body-like, antennal-lobe-like and
            // central-complex-like populations.
            connectRange(KENYON_START, KENYON_END, OLF_START, OLF_END, 12, .018f, l, ws, 11)
            connectRange(ALPN_START, ALPN_END, OLF_START, OLF_END, 14, .030f, l, ws, 12)
            connectRange(CX_START, CX_END, VIS_START, VIS_END, 12, .018f, l, ws, 13)
            connectRange(CX_START, CX_END, MECH_START, SENSOR_END, 8, .016f, l, ws, 14)
            connectRange(CX_START, CX_END, KENYON_START, KENYON_END, 8, .014f, l, ws, 15)
            connectRange(CX_START, CX_END, ALPN_START, ALPN_END, 5, .020f, l, ws, 16)

            // Structured navigation/action state pools.
            connectRange(NAV_LEFT_START, NAV_LEFT_END, VIS_START, VIS_END, 10, .020f, l, ws, 21)
            connectRange(NAV_RIGHT_START, NAV_RIGHT_END, VIS_START, VIS_END, 10, .020f, l, ws, 22)
            connectRange(NAV_FORWARD_START, NAV_FORWARD_END, VIS_START, VIS_END, 10, .020f, l, ws, 23)

            // Directional visual columns: left/right/front channels are biased
            // toward their corresponding premotor pools, but the signal still
            // passes through the neural populations before reaching the VNC.
            for (target in NAV_LEFT_START until NAV_LEFT_END) {
                repeat(10) { k ->
                    val source = VIS_START + (((target * 7 + k * 19) % ((VIS_END - VIS_START) / 8)) * 8)
                    addEdge(target, source, .032f, l, ws)
                }
            }
            for (target in NAV_RIGHT_START until NAV_RIGHT_END) {
                repeat(10) { k ->
                    val source = VIS_START + ((((target * 11 + k * 23) % ((VIS_END - VIS_START) / 8)) * 8) + 1)
                    addEdge(target, source, .032f, l, ws)
                }
            }
            for (target in NAV_FORWARD_START until NAV_FORWARD_END) {
                repeat(10) { k ->
                    val source = VIS_START + ((((target * 13 + k * 29) % ((VIS_END - VIS_START) / 8)) * 8) + 2)
                    addEdge(target, source, .034f, l, ws)
                }
            }
            // Bilateral olfactory localisation: food odour is represented on
            // left/right antennal channels before reaching action selection.
            for (target in NAV_LEFT_START until NAV_LEFT_END) {
                repeat(8) { k ->
                    val source = OLF_START + (((target * 7 + k * 17) % ((OLF_END - OLF_START) / 8)) * 8)
                    addEdge(target, source, .026f, l, ws)
                }
            }
            for (target in NAV_RIGHT_START until NAV_RIGHT_END) {
                repeat(8) { k ->
                    val source = OLF_START + ((((target * 11 + k * 23) % ((OLF_END - OLF_START) / 8)) * 8) + 1)
                    addEdge(target, source, .026f, l, ws)
                }
            }
            for (target in NAV_FORWARD_START until NAV_FORWARD_END) {
                repeat(8) { k ->
                    val source = OLF_START + ((((target * 13 + k * 29) % ((OLF_END - OLF_START) / 8)) * 8) + 2)
                    addEdge(target, source, .028f, l, ws)
                }
            }
            connectRange(ESCAPE_STATE_START, ESCAPE_STATE_END, MECH_START, SENSOR_END, 12, .045f, l, ws, 24)
            connectRange(APPROACH_STATE_START, APPROACH_STATE_END, OLF_START, OLF_END, 12, .024f, l, ws, 25)
            connectRange(EXPLORE_STATE_START, EXPLORE_STATE_END, CX_START, CX_END, 10, .018f, l, ws, 26)

            // Higher-order centres feed action-state pools. These are network
            // pathways, not direct stimulus->motor commands.
            connectRange(NAV_LEFT_START, NAV_LEFT_END, CX_START, CX_END, 12, .017f, l, ws, 31)
            connectRange(NAV_RIGHT_START, NAV_RIGHT_END, CX_START, CX_END, 12, .017f, l, ws, 32)
            connectRange(NAV_FORWARD_START, NAV_FORWARD_END, CX_START, CX_END, 12, .018f, l, ws, 33)
            connectRange(ESCAPE_STATE_START, ESCAPE_STATE_END, CX_START, CX_END, 10, .018f, l, ws, 34)
            connectRange(APPROACH_STATE_START, APPROACH_STATE_END, KENYON_START, KENYON_END, 10, .017f, l, ws, 35)
            connectRange(EXPLORE_STATE_START, EXPLORE_STATE_END, CX_START, CX_END, 12, .014f, l, ws, 36)

            // Memory/learning population receives olfactory and higher-centre input.
            connectRange(MEMORY_START, MEMORY_END, OLF_START, OLF_END, 10, .014f, l, ws, 41)
            connectRange(MEMORY_START, MEMORY_END, KENYON_START, KENYON_END, 8, .014f, l, ws, 42)
            connectRange(MEMORY_START, MEMORY_END, CX_START, CX_END, 6, .010f, l, ws, 43)

            // Dense but sparse-in-degree recurrent integration network.
            for (i in INTEGRATION_START until N) {
                repeat(8) { k ->
                    var source = INTEGRATION_START + ((i * 1103515245 + k * 12345 + 9301) ushr 4) % (N - INTEGRATION_START)
                    if (source == i) source = INTEGRATION_START + ((source - INTEGRATION_START + 17) % (N - INTEGRATION_START))
                    val inhibitory = ((i + k * 7) % 13 == 0)
                    val weight = .0065f + ((i * 31 + k * 17) % 7) * .0015f
                    addEdge(i, source, if (inhibitory) -weight else weight, l, ws)
                }
            }

            // Action selection is organised into six descending channels. Each
            // channel is strongly driven by its matching state population and
            // weakly inhibited by the alternatives, creating a genuine action
            // selection stage before the VNC motor neurons.
            val actionPools = arrayOf(
                NAV_LEFT_START until NAV_LEFT_END,
                NAV_RIGHT_START until NAV_RIGHT_END,
                NAV_FORWARD_START until NAV_FORWARD_END,
                ESCAPE_STATE_START until ESCAPE_STATE_END,
                APPROACH_STATE_START until APPROACH_STATE_END,
                EXPLORE_STATE_START until EXPLORE_STATE_END
            )
            val descendingGroupSize = (DESC_END - DESC_START) / actionPools.size
            for (group in actionPools.indices) {
                val descA = DESC_START + group * descendingGroupSize
                val descB = if (group == actionPools.lastIndex) DESC_END else descA + descendingGroupSize
                val ownPool = actionPools[group]
                for (target in descA until descB) {
                    repeat(12) { k ->
                        val source = ownPool.first + ((target * 19 + k * 29 + group * 47) % (ownPool.last - ownPool.first + 1))
                        val base = when (group) {
                            2 -> .060f
                            3 -> .085f
                            4 -> .050f
                            5 -> .046f
                            else -> .052f
                        }
                        addEdge(target, source, base, l, ws)
                    }
                    for (other in actionPools.indices) {
                        if (other == group) continue
                        val pool = actionPools[other]
                        repeat(2) { k ->
                            val source = pool.first + ((target * 13 + k * 17 + other * 31) % (pool.last - pool.first + 1))
                            addEdge(target, source, -.010f, l, ws)
                        }
                    }
                }
            }

            // Descending neurons -> VNC motor neurons. Matching channels are
            // excitatory; non-matching channels are weakly inhibitory.
            val motorPools = arrayOf(
                MOTOR_START until MOTOR_START + 14,
                MOTOR_START + 14 until MOTOR_START + 28,
                MOTOR_START + 28 until MOTOR_START + 42,
                MOTOR_START + 42 until MOTOR_START + 56,
                MOTOR_START + 56 until MOTOR_START + 69,
                MOTOR_START + 69 until MOTOR_END
            )
            for ((poolIndex, pool) in motorPools.withIndex()) {
                val descA = DESC_START + poolIndex * descendingGroupSize
                val descB = if (poolIndex == motorPools.lastIndex) DESC_END else descA + descendingGroupSize
                for (target in pool) {
                    for (source in descA until descB step 2) {
                        val base = when (poolIndex) {
                            2 -> .055f
                            3 -> .078f
                            4 -> .045f
                            5 -> .042f
                            else -> .050f
                        }
                        addEdge(target, source, base, l, ws)
                    }
                    for (other in 0 until actionPools.size) {
                        if (other == poolIndex) continue
                        val oa = DESC_START + other * descendingGroupSize
                        val ob = if (other == actionPools.lastIndex) DESC_END else oa + descendingGroupSize
                        for (source in oa until ob step 7) {
                            addEdge(target, source, -.002f, l, ws)
                        }
                    }
                }
            }

            // Lateral inhibition between action pools creates competition rather
            // than allowing every motor output to remain simultaneously active.
            for (target in MOTOR_START until MOTOR_END) {
                val pool = when {
                    target < MOTOR_START + 14 -> 0
                    target < MOTOR_START + 28 -> 1
                    target < MOTOR_START + 42 -> 2
                    target < MOTOR_START + 56 -> 3
                    target < MOTOR_START + 69 -> 4
                    else -> 5
                }
                for (source in MOTOR_START until MOTOR_END step 5) {
                    val sourcePool = when {
                        source < MOTOR_START + 14 -> 0
                        source < MOTOR_START + 28 -> 1
                        source < MOTOR_START + 42 -> 2
                        source < MOTOR_START + 56 -> 3
                        source < MOTOR_START + 69 -> 4
                        else -> 5
                    }
                    if (sourcePool != pool) addEdge(target, source, -.002f, l, ws)
                }
            }

            for (i in 0 until N) {
                incoming[i] = l[i].toIntArray()
                incomingW[i] = ws[i].toFloatArray()
                baseW[i] = incomingW[i].clone()
                eligibility[i] = FloatArray(incomingW[i].size)
            }
        }

        private fun gaussian(d: Float, radius: Float): Float {
            return exp((-(d * d) / (2f * radius * radius)).toDouble()).toFloat().coerceIn(0f, 1f)
        }

        private fun directional(dx: Float, dy: Float, angle: Float, side: Int): Float {
            val a = atan2(dy, dx)
            val e = atan2(sin(a - angle), cos(a - angle))
            return when (side) {
                -1 -> (-e / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                1 -> (e / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                else -> 1f - (abs(e) / Math.PI.toFloat()).coerceIn(0f, 1f)
            }
        }

        private fun writePopulation(start: Int, values: FloatArray) {
            for (i in values.indices) {
                val idx = start + i
                if (idx < SENSOR_END) v[idx] += values[i]
            }
        }

        private fun encodeStimulus(enabled: Boolean, sx: Float, sy: Float, gain: Float): FloatArray {
            if (!enabled) return FloatArray(8)
            val dx = sx - flyX
            val dy = sy - flyY
            val d = hypot(dx, dy)
            val prox = gaussian(d, .42f)
            val left = directional(dx, dy, heading, -1)
            val right = directional(dx, dy, heading, 1)
            val front = directional(dx, dy, heading, 0)
            return floatArrayOf(
                left * gain,
                right * gain,
                front * gain,
                prox * gain,
                left * prox * gain,
                right * prox * gain,
                front * prox * gain,
                (1f - prox) * gain * .18f
            )
        }

        private fun injectSensoryPopulation(start: Int, end: Int, pattern: FloatArray, gain: Float) {
            val size = end - start
            for (i in 0 until size) {
                val channel = i % pattern.size
                val spatial = .55f + .45f * sin((i * 0.071f) + channel).let { (it + 1f) * .5f }
                v[start + i] += pattern[channel] * gain * spatial
            }
        }

        private fun sense(dt: Float) {
            val foodPattern = encodeStimulus(foodOn, foodX, foodY, 1.25f * (1f - satiety * .55f))
            val lightPattern = encodeStimulus(lightOn, lightX, lightY, 1.00f)
            val dangerPattern = encodeStimulus(dangerOn, dangerX, dangerY, 1.75f)

            injectSensoryPopulation(VIS_START, VIS_END, lightPattern, 0.42f)
            injectSensoryPopulation(OLF_START, OLF_END, foodPattern, 0.50f)
            injectSensoryPopulation(GUST_START, GUST_END, foodPattern, 0.32f)
            injectSensoryPopulation(MECH_START, SENSOR_END, dangerPattern, 0.38f)

            // Mechanosensory/proprioceptive feedback from locomotion and boundaries.
            val wall = min(min(flyX - .06f, .94f - flyX), min(flyY - .10f, .79f - flyY)).coerceIn(0f, .4f)
            val wallSignal = (1f - wall / .4f).coerceIn(0f, 1f)
            for (i in MECH_START until SENSOR_END) {
                v[i] += wallSignal * .08f
            }

            foodDrive = foodPattern[3].coerceIn(0f, 1f)
            lightDrive = lightPattern[3].coerceIn(0f, 1f)
            dangerDrive = dangerPattern[3].coerceIn(0f, 1f)

            foodSignalDisplay = .90f * foodSignalDisplay + .10f * foodDrive
            lightSignalDisplay = .90f * lightSignalDisplay + .10f * lightDrive
            dangerSignalDisplay = .90f * dangerSignalDisplay + .10f * dangerDrive

            visualDisplayUpdate(foodDrive, lightDrive, dangerDrive)

            for (i in 0 until SENSOR_END) {
                v[i] -= adapt[i]
                adapt[i] *= exp((-dt * 2.0f).toDouble()).toFloat()
            }
        }

        private fun visualDisplayUpdate(food: Float, light: Float, danger: Float) {
            sensoryDisplay = .90f * sensoryDisplay + .10f * ((food + light + danger) / 3f)
        }

        private fun stepBrain(dt: Float) {
            for (i in 0 until N) prevFired[i] = fired[i]

            for (i in 0 until N) {
                if (refractory[i] > 0f) {
                    refractory[i] -= dt
                    fired[i] = false
                    continue
                }

                var syn = 0f
                val src = incoming[i]
                val w = incomingW[i]
                for (k in src.indices) {
                    if (prevFired[src[k]]) syn += w[k]
                }

                // Low tonic arousal prevents a dead network, while remaining
                // inside the neural pathway rather than directly moving the fly.
                val tonic = when {
                    i in EXPLORE_STATE_START until EXPLORE_STATE_END -> .060f
                    i in NAV_FORWARD_START until NAV_FORWARD_END -> .008f
                    i in DESC_START until DESC_END -> .008f
                    else -> 0f
                }

                v[i] += ((-.72f - v[i]) * 6.2f - adapt[i]) * dt + syn * .95f + tonic * dt * 12f
                fired[i] = v[i] >= -.45f

                if (fired[i]) {
                    v[i] = -.84f
                    adapt[i] = min(.18f, adapt[i] + .026f)
                    refractory[i] = .005f
                }
            }
        }

        private fun count(a: Int, b: Int): Int {
            var n = 0
            for (i in a until b) if (fired[i]) n++
            return n
        }

        private fun populationRate(a: Int, b: Int): Float {
            return count(a, b).toFloat() / (b - a).toFloat()
        }

        private fun learn(reward: Float, dt: Float) {
            val r = reward.coerceIn(-1f, 1f)
            memoryTrace = (memoryTrace * exp((-dt * .035f).toDouble()).toFloat() + abs(r) * .03f).coerceIn(0f, 1f)

            for (target in MOTOR_START until MOTOR_END) {
                val sources = incoming[target]
                val weights = incomingW[target]
                val base = baseW[target]
                val e = eligibility[target]
                for (k in sources.indices) {
                    val pre = if (prevFired[sources[k]]) 1f else 0f
                    val post = if (fired[target]) 1f else 0f
                    e[k] = (e[k] * .995f + pre * post * .08f).coerceIn(-1f, 1f)
                    weights[k] += r * e[k] * dt * .18f
                    val lo = min(base[k] * .55f, base[k] * 1.45f)
                    val hi = max(base[k] * .55f, base[k] * 1.45f)
                    weights[k] = weights[k].coerceIn(lo, hi)
                }
            }
            lastReward = .94f * lastReward + .06f * r
        }

        private fun driveBody(dt: Float) {
            val left = populationRate(MOTOR_START, MOTOR_START + 14)
            val right = populationRate(MOTOR_START + 14, MOTOR_START + 28)
            val forward = populationRate(MOTOR_START + 28, MOTOR_START + 42)
            val escape = populationRate(MOTOR_START + 42, MOTOR_START + 56)
            val brake = populationRate(MOTOR_START + 56, MOTOR_START + 69)
            val explore = populationRate(MOTOR_START + 69, MOTOR_END)

            // Motor commands come only from the VNC motor populations.
            // Stimuli influence these populations through the sensory -> higher
            // centre -> descending -> motor pathway constructed above.
            val turn = (right - left) * 1.8f
            val locomotion = forward * .0028f + explore * .0014f
            val avoidance = escape * .0038f + brake * .0022f
            val cmdSpeed = (locomotion - avoidance).coerceIn(-.009f, .014f)

            heading += turn * dt * 3.0f
            flySpeed = .90f * flySpeed + .10f * cmdSpeed
            flyX += cos(heading) * flySpeed * dt * 30f
            flyY += sin(heading) * flySpeed * dt * 30f

            if (flyX < .055f || flyX > .945f) {
                heading = Math.PI.toFloat() - heading
                flyX = flyX.coerceIn(.055f, .945f)
            }
            if (flyY < .10f || flyY > .79f) {
                heading = -heading
                flyY = flyY.coerceIn(.10f, .79f)
            }

            var reward = 0f
            val foodDistance = hypot(foodX - flyX, foodY - flyY)
            if (foodOn && foodDistance < .065f) {
                foodHits++
                satiety = min(1f, satiety + .28f)
                reward += 1f
                foodX = .08f + rng.nextFloat() * .84f
                foodY = .14f + rng.nextFloat() * .58f
            }

            satiety *= exp((-dt * .018f).toDouble()).toFloat()

            val danger = if (dangerOn) gaussian(hypot(dangerX - flyX, dangerY - flyY), .36f) else 0f
            if (danger > .68f && lastDangerLevel <= .68f) escapeEvents++
            if (dangerOn && danger < .20f && lastDangerLevel > .68f) reward += .5f
            lastDangerLevel = danger

            learn(reward, dt)

            centralDisplay = .88f * centralDisplay + .12f * (
                (populationRate(CX_START, CX_END) +
                    populationRate(KENYON_START, KENYON_END) +
                    populationRate(ALPN_START, ALPN_END)) / 3f
            )
            motorDisplay = .88f * motorDisplay + .12f * (
                (left + right + forward + escape + brake + explore) / 6f
            )

            leftMotor = .82f * leftMotor + .18f * left
            rightMotor = .82f * rightMotor + .18f * right
            forwardMotor = .82f * forwardMotor + .18f * forward
            escapeMotor = .82f * escapeMotor + .18f * escape
            brakeMotor = .82f * brakeMotor + .18f * brake
            exploreMotor = .82f * exploreMotor + .18f * explore

            stableLocomotion = (.90f * stableLocomotion + .10f * min(1f, abs(flySpeed) / .006f)).coerceIn(0f, 1f)
            info.text = infoText()
        }

        private fun runNeuralSimulation(dt: Float) {
            sense(dt)
            stepBrain(dt)
            driveBody(dt)
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val now = System.nanoTime()
            val raw = (now - lastNs) / 1e9
            val frameDt = min(.030, max(.004, raw)).toFloat()
            lastNs = now
            fps = fps * .94f + (1f / frameDt) * .06f
            simTime += frameDt

            // Neural clock at 50 Hz, independent of display refresh rate.
            neuralAccumulator += frameDt
            var steps = 0
            while (neuralAccumulator >= .020f && steps < 2) {
                runNeuralSimulation(.020f)
                neuralAccumulator -= .020f
                steps++
            }

            drawScene(c)
            drawFly(c, flyX * width, flyY * sceneBottom(), heading)
            drawBrainPanel(c)
            postInvalidateOnAnimation()
        }

        private fun sceneBottom(): Float = height - brainPanelHeight()

        private fun brainPanelHeight(): Float = min(height * .42f, 500.dp().toFloat())

        private fun drawScene(c: Canvas) {
            val bottom = sceneBottom()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = Color.rgb(190, 190, 190)
            c.drawRect(8f, 8f, width - 8f, bottom - 6f, paint)
            paint.style = Paint.Style.FILL

            if (foodOn) {
                val x = foodX * width
                val y = foodY * bottom
                paint.color = Color.rgb(32, 155, 70)
                c.drawCircle(x, y, 22f, paint)
                paint.color = Color.WHITE
                paint.textSize = 16f
                paint.textAlign = Paint.Align.CENTER
                paint.typeface = Typeface.DEFAULT_BOLD
                c.drawText("F", x, y + 6f, paint)
            }

            if (lightOn) {
                val x = lightX * width
                val y = lightY * bottom
                paint.color = Color.rgb(230, 165, 15)
                c.drawCircle(x, y, 38f, paint)
                paint.color = Color.rgb(255, 222, 75)
                c.drawCircle(x, y, 21f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f
                paint.color = Color.argb(130, 235, 180, 20)
                c.drawCircle(x, y, 54f, paint)
                paint.style = Paint.Style.FILL
            }

            if (dangerOn) {
                val x = dangerX * width
                val y = dangerY * bottom
                paint.color = Color.rgb(205, 42, 42)
                c.drawCircle(x, y, 34f, paint)
                paint.color = Color.WHITE
                paint.textSize = 33f
                paint.textAlign = Paint.Align.CENTER
                paint.typeface = Typeface.DEFAULT_BOLD
                c.drawText("!", x, y + 11f, paint)
            }
        }

        private fun drawBrainPanel(c: Canvas) {
            val ph = brainPanelHeight()
            val top = height - ph
            paint.color = Color.rgb(20, 25, 28)
            paint.style = Paint.Style.FILL
            c.drawRoundRect(8f, top, width - 8f, height.toFloat(), 12f, 12f, paint)
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = Color.WHITE
            paint.textSize = 16f
            c.drawText("CEREBRO · MaleCNS REDUCIDO · ACTIVIDAD", 20f, top + 23f, paint)
            bar(c, "SENSORIAL", sensoryDisplay, top + 30f, Color.rgb(52, 195, 110))
            bar(c, "CENTRAL", centralDisplay, top + 55f, Color.rgb(80, 145, 225))
            bar(c, "MOTOR / VNC", motorDisplay, top + 80f, Color.rgb(225, 160, 45))
            paint.color = Color.rgb(215, 220, 222)
            paint.textSize = 9f
            paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("ESTÍMULOS", 20f, top + 106f, paint)
            mini(c, "COMIDA", foodSignalDisplay, 20f, top + 111f, 0)
            mini(c, "LUZ", lightSignalDisplay, 160f, top + 111f, 1)
            mini(c, "PELIGRO", dangerSignalDisplay, 300f, top + 111f, 2)

            val mapTop = top + 142f
            val mapBottom = height - 24f
            drawBrainMap(c, 14f, mapTop, width - 28f, max(110f, mapBottom - mapTop))
            paint.color = Color.rgb(205, 210, 212)
            paint.textSize = 8f
            paint.typeface = Typeface.DEFAULT
            c.drawText("10% MaleCNS · 16.669 neuronas · nodos visuales agregados por región", 20f, height - 7f, paint)
        }

        private fun bar(c: Canvas, label: String, value: Float, y: Float, accent: Int) {
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = Color.WHITE
            paint.textSize = 10f
            c.drawText(label, 20f, y + 14f, paint)
            val left = 116f
            val right = width - 55f
            paint.color = Color.rgb(62, 67, 70)
            c.drawRoundRect(left, y, right, y + 18f, 7f, 7f, paint)
            paint.color = accent
            c.drawRoundRect(left, y, left + (right - left) * value.coerceIn(0f, 1f), y + 18f, 7f, 7f, paint)
            paint.color = Color.WHITE
            paint.textSize = 10f
            c.drawText("${(value * 100).toInt()}%", right + 5f, y + 14f, paint)
        }

        private fun mini(c: Canvas, label: String, value: Float, x: Float, y: Float, kind: Int) {
            val w = (width - 52f) / 3f
            paint.color = Color.rgb(53, 58, 61)
            c.drawRoundRect(x, y, x + w, y + 21f, 6f, 6f, paint)
            paint.color = when (kind) {
                0 -> Color.rgb(52, 175, 85)
                1 -> Color.rgb(238, 178, 25)
                else -> Color.rgb(215, 55, 55)
            }
            c.drawRoundRect(x + 2f, y + 2f, x + 2f + (w - 4f) * value.coerceIn(0f, 1f), y + 19f, 5f, 5f, paint)
            paint.color = Color.WHITE
            paint.textSize = 9f
            paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("$label ${(value * 100).toInt()}%", x + 7f, y + 14f, paint)
        }

        private fun drawBrainMap(c: Canvas, x: Float, y: Float, w: Float, h: Float) {
            paint.color = Color.rgb(28, 33, 37)
            paint.style = Paint.Style.FILL
            c.drawRoundRect(x, y, x + w, y + h, 14f, 14f, paint)

            val cx = x + w * .5f
            val cy = y + h * .52f
            val left = x + w * .22f
            val right = x + w * .78f

            paint.color = Color.rgb(55, 62, 68)
            c.drawOval(left - w * .15f, cy - h * .30f, left + w * .08f, cy + h * .30f, paint)
            c.drawOval(right - w * .08f, cy - h * .30f, right + w * .15f, cy + h * .30f, paint)
            paint.color = Color.rgb(67, 73, 79)
            c.drawOval(cx - w * .23f, cy - h * .27f, cx + w * .23f, cy + h * .27f, paint)

            val hubs = arrayOf(
                floatArrayOf(left, cy),
                floatArrayOf(right, cy),
                floatArrayOf(cx - w * .13f, cy - h * .10f),
                floatArrayOf(cx + w * .13f, cy - h * .10f),
                floatArrayOf(cx, cy + h * .04f),
                floatArrayOf(cx, cy + h * .22f),
                floatArrayOf(cx, cy + h * .36f)
            )

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            paint.color = Color.argb(75, 160, 170, 178)
            for (i in hubs.indices) {
                for (j in i + 1 until hubs.size) {
                    if ((i * 3 + j) % 3 != 0) {
                        c.drawLine(hubs[i][0], hubs[i][1], hubs[j][0], hubs[j][1], paint)
                    }
                }
            }

            // 300 visible representative nodes: the simulation contains 16,669
            // neurons, but drawing every node would make the activity map unreadable.
            val nodeN = 300
            val nx = FloatArray(nodeN)
            val ny = FloatArray(nodeN)
            for (i in 0 until nodeN) {
                val q = i / 10
                val side = if (i % 2 == 0) -1f else 1f
                val px = when {
                    i < 70 -> cx + side * w * (.12f + .13f * ((q % 12) / 11f))
                    i < 150 -> cx + side * w * (.04f + .08f * ((q % 10) / 9f))
                    else -> cx + sin(i * .73f) * w * .20f
                }
                val py = when {
                    i < 70 -> cy + sin(i * .41f) * h * .25f
                    i < 150 -> cy + cos(i * .29f) * h * .20f
                    else -> cy + sin(i * .37f) * h * .30f
                }
                nx[i] = px.coerceIn(x + 10f, x + w - 10f)
                ny[i] = py.coerceIn(y + 10f, y + h - 10f)
            }

            paint.strokeWidth = .65f
            for (i in 0 until nodeN step 2) {
                val j = (i * 47 + 17) % nodeN
                paint.color = Color.argb(45, 145, 155, 162)
                c.drawLine(nx[i], ny[i], nx[j], ny[j], paint)
            }

            for (i in 0 until nodeN) {
                val idx = when {
                    i < 55 -> VIS_START + (i * 11) % (VIS_END - VIS_START)
                    i < 85 -> OLF_START + (i * 7) % (OLF_END - OLF_START)
                    i < 110 -> GUST_START + (i * 5) % (GUST_END - GUST_START)
                    i < 150 -> CX_START + (i * 13) % (CX_END - CX_START)
                    i < 210 -> INTEGRATION_START + (i * 31) % (N - INTEGRATION_START)
                    else -> MOTOR_START + (i * 3) % (MOTOR_END - MOTOR_START)
                }
                val active = fired[idx]
                val membrane = ((v[idx] + .72f) / .75f).coerceIn(0f, 1f)
                if (active) {
                    paint.style = Paint.Style.FILL
                    paint.color = Color.argb(75, 70, 220, 145)
                    c.drawCircle(nx[i], ny[i], 7f, paint)
                }
                paint.style = Paint.Style.FILL
                paint.color = if (active) {
                    Color.rgb(255, 226, 65)
                } else {
                    Color.rgb(
                        (60 + membrane * 85).toInt(),
                        (65 + membrane * 75).toInt(),
                        (72 + membrane * 70).toInt()
                    )
                }
                c.drawCircle(nx[i], ny[i], if (active) 2.8f else 1.8f, paint)
            }

            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(210, 215, 218)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 8f
            paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("ÓPTICO", left, y + h - 6f, paint)
            c.drawText("ÓPTICO", right, y + h - 6f, paint)
            c.drawText("CENTRAL / MB / CX", cx, y + 12f, paint)
            c.drawText("VNC · MOTOR", cx, y + h - 6f, paint)
            paint.textAlign = Paint.Align.LEFT
        }

        private fun drawFly(c: Canvas, px: Float, py: Float, angle: Float) {
            c.save()
            c.rotate(Math.toDegrees(angle.toDouble()).toFloat(), px, py)

            // Ground shadow.
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(40, 0, 0, 0)
            c.drawOval(px - 44f, py + 21f, px + 43f, py + 32f, paint)

            // Six articulated legs.
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = 3.2f
            paint.color = Color.rgb(45, 37, 35)
            val ys = floatArrayOf(-16f, 0f, 16f)
            for ((q, yy) in ys.withIndex()) {
                val knee = if (q == 1) 20f else 24f
                c.drawLine(px - 5f, py + yy, px - knee, py + yy - 20f, paint)
                c.drawLine(px - knee, py + yy - 20f, px - knee - 20f, py + yy + 3f, paint)
                c.drawLine(px + 6f, py + yy, px + knee, py + yy - 20f, paint)
                c.drawLine(px + knee, py + yy - 20f, px + knee + 20f, py + yy + 3f, paint)
            }

            // Transparent wings with veins.
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(95, 184, 210, 226)
            c.drawOval(px - 13f, py - 67f, px + 39f, py - 7f, paint)
            c.drawOval(px - 13f, py + 7f, px + 39f, py + 67f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.1f
            paint.color = Color.argb(170, 100, 135, 155)
            c.drawOval(px - 13f, py - 67f, px + 39f, py - 7f, paint)
            c.drawOval(px - 13f, py + 7f, px + 39f, py + 67f, paint)
            c.drawLine(px + 2f, py - 63f, px + 25f, py - 10f, paint)
            c.drawLine(px + 2f, py + 63f, px + 25f, py + 10f, paint)

            // Segmented abdomen.
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(48, 43, 41)
            c.drawOval(px - 50f, py - 21f, px + 18f, py + 21f, paint)
            val segments = floatArrayOf(-37f, -25f, -13f, -1f, 11f)
            for ((k, xx) in segments.withIndex()) {
                paint.color = if (k % 2 == 0) Color.rgb(142, 108, 72) else Color.rgb(64, 54, 49)
                c.drawRect(px + xx, py - 19f, px + xx + 6f, py + 19f, paint)
            }

            // Thorax and head.
            paint.color = Color.rgb(60, 54, 51)
            c.drawCircle(px + 22f, py, 17f, paint)
            paint.color = Color.rgb(50, 44, 43)
            c.drawCircle(px + 38f, py, 14f, paint)

            // Compound eyes.
            paint.color = Color.rgb(150, 38, 34)
            c.drawCircle(px + 45f, py - 8f, 9f, paint)
            c.drawCircle(px + 45f, py + 8f, 9f, paint)
            paint.color = Color.rgb(230, 95, 70)
            c.drawCircle(px + 47f, py - 9f, 2.2f, paint)
            c.drawCircle(px + 47f, py + 7f, 2.2f, paint)

            // Antennae.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.8f
            paint.color = Color.rgb(50, 42, 39)
            c.drawLine(px + 45f, py - 8f, px + 64f, py - 27f, paint)
            c.drawLine(px + 45f, py + 8f, px + 64f, py + 27f, paint)
            paint.style = Paint.Style.FILL
            c.drawCircle(px + 65f, py - 28f, 2f, paint)
            c.drawCircle(px + 65f, py + 28f, 2f, paint)
            c.restore()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    if (e.y < sceneBottom()) {
                        moveStimulus(e.x / width.toFloat(), e.y / sceneBottom())
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }

        private fun moveStimulus(xr: Float, yr: Float) {
            val x = xr.coerceIn(.06f, .94f)
            val y = yr.coerceIn(.10f, .82f)
            when (selectedStimulus) {
                0 -> { foodX = x; foodY = y }
                1 -> { lightX = x; lightY = y }
                else -> { dangerX = x; dangerY = y }
            }
        }
    }
}
