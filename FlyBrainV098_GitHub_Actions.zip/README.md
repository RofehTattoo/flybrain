# FlyBrain V0.98

## Objetivo
V0.98 profundiza el enfoque connectome-driven: exactamente 16.669 neuronas de MaleCNS v1.0, con diversidad de tipos preservada, todos los neuronas descendientes y motoras VNC retenidos cuando están anotados, y solo conexiones publicadas entre las neuronas retenidas.

El movimiento no se genera desde reglas comida→avance ni peligro→escape. La interfaz corporal lee exclusivamente actividad de neuronas motoras VNC retenidas del connectoma; sus roles (leg, wing, haltere, neck, abdomen, jump, other) se derivan de las anotaciones publicadas, no del índice de la neurona.

## Fuente científica
MaleCNS v1.0 — Janelia/FlyEM. Dataset CC-BY.
https://male-cns.janelia.org/download/

La conectividad completa publicada está disponible como `connectome-weights-male-cns-v1.0-minconf-0.5.feather` (1.1 GB). El extractor la reduce a 16.669 neuronas y conserva solo las aristas publicadas entre ellas.

## Limitaciones
Esto sigue siendo un modelo computacional: el connectoma aporta anatomía/conectividad, pero la dinámica neuronal y la mecánica corporal son aproximaciones. V0.98 evita atajos conductuales y hace explícita la separación entre red neuronal, VNC y cuerpo virtual.


## V0.98 behavioral architecture

V0.98 keeps the 16,669-neuron MaleCNS reduction and measured published edges, but adds an explicit internal-state modulation layer rather than a stimulus-to-body shortcut. A slow endogenous locomotor state and homeostatic pressure modulate central and descending neurons; VNC motor neurons remain the only source of body movement. The runtime tracks actual motor activity for the locomotion display, so “exploration” is not reported while the fly is stationary.

The binary format is FBC98. Node metadata additionally stores a descending-neuron role label derived from published annotation text (walking/forward, turning/steering, backward, escape, or unknown). This label only controls the strength of the internal-state modulation; it does not create or alter connectome edges.

V0.98 is still an approximation: the connectome is reduced, neurotransmitter-sign-resolved edges are used for direct current, and body mechanics are simplified. The scientific test is whether spontaneous locomotion, spatial sensory modulation, and closed-loop sensorimotor behavior emerge without directly mapping food/light/danger to body movement.
