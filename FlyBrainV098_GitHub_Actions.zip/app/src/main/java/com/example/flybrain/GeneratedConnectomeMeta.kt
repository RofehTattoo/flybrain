package com.example.flybrain

/** Placeholder overwritten by tools/build_connectome.py during the V0.98 build. */
object GeneratedConnectomeMeta {
    const val VERSION = "MaleCNS v1.0 · FlyBrain V0.98"
    const val NEURONS = 16669
    const val EDGES = 0
    const val CONTACTS_RETAINED = 0L
    const val VIS_START = 0
    const val VIS_END = 1
    const val OLF_START = 1
    const val OLF_END = 2
    const val GUST_START = 2
    const val GUST_END = 3
    const val MECH_START = 3
    const val MECH_END = 4
    const val DESC_START = 4
    const val DESC_END = 5
    const val ASC_START = 5
    const val ASC_END = 6
    const val VMOTOR_START = 6
    const val VMOTOR_END = 7
    const val VSENS_START = 7
    const val VSENS_END = 8
    const val OTHER_START = 8
    const val OTHER_END = 16669
    const val MOTOR_LEG = 1
    const val MOTOR_WING = 2
    const val MOTOR_HALTERE = 3
    const val MOTOR_NECK = 4
    const val MOTOR_ABDOMEN = 5
    const val MOTOR_JUMP = 6
    const val MOTOR_OTHER = 7
}
