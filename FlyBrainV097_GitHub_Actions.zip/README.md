# FlyBrain V0.97

## Objetivo
V0.97 profundiza el enfoque connectome-driven: exactamente 16.669 neuronas de MaleCNS v1.0, con diversidad de tipos preservada, todos los neuronas descendientes y motoras VNC retenidos cuando están anotados, y solo conexiones publicadas entre las neuronas retenidas.

El movimiento no se genera desde reglas comida→avance ni peligro→escape. La interfaz corporal lee exclusivamente actividad de neuronas motoras VNC retenidas del connectoma; sus roles (leg, wing, haltere, neck, abdomen, jump, other) se derivan de las anotaciones publicadas, no del índice de la neurona.

## Fuente científica
MaleCNS v1.0 — Janelia/FlyEM. Dataset CC-BY.
https://male-cns.janelia.org/download/

La conectividad completa publicada está disponible como `connectome-weights-male-cns-v1.0-minconf-0.5.feather` (1.1 GB). El extractor la reduce a 16.669 neuronas y conserva solo las aristas publicadas entre ellas.

## Limitaciones
Esto sigue siendo un modelo computacional: el connectoma aporta anatomía/conectividad, pero la dinámica neuronal y la mecánica corporal son aproximaciones. V0.97 evita atajos conductuales y hace explícita la separación entre red neuronal, VNC y cuerpo virtual.
