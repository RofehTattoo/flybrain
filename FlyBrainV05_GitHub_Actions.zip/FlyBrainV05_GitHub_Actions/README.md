# FlyBrain V0.5

Versión experimental refinada.

## Arquitectura
- 512 neuronas LIF
- 24 sensoriales
- 360 interneuronas recurrentes
- 128 motoras/de valoración
- Conexiones dispersas para reducir carga de CPU
- Refractariedad y adaptación neuronal
- Ruido espontáneo controlado

## Estímulos
- 🟢 Comida: atracción y recompensa
- ☀️ Luz: fototaxis positiva
- ⚠️ Peligro: escape/evitación
- Botones independientes ON/OFF
- Toques para reposicionar estímulos
- RESET para reiniciar el estado

## Corrección importante respecto a V0.4
La función de estímulo de V0.4 calculaba accidentalmente una parte de la señal respecto al origen (0,0), en vez de respecto a la posición real del estímulo. V0.5 usa la distancia y el ángulo reales entre mosca y estímulo.

La locomoción se basa en la actividad de las poblaciones motoras; no es simplemente una regla directa de posición.

No es el connectoma biológico de Drosophila. Es un modelo neuronal experimental inspirado en principios de redes de spiking.
