package com.example.flybrain

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.widget.*
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 247, 247))
        }

        val sim = FlyView()
        root.addView(sim, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 6, 8, 8)
            setBackgroundColor(Color.rgb(232, 232, 232))
        }

        fun makeButton(label: String) = Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            minHeight = 50
        }

        val food = makeButton("🟢 COMIDA")
        val light = makeButton("☀️ LUZ")
        val danger = makeButton("⚠️ PELIGRO")
        val reset = makeButton("↻ RESET")

        controls.addView(food, LinearLayout.LayoutParams(0, 56.dp(), 1f))
        controls.addView(light, LinearLayout.LayoutParams(0, 56.dp(), 1f))
        controls.addView(danger, LinearLayout.LayoutParams(0, 56.dp(), 1f))
        controls.addView(reset, LinearLayout.LayoutParams(0, 56.dp(), 1f))

        food.setOnClickListener { sim.foodOn = !sim.foodOn; sim.updateButtons() }
        light.setOnClickListener { sim.lightOn = !sim.lightOn; sim.updateButtons() }
        danger.setOnClickListener { sim.dangerOn = !sim.dangerOn; sim.updateButtons() }
        reset.setOnClickListener { sim.resetSimulation() }

        sim.foodButton = food
        sim.lightButton = light
        sim.dangerButton = danger
        root.addView(controls, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 70.dp()
        ))

        setContentView(root)
        sim.updateButtons()
    }

    private fun Int.dp(): Int =
        (this * resources.displayMetrics.density).roundToInt()

    inner class FlyView : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rng = Random(505)

        /*
         * FLYBRAIN V0.5
         *
         * 512 spiking units:
         *   24 sensory
         *  360 recurrent interneurons
         *  128 motor/value
         *
         * The V0.4 implementation had a serious sensory bug:
         * stimulus() used distance from (0,0), not distance to the
         * actual stimulus. V0.5 fixes that and removes the direct
         * "stimulus -> body" steering shortcut. Body control is driven
         * by motor population activity.
         *
         * Network:
         *   stimulus -> sensory spikes -> interneuron spikes
         *   -> recurrent processing -> motor spikes -> behaviour
         *
         * A sparse graph is used instead of a 512x512 dense matrix.
         */

        private val N = 512
        private val SENSOR = 24
        private val INTER_START = SENSOR
        private val INTER_END = 384
        private val MOTOR_START = INTER_END

        private val v = FloatArray(N) { -0.72f }
        private val adapt = FloatArray(N)
        private val fired = BooleanArray(N)
        private val prevFired = BooleanArray(N)
        private val refractory = FloatArray(N)

        // Sparse incoming graph.
        private val incoming = Array(N) { IntArray(0) }
        private val incomingW = Array(N) { FloatArray(0) }

        var foodOn = true
        var lightOn = false
        var dangerOn = false

        var foodButton: Button? = null
        var lightButton: Button? = null
        var dangerButton: Button? = null

        private var flyX = 0.24f
        private var flyY = 0.58f
        private var heading = -0.25f

        private var foodX = 0.76f
        private var foodY = 0.36f
        private var lightX = 0.72f
        private var lightY = 0.72f
        private var dangerX = 0.30f
        private var dangerY = 0.30f

        private var selectedStimulus = 0 // 0 food, 1 light, 2 danger
        private var simTime = 0f
        private var lastNs = System.nanoTime()
        private var fps = 60f

        private var foodHits = 0
        private var escapeEvents = 0
        private var lastDangerLevel = 0f
        private var satiety = 0f
        private var fatigue = 0f
        private var novelty = 0f

        init {
            setBackgroundColor(Color.rgb(247, 247, 247))
            buildBrain()
        }

        fun updateButtons() {
            foodButton?.text = if (foodOn) "🟢 COMIDA ON" else "🟢 COMIDA"
            lightButton?.text = if (lightOn) "☀️ LUZ ON" else "☀️ LUZ"
            dangerButton?.text = if (dangerOn) "⚠️ PELIGRO ON" else "⚠️ PELIGRO"
            foodButton?.alpha = if (foodOn) 1f else .55f
            lightButton?.alpha = if (lightOn) 1f else .55f
            dangerButton?.alpha = if (dangerOn) 1f else .55f
        }

        fun resetSimulation() {
            for (i in 0 until N) {
                v[i] = -.72f
                adapt[i] = 0f
                fired[i] = false
                prevFired[i] = false
                refractory[i] = 0f
            }
            flyX = .24f
            flyY = .58f
            heading = -.25f
            foodX = .76f; foodY = .36f
            lightX = .72f; lightY = .72f
            dangerX = .30f; dangerY = .30f
            simTime = 0f
            foodHits = 0
            escapeEvents = 0
            satiety = 0f
            fatigue = 0f
            novelty = 0f
        }

        private fun addEdge(target: Int, source: Int, weight: Float, lists: Array<MutableList<Int>>, ws: Array<MutableList<Float>>) {
            lists[target].add(source)
            ws[target].add(weight)
        }

        private fun buildBrain() {
            val lists = Array(N) { mutableListOf<Int>() }
            val weights = Array(N) { mutableListOf<Float>() }

            // Sensory populations: 8 per stimulus.
            // Each stimulus has left/right, near/far and upper/lower
            // directional channels. The encoding is computed in sense().
            for (i in INTER_START until INTER_END) {
                // Every interneuron samples 5-9 sensory channels.
                val count = 5 + rng.nextInt(5)
                repeat(count) {
                    val src = rng.nextInt(SENSOR)
                    val sign = if (rng.nextFloat() < .64f) 1f else -1f
                    addEdge(i, src, sign * (.055f + rng.nextFloat() * .13f), lists, weights)
                }

                // Recurrent sparse excitation/inhibition.
                val recurrent = 7 + rng.nextInt(7)
                repeat(recurrent) {
                    var src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                    while (src == i) src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                    val sign = if (rng.nextFloat() < .72f) 1f else -1f
                    addEdge(i, src, sign * (.025f + rng.nextFloat() * .075f), lists, weights)
                }
            }

            /*
             * Motor groups:
             * 384-399  turn left
             * 400-415  turn right
             * 416-447  forward/approach
             * 448-463  retreat/escape
             * 464-479  braking/avoidance
             * 480-495  exploration/scan
             * 496-511  valuation/arousal
             *
             * Each motor neuron receives recurrent input. Structured
             * biases are added so the network has interpretable sensorimotor
             * pathways while still allowing recurrent competition.
             */
            for (i in MOTOR_START until N) {
                repeat(8) {
                    val src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                    val sign = if (rng.nextFloat() < .65f) 1f else -1f
                    addEdge(i, src, sign * (.04f + rng.nextFloat() * .08f), lists, weights)
                }
            }

            // Structured sensory -> motor "teaching" channels are indirect:
            // sensory neurons feed dedicated interneuron pools, which feed motors.
            // This prevents direct body steering but makes basic behaviours learnable.
            for (i in 0 until 24) {
                val poolStart = INTER_START + (i % 12) * 28
                for (j in poolStart until min(poolStart + 28, INTER_END)) {
                    addEdge(j, i, if (i % 8 == 0 || i % 8 == 1) .13f else .08f, lists, weights)
                }
            }

            // Left/right food + light drive approach turning.
            for (i in 384 until 400) {
                repeat(12) {
                    addEdge(i, INTER_START + rng.nextInt(140), .055f, lists, weights)
                }
            }
            for (i in 400 until 416) {
                repeat(12) {
                    addEdge(i, INTER_START + rng.nextInt(140), .055f, lists, weights)
                }
            }

            // Danger strongly recruits escape motors.
            for (i in 448 until 464) {
                repeat(18) {
                    addEdge(i, INTER_START + rng.nextInt(180), .085f, lists, weights)
                }
            }

            for (i in 0 until N) {
                incoming[i] = lists[i].toIntArray()
                incomingW[i] = weights[i].toFloatArray()
            }
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)

            val now = System.nanoTime()
            val raw = (now - lastNs) / 1e9
            val dt = min(.022, max(.003, raw)).toFloat()
            lastNs = now

            fps = fps * .94f + (1f / dt) * .06f
            simTime += dt

            sense(dt)
            stepBrain(dt)
            driveBody(dt)
            drawScene(c)
            drawFly(c, flyX * width, flyY * height, heading)

            postInvalidateOnAnimation()
        }

        private fun signal(distance: Float, radius: Float): Float {
            return exp(-(distance * distance) / (2f * radius * radius))
                .coerceIn(0f, 1f)
        }

        private fun directionalStrength(dx: Float, dy: Float, angle: Float, side: Int): Float {
            val targetAngle = atan2(dy, dx)
            val error = atan2(sin(targetAngle - angle), cos(targetAngle - angle))
            return when (side) {
                -1 -> (-error / (Math.PI / 2f)).coerceIn(0f, 1f)
                1 -> (error / (Math.PI / 2f)).coerceIn(0f, 1f)
                else -> 1f - abs(error / Math.PI.toFloat()).coerceIn(0f, 1f)
            }
        }

        private fun encodeStimulus(
            enabled: Boolean,
            sx: Float,
            sy: Float,
            base: Int,
            gain: Float
        ) {
            if (!enabled) return

            val dx = sx - flyX
            val dy = sy - flyY
            val dist = hypot(dx, dy)
            val proximity = signal(dist, .24f)
            val left = directionalStrength(dx, dy, heading, -1)
            val right = directionalStrength(dx, dy, heading, 1)
            val front = directionalStrength(dx, dy, heading, 0)
            val upper = (0.5f + dy * 2.2f).coerceIn(0f, 1f)
            val lower = (0.5f - dy * 2.2f).coerceIn(0f, 1f)

            // Two directional channels, two vertical channels,
            // proximity and front/novelty channels.
            val currents = floatArrayOf(
                left * gain,
                right * gain,
                upper * gain * .55f,
                lower * gain * .55f,
                proximity * gain,
                front * gain,
                (1f - proximity) * gain * .28f,
                proximity * front * gain * .7f
            )
            for (k in 0 until 8) {
                v[base + k] += currents[k]
            }
        }

        private fun sense(dt: Float) {
            encodeStimulus(foodOn, foodX, foodY, 0, 1.00f * (1f - satiety * .45f))
            encodeStimulus(lightOn, lightX, lightY, 8, .78f)
            encodeStimulus(dangerOn, dangerX, dangerY, 16, 1.35f)

            // Adaptation makes continuous stimulation less dominant.
            for (i in 0 until SENSOR) {
                v[i] -= adapt[i]
                adapt[i] *= exp(-dt * 1.5f)
            }

            novelty = .96f * novelty + .04f * (
                (if (foodOn) signal(hypot(foodX - flyX, foodY - flyY), .4f) else 0f) +
                (if (lightOn) signal(hypot(lightX - flyX, lightY - flyY), .4f) else 0f) +
                (if (dangerOn) signal(hypot(dangerX - flyX, dangerY - flyY), .4f) else 0f)
            ).coerceIn(0f, 1f)
        }

        private fun stepBrain(dt: Float) {
            for (i in 0 until N) prevFired[i] = fired[i]

            for (i in 0 until N) {
                if (refractory[i] > 0f) {
                    refractory[i] -= dt
                    fired[i] = false
                    continue
                }

                var syn = 0f
                val sources = incoming[i]
                val ws = incomingW[i]
                for (k in sources.indices) {
                    if (prevFired[sources[k]]) syn += ws[k]
                }

                // Leaky integrate-and-fire with adaptation.
                v[i] += ((-.72f - v[i]) * 7.0f + syn - adapt[i]) * dt

                // Low background stochastic drive, strongest in interneurons.
                if (i >= INTER_START && i < INTER_END && rng.nextFloat() < .0028f) {
                    v[i] += .045f
                }

                fired[i] = v[i] >= .035f
                if (fired[i]) {
                    v[i] = -.84f
                    adapt[i] = min(.16f, adapt[i] + .028f)
                    refractory[i] = .006f
                }
            }
        }

        private fun count(a: Int, b: Int): Int {
            var n = 0
            for (i in a until b) if (fired[i]) n++
            return n
        }

        private fun driveBody(dt: Float) {
            val left = count(384, 400)
            val right = count(400, 416)
            val forward = count(416, 448)
            val escape = count(448, 464)
            val brake = count(464, 480)
            val explore = count(480, 496)
            val value = count(496, 512)

            val turn = (right - left) * .011f
            val propulsion = forward * .0015f
            val escapeTurn = (right - left) * .004f
            var speed = (.004f + propulsion + explore * .00045f) -
                    escape * .0028f - brake * .0014f

            // These are not direct steering rules: they are environmental
            // consequences of motor populations being recruited by the network.
            heading += turn + escapeTurn
            if (escape > 3) heading += .018f * sin(simTime * 5f)

            // Motor population controls velocity.
            speed += value * .00025f
            speed = speed.coerceIn(-.018f, .026f)

            flyX += cos(heading) * speed * dt * 14f
            flyY += sin(heading) * speed * dt * 14f

            if (flyX < .04f || flyX > .96f) {
                heading = Math.PI.toFloat() - heading
                flyX = flyX.coerceIn(.04f, .96f)
            }
            if (flyY < .13f || flyY > .94f) {
                heading = -heading
                flyY = flyY.coerceIn(.13f, .94f)
            }

            val foodDist = hypot(foodX - flyX, foodY - flyY)
            if (foodOn && foodDist < .055f) {
                foodHits++
                satiety = min(1f, satiety + .28f)
                foodX = .08f + rng.nextFloat() * .84f
                foodY = .17f + rng.nextFloat() * .70f
            }

            satiety *= exp(-dt * .018f)
            fatigue = (fatigue * .995f + escape * .002f).coerceIn(0f, 1f)

            val dangerLevel = if (dangerOn) {
                signal(hypot(dangerX - flyX, dangerY - flyY), .28f)
            } else 0f
            if (dangerLevel > .72f && lastDangerLevel <= .72f) escapeEvents++
            lastDangerLevel = dangerLevel
        }

        private fun drawScene(c: Canvas) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = Color.LTGRAY
            c.drawRect(18f, 18f, width - 18f, height - 18f, paint)
            paint.style = Paint.Style.FILL

            if (foodOn) {
                paint.color = Color.rgb(50, 175, 80)
                c.drawCircle(foodX * width, foodY * height, 16f, paint)
                paint.color = Color.WHITE
                paint.textSize = 12f
                paint.textAlign = Paint.Align.CENTER
                c.drawText("F", foodX * width, foodY * height + 4f, paint)
            }

            if (lightOn) {
                paint.color = Color.rgb(245, 190, 45)
                c.drawCircle(lightX * width, lightY * height, 25f, paint)
                paint.color = Color.rgb(250, 225, 125)
                c.drawCircle(lightX * width, lightY * height, 13f, paint)
            }

            if (dangerOn) {
                paint.color = Color.rgb(205, 55, 55)
                c.drawCircle(dangerX * width, dangerY * height, 23f, paint)
                paint.color = Color.WHITE
                paint.textSize = 25f
                paint.textAlign = Paint.Align.CENTER
                c.drawText("!", dangerX * width, dangerY * height + 8f, paint)
                paint.textAlign = Paint.Align.LEFT
            }

            paint.color = Color.DKGRAY
            paint.textAlign = Paint.Align.LEFT
            paint.textSize = 18f
            c.drawText("FLYBRAIN V0.5", 28f, 45f, paint)
            paint.textSize = 11f
            c.drawText("512 neuronas · LIF + adaptación · red dispersa", 28f, 63f, paint)
            c.drawText("24 sensoriales · 360 recurrentes · 128 motor/valor", 28f, 79f, paint)
            c.drawText(
                "comida ${if(foodOn) "ON" else "OFF"} · luz ${if(lightOn) "ON" else "OFF"} · peligro ${if(dangerOn) "ON" else "OFF"}",
                28f, 95f, paint
            )
            c.drawText(
                "comidas: $foodHits · escapes: $escapeEvents · saciedad: ${(satiety * 100).toInt()}% · FPS: ${fps.toInt()}",
                28f, 111f, paint
            )

            val baseY = height - 35f
            paint.textSize = 10f
            paint.color = Color.DKGRAY
            c.drawText("ACTIVIDAD NEURONAL · 512 UNIDADES", 28f, baseY - 53f, paint)

            val barWidth = max(1.2f, (width - 56f) / N.toFloat())
            var bx = 28f
            for (i in 0 until N) {
                val activity = ((v[i] + .84f) / .875f).coerceIn(0f, 1f)
                paint.color = if (fired[i]) Color.BLACK else Color.LTGRAY
                c.drawRect(bx, baseY - activity * 38f, bx + barWidth - .5f, baseY, paint)
                bx += barWidth
            }

            paint.color = Color.DKGRAY
            paint.textSize = 10f
            c.drawText("Toca el escenario para mover el estímulo seleccionado", 28f, height - 84f, paint)
            c.drawText("Selecciona: comida → luz → peligro (toques largos cambian el objetivo)", 28f, height - 68f, paint)
        }

        private fun drawFly(c: Canvas, px: Float, py: Float, angle: Float) {
            c.save()
            c.rotate(Math.toDegrees(angle.toDouble()).toFloat(), px, py)

            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(35, 35, 35)
            c.drawOval(px - 18, py - 9, px + 18, py + 9, paint)
            c.drawCircle(px + 15, py, 7f, paint)

            paint.color = Color.argb(150, 175, 210, 230)
            c.drawOval(px - 10, py - 25, px + 7, py - 3, paint)
            c.drawOval(px - 10, py + 3, px + 7, py + 25, paint)

            paint.color = Color.WHITE
            c.drawCircle(px + 18, py - 3, 2.5f, paint)
            c.drawCircle(px + 18, py + 3, 2.5f, paint)
            c.restore()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    selectedStimulus = (selectedStimulus + 1) % 3
                    moveStimulus(e.x / width, e.y / height)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    moveStimulus(e.x / width, e.y / height)
                    return true
                }
            }
            return true
        }

        private fun moveStimulus(xRaw: Float, yRaw: Float) {
            val x = xRaw.coerceIn(.06f, .94f)
            val y = yRaw.coerceIn(.13f, .92f)
            when (selectedStimulus) {
                0 -> { foodX = x; foodY = y }
                1 -> { lightX = x; lightY = y }
                else -> { dangerX = x; dangerY = y }
            }
        }
    }
}
