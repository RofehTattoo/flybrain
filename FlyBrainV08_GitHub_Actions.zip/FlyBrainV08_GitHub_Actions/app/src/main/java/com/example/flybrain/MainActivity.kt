package com.example.flybrain

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 247, 247))
            clipToPadding = true
        }

        root.setOnApplyWindowInsetsListener { view, insets ->
            val bars = if (Build.VERSION.SDK_INT >= 30) {
                insets.getInsets(WindowInsets.Type.systemBars())
            } else null
            val top = bars?.top ?: insets.systemWindowInsetTop
            val bottom = bars?.bottom ?: insets.systemWindowInsetBottom
            view.setPadding(0, top, 0, bottom)
            insets
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6.dp(), 5.dp(), 6.dp(), 5.dp())
            setBackgroundColor(Color.rgb(226, 226, 226))
        }

        fun makeButton(label: String): Button = Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            minHeight = 0
            minWidth = 0
            setPadding(1.dp(), 0, 1.dp(), 0)
        }

        val food = makeButton("COMIDA")
        val light = makeButton("LUZ")
        val danger = makeButton("PELIGRO")
        val reset = makeButton("↻ RESET")
        val buttonHeight = 62.dp()

        controls.addView(food, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(light, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(danger, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(reset, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        root.addView(controls, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 72.dp()))

        val info = TextView(this).apply {
            setPadding(14.dp(), 7.dp(), 14.dp(), 7.dp())
            setTextColor(Color.rgb(28, 28, 28))
            textSize = 13f
            typeface = Typeface.create("sans", Typeface.NORMAL)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                setStroke(2.dp(), Color.rgb(145, 145, 145))
                cornerRadius = 8.dp().toFloat()
            }
        }
        root.addView(info, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 112.dp()).apply {
            setMargins(8.dp(), 5.dp(), 8.dp(), 5.dp())
        })

        val sim = FlyView(info)
        root.addView(sim, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        fun refresh() {
            info.text = sim.infoText()
            sim.updateButtons()
        }

        food.setOnClickListener { sim.selectAndToggle(0); refresh() }
        light.setOnClickListener { sim.selectAndToggle(1); refresh() }
        danger.setOnClickListener { sim.selectAndToggle(2); refresh() }
        reset.setOnClickListener { sim.resetSimulation(); refresh() }

        sim.foodButton = food
        sim.lightButton = light
        sim.dangerButton = danger
        sim.resetButton = reset

        setContentView(root)
        root.requestApplyInsets()
        refresh()
    }

    inner class FlyView(private val info: TextView) : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rng = Random(508)

        // V0.8: 1,536-neuron modular network with explicit pathways, state and plasticity.
        // pathways, state, reward-modulated plasticity and observability.
        private val N = 1536
        private val SENSOR = 48
        private val INTER_START = SENSOR
        private val INTER_END = 1280
        private val MOTOR_START = INTER_END
        private val MOTOR_END = N

        private val v = FloatArray(N) { -0.72f }
        private val adapt = FloatArray(N)
        private val fired = BooleanArray(N)
        private val prevFired = BooleanArray(N)
        private val refractory = FloatArray(N)
        private val incoming = Array(N) { IntArray(0) }
        private val incomingW = Array(N) { FloatArray(0) }
        private val baseW = Array(N) { FloatArray(0) }
        private val eligibility = Array(N) { FloatArray(0) }

        var foodOn = true
        var lightOn = false
        var dangerOn = false
        var selectedStimulus = 0
        var foodButton: Button? = null
        var lightButton: Button? = null
        var dangerButton: Button? = null
        var resetButton: Button? = null

        private var flyX = .24f
        private var flyY = .55f
        private var heading = -.15f
        private var flySpeed = .002f
        private var foodX = .76f
        private var foodY = .35f
        private var lightX = .72f
        private var lightY = .72f
        private var dangerX = .30f
        private var dangerY = .30f
        private var simTime = 0f
        private var lastNs = System.nanoTime()
        private var fps = 60f
        private var foodHits = 0
        private var escapeEvents = 0
        private var lastDangerLevel = 0f
        private var satiety = 0f
        private var fatigue = 0f
        private var novelty = 0f
        private var memoryTrace = 0f
        private var lastReward = 0f
        private var sensoryDisplay = 0f
        private var interDisplay = 0f
        private var motorDisplay = 0f
        private var foodSignalDisplay = 0f
        private var lightSignalDisplay = 0f
        private var dangerSignalDisplay = 0f
        private var flowSensor = 0f
        private var flowInter = 0f
        private var flowMotor = 0f
        private var flowState = 0f
        private var draggingStimulus = false

        init {
            setBackgroundColor(Color.rgb(250, 250, 250))
            isFocusable = true
            buildBrain()
        }

        fun infoText(): String = buildString {
            append("FLYBRAIN V0.8\n")
            append("1.536 neuronas · red modular dispersa · LIF + adaptación + plasticidad\n")
            append("48 sensoriales · 1.232 integración · 256 motor/estado\n")
            append("COMIDA ${if (foodOn) "ON" else "OFF"}   LUZ ${if (lightOn) "ON" else "OFF"}   PELIGRO ${if (dangerOn) "ON" else "OFF"}\n")
            append("Comidas $foodHits   Escapes $escapeEvents   Saciedad ${(satiety * 100f).toInt()}%   Memoria ${(memoryTrace * 100f).toInt()}%   FPS ${fps.toInt()}")
        }

        fun selectAndToggle(stimulus: Int) {
            if (selectedStimulus == stimulus) {
                when (stimulus) {
                    0 -> foodOn = !foodOn
                    1 -> lightOn = !lightOn
                    else -> dangerOn = !dangerOn
                }
            } else {
                selectedStimulus = stimulus
                when (stimulus) {
                    0 -> foodOn = true
                    1 -> lightOn = true
                    else -> dangerOn = true
                }
            }
            invalidate()
        }

        private fun styleButton(button: Button, active: Boolean, selected: Boolean, accent: Int) {
            button.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 12.dp().toFloat()
                setColor(if (active) Color.rgb(232, 246, 235) else Color.rgb(245, 245, 245))
                setStroke(if (selected) 4 else 1, if (selected) accent else Color.rgb(155, 155, 155))
            }
            button.alpha = if (active) 1f else .68f
        }

        fun updateButtons() {
            foodButton?.let { it.text = if (foodOn) "COMIDA  ON" else "COMIDA"; styleButton(it, foodOn, selectedStimulus == 0, Color.rgb(35, 120, 70)) }
            lightButton?.let { it.text = if (lightOn) "LUZ  ON" else "LUZ"; styleButton(it, lightOn, selectedStimulus == 1, Color.rgb(210, 145, 10)) }
            dangerButton?.let { it.text = if (dangerOn) "PELIGRO  ON" else "PELIGRO"; styleButton(it, dangerOn, selectedStimulus == 2, Color.rgb(190, 45, 45)) }
            resetButton?.alpha = 1f
            invalidate()
        }

        fun resetSimulation() {
            for (i in 0 until N) {
                v[i] = -.72f
                adapt[i] = 0f
                fired[i] = false
                prevFired[i] = false
                refractory[i] = 0f
                for (k in incomingW[i].indices) {
                    incomingW[i][k] = baseW[i][k]
                    eligibility[i][k] = 0f
                }
            }
            flyX = .24f; flyY = .55f; heading = -.15f; flySpeed = .002f
            foodX = .76f; foodY = .35f; lightX = .72f; lightY = .72f; dangerX = .30f; dangerY = .30f
            simTime = 0f; foodHits = 0; escapeEvents = 0; lastDangerLevel = 0f; satiety = 0f; fatigue = 0f; novelty = 0f; memoryTrace = 0f; lastReward = 0f
            sensoryDisplay = 0f; interDisplay = 0f; motorDisplay = 0f
            foodSignalDisplay = 0f; lightSignalDisplay = 0f; dangerSignalDisplay = 0f
            flowSensor = 0f; flowInter = 0f; flowMotor = 0f; flowState = 0f
            lastNs = System.nanoTime()
            info.text = infoText()
            invalidate()
        }

        private fun addEdge(target: Int, source: Int, weight: Float, lists: Array<MutableList<Int>>, ws: Array<MutableList<Float>>) {
            lists[target].add(source); ws[target].add(weight)
        }

        private fun buildBrain() {
            val lists = Array(N) { mutableListOf<Int>() }
            val weights = Array(N) { mutableListOf<Float>() }

            // Six functional integration modules.
            val regions = arrayOf(
                48 until 250, 250 until 452, 452 until 654,
                654 until 856, 856 until 1068, 1068 until 1280
            )
            for (regionIndex in regions.indices) {
                val range = regions[regionIndex]
                for (i in range) {
                    repeat(7 + rng.nextInt(5)) {
                        val src = when (regionIndex) {
                            0 -> rng.nextInt(16)
                            1 -> 16 + rng.nextInt(16)
                            2 -> 32 + rng.nextInt(16)
                            else -> rng.nextInt(SENSOR)
                        }
                        val gain = when (regionIndex) {
                            0 -> .060f; 1 -> .055f; 2 -> .085f; else -> .032f
                        }
                        addEdge(i, src, gain + rng.nextFloat() * .045f, lists, weights)
                    }
                    repeat(10 + rng.nextInt(7)) {
                        var src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                        while (src == i) src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                        val sign = if (rng.nextFloat() < .74f) 1f else -1f
                        addEdge(i, src, sign * (.014f + rng.nextFloat() * .035f), lists, weights)
                    }
                }
            }

            repeat(1800) {
                val target = INTER_START + rng.nextInt(INTER_END - INTER_START)
                val source = INTER_START + rng.nextInt(INTER_END - INTER_START)
                if (target != source) {
                    val sign = if (rng.nextFloat() < .72f) 1f else -1f
                    addEdge(target, source, sign * (.010f + rng.nextFloat() * .024f), lists, weights)
                }
            }

            // Motor groups: left, right, forward, escape, brake, explore, value, state.
            for (i in MOTOR_START until N) {
                repeat(14) {
                    val src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                    val sign = if (rng.nextFloat() < .72f) 1f else -1f
                    addEdge(i, src, sign * (.024f + rng.nextFloat() * .038f), lists, weights)
                }
            }

            // Structured pathways preserve the sensory -> integration -> motor chain.
            for (i in 1280 until 1312) {
                for (src in 48 until 125 step 2) addEdge(i, src, .12f, lists, weights)
                for (src in 250 until 325 step 2) addEdge(i, src, .075f, lists, weights)
            }
            for (i in 1312 until 1344) {
                for (src in 48 until 125 step 2) addEdge(i, src + 1, .12f, lists, weights)
                for (src in 250 until 325 step 2) addEdge(i, src + 1, .075f, lists, weights)
            }
            for (i in 1344 until 1384) {
                for (src in 125 until 220 step 2) addEdge(i, src, .10f, lists, weights)
                for (src in 325 until 420 step 2) addEdge(i, src, .065f, lists, weights)
            }
            for (i in 1384 until 1416) {
                for (src in 452 until 654 step 2) addEdge(i, src, .19f, lists, weights)
                for (src in 654 until 730 step 3) addEdge(i, src, .09f, lists, weights)
            }
            for (i in 1416 until 1440) for (src in 452 until 654 step 3) addEdge(i, src, .14f, lists, weights)
            for (i in 1440 until 1464) for (src in 856 until 1280 step 3) addEdge(i, src, .060f, lists, weights)
            for (i in 1464 until 1496) for (src in 654 until 1280 step 4) addEdge(i, src, .048f, lists, weights)
            for (i in 1496 until 1536) for (src in 452 until 1280 step 5) addEdge(i, src, .042f, lists, weights)

            for (i in 0 until N) {
                incoming[i] = lists[i].toIntArray()
                incomingW[i] = weights[i].toFloatArray()
                baseW[i] = incomingW[i].clone()
                eligibility[i] = FloatArray(incomingW[i].size)
            }
        }

        private fun signal(distance: Float, radius: Float): Float = exp((-(distance * distance) / (2f * radius * radius)).toDouble()).toFloat().coerceIn(0f, 1f)

        private fun directionalStrength(dx: Float, dy: Float, angle: Float, side: Int): Float {
            val targetAngle = atan2(dy, dx)
            val error = atan2(sin(targetAngle - angle), cos(targetAngle - angle))
            return when (side) {
                -1 -> (-error / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                1 -> (error / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                else -> 1f - (abs(error) / Math.PI.toFloat()).coerceIn(0f, 1f)
            }
        }

        private fun encodeStimulus(enabled: Boolean, sx: Float, sy: Float, base: Int, gain: Float): Float {
            if (!enabled) return 0f
            val dx = sx - flyX; val dy = sy - flyY
            val dist = hypot(dx, dy)
            val proximity = signal(dist, .38f)
            val left = directionalStrength(dx, dy, heading, -1)
            val right = directionalStrength(dx, dy, heading, 1)
            val front = directionalStrength(dx, dy, heading, 0)
            val upper = (0.5f + dy * 2.4f).coerceIn(0f, 1f)
            val lower = (0.5f - dy * 2.4f).coerceIn(0f, 1f)
            val currents = floatArrayOf(
                left * gain, right * gain, front * gain, upper * gain * .7f, lower * gain * .7f, proximity * gain,
                proximity * front * gain, proximity * left * gain, proximity * right * gain,
                (1f - proximity) * gain * .22f, front * (1f - proximity) * gain * .18f, gain * .08f,
                left * proximity * gain * .8f, right * proximity * gain * .8f, front * proximity * gain * .8f, proximity * gain
            )
            for (k in 0 until 16) v[base + k] += currents[k]
            return (currents.sum() / (16f * gain)).coerceIn(0f, 1f)
        }

        private fun sense(dt: Float) {
            val foodSignal = encodeStimulus(foodOn, foodX, foodY, 0, 1.55f * (1f - satiety * .55f))
            val lightSignal = encodeStimulus(lightOn, lightX, lightY, 16, 1.35f)
            val dangerSignal = encodeStimulus(dangerOn, dangerX, dangerY, 32, 3.35f)
            foodSignalDisplay = .86f * foodSignalDisplay + .14f * foodSignal
            lightSignalDisplay = .86f * lightSignalDisplay + .14f * lightSignal
            dangerSignalDisplay = .86f * dangerSignalDisplay + .14f * dangerSignal
            for (i in 0 until SENSOR) {
                v[i] -= adapt[i]
                adapt[i] *= exp((-dt * 1.7f).toDouble()).toFloat()
            }
            val foodNovelty = if (foodOn) signal(hypot(foodX - flyX, foodY - flyY), .44f) else 0f
            val lightNovelty = if (lightOn) signal(hypot(lightX - flyX, lightY - flyY), .44f) else 0f
            val dangerNovelty = if (dangerOn) signal(hypot(dangerX - flyX, dangerY - flyY), .52f) else 0f
            novelty = .95f * novelty + .05f * (foodNovelty + lightNovelty + dangerNovelty).coerceIn(0f, 1f)
        }

        private fun stepBrain(dt: Float) {
            for (i in 0 until N) prevFired[i] = fired[i]
            for (i in 0 until N) {
                if (refractory[i] > 0f) { refractory[i] -= dt; fired[i] = false; continue }
                var syn = 0f
                val sources = incoming[i]; val ws = incomingW[i]
                for (k in sources.indices) if (prevFired[sources[k]]) syn += ws[k]
                v[i] += ((-.72f - v[i]) * 7.0f - adapt[i]) * dt + syn * .30f
                if (i in INTER_START until INTER_END && rng.nextFloat() < .0024f) v[i] += .052f
                fired[i] = v[i] >= .035f
                if (fired[i]) {
                    v[i] = -.84f
                    adapt[i] = min(.16f, adapt[i] + .028f)
                    refractory[i] = .006f
                }
            }
        }

        private fun count(a: Int, b: Int): Int { var n = 0; for (i in a until b) if (fired[i]) n++; return n }

        private fun learn(reward: Float, dt: Float) {
            // Reward-modulated Hebbian trace: small, bounded changes only on
            // recurrent/integration-to-motor synapses. This creates a simple
            // persistent memory without replacing the neural controller with rules.
            val clippedReward = reward.coerceIn(-1f, 1f)
            memoryTrace = (memoryTrace * exp((-dt * .055f).toDouble()).toFloat() + abs(clippedReward) * .035f).coerceIn(0f, 1f)
            for (target in MOTOR_START until MOTOR_END) {
                val sources = incoming[target]
                val ws = incomingW[target]
                val base = baseW[target]
                val elig = eligibility[target]
                for (k in sources.indices) {
                    val pre = if (prevFired[sources[k]]) 1f else 0f
                    val post = if (fired[target]) 1f else 0f
                    elig[k] = (elig[k] * .995f + pre * post * .08f).coerceIn(-1f, 1f)
                    ws[k] += clippedReward * elig[k] * dt * .45f
                    val lo = min(base[k] * .55f, base[k] * 1.55f)
                    val hi = max(base[k] * .55f, base[k] * 1.55f)
                    ws[k] = ws[k].coerceIn(lo, hi)
                }
            }
            lastReward = .92f * lastReward + .08f * clippedReward
        }

        private fun driveBody(dt: Float) {
            val left = count(1280, 1312)
            val right = count(1312, 1344)
            val forward = count(1344, 1384)
            val escape = count(1384, 1416)
            val brake = count(1416, 1440)
            val explore = count(1440, 1464)
            val value = count(1464, 1496)
            val state = count(1496, 1536)

            val threat = dangerSignalDisplay
            val turn = (right - left) * .022f
            val propulsion = forward * .0023f
            var speed = (.0014f + propulsion + explore * .00060f) - escape * .0068f - brake * .0025f
            heading += turn
            if (threat > .12f) {
                heading += (0.020f + threat * .060f) * sin(simTime * 11.0f)
                speed -= .0035f * threat
            }
            speed += value * .00024f + state * .00008f
            speed = speed.coerceIn(-.040f, .040f)
            flySpeed = .90f * flySpeed + .10f * speed
            flyX += cos(heading) * flySpeed * dt * 15f
            flyY += sin(heading) * flySpeed * dt * 15f

            if (flyX < .055f || flyX > .945f) { heading = Math.PI.toFloat() - heading; flyX = flyX.coerceIn(.055f, .945f) }
            if (flyY < .10f || flyY > .79f) { heading = -heading; flyY = flyY.coerceIn(.10f, .79f) }

            var reward = 0f
            val foodDist = hypot(foodX - flyX, foodY - flyY)
            if (foodOn && foodDist < .065f) {
                foodHits++
                satiety = min(1f, satiety + .28f)
                reward += 1f
                foodX = .08f + rng.nextFloat() * .84f
                foodY = .14f + rng.nextFloat() * .58f
            }
            satiety *= exp((-dt * .018f).toDouble()).toFloat()
            fatigue = (fatigue * .995f + escape * .002f).coerceIn(0f, 1f)
            val dangerLevel = if (dangerOn) signal(hypot(dangerX - flyX, dangerY - flyY), .36f) else 0f
            if (dangerLevel > .68f && lastDangerLevel <= .68f) {
                escapeEvents++
            }
            if (dangerOn && dangerLevel < .20f && lastDangerLevel > .68f) reward += .50f
            lastDangerLevel = dangerLevel
            learn(reward, dt)

            sensoryDisplay = .82f * sensoryDisplay + .18f * (count(0, SENSOR).toFloat() / SENSOR)
            interDisplay = .82f * interDisplay + .18f * (count(INTER_START, INTER_END).toFloat() / (INTER_END - INTER_START))
            motorDisplay = .82f * motorDisplay + .18f * (count(MOTOR_START, N).toFloat() / (N - MOTOR_START))
            flowSensor = .84f * flowSensor + .16f * max(sensoryDisplay, max(foodSignalDisplay, max(lightSignalDisplay, dangerSignalDisplay)))
            flowInter = .86f * flowInter + .14f * interDisplay
            flowMotor = .86f * flowMotor + .14f * max(motorDisplay, threat * .85f)
            flowState = .90f * flowState + .10f * (memoryTrace + satiety * .5f)
            info.text = infoText()
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val now = System.nanoTime()
            val raw = (now - lastNs) / 1e9
            val dt = min(.022, max(.003, raw)).toFloat()
            lastNs = now
            fps = fps * .94f + (1f / dt) * .06f
            simTime += dt
            sense(dt)
            stepBrain(dt)
            driveBody(dt)
            drawScene(c)
            drawFly(c, flyX * width, flyY * sceneBottom(), heading)
            drawBrainPanel(c)
            postInvalidateOnAnimation()
        }

        private fun sceneBottom(): Float {
            return height - brainPanelHeight()
        }

        private fun brainPanelHeight(): Float {
            return min(height * .36f, 310.dp().toFloat())
        }

        private fun drawScene(c: Canvas) {
            val bottom = sceneBottom()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = Color.rgb(190, 190, 190)
            c.drawRect(8f, 8f, width - 8f, bottom - 6f, paint)
            paint.style = Paint.Style.FILL

            if (foodOn) {
                val x = foodX * width; val y = foodY * bottom
                paint.color = Color.rgb(32, 155, 70); c.drawCircle(x, y, 23f, paint)
                paint.color = Color.WHITE; paint.textSize = 17f; paint.textAlign = Paint.Align.CENTER; paint.typeface = Typeface.DEFAULT_BOLD; c.drawText("F", x, y + 6f, paint)
                paint.typeface = Typeface.DEFAULT
            }
            if (lightOn) {
                val x = lightX * width; val y = lightY * bottom
                paint.color = Color.rgb(230, 165, 15); c.drawCircle(x, y, 39f, paint)
                paint.color = Color.rgb(255, 222, 75); c.drawCircle(x, y, 22f, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = Color.argb(130, 235, 180, 20)
                c.drawCircle(x, y, 54f, paint); paint.style = Paint.Style.FILL
            }
            if (dangerOn) {
                val x = dangerX * width; val y = dangerY * bottom
                paint.color = Color.rgb(205, 42, 42); c.drawCircle(x, y, 36f, paint)
                paint.color = Color.WHITE; paint.textSize = 35f; paint.textAlign = Paint.Align.CENTER; paint.typeface = Typeface.DEFAULT_BOLD; c.drawText("!", x, y + 12f, paint); paint.typeface = Typeface.DEFAULT
            }
        }

        private fun drawBrainPanel(c: Canvas) {
            val panelH = brainPanelHeight()
            val top = height - panelH
            paint.color = Color.rgb(25, 29, 31)
            c.drawRect(8f, top, width.toFloat() - 8f, height.toFloat(), paint)
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = Color.WHITE
            paint.textSize = 19f
            c.drawText("ACTIVIDAD DEL CEREBRO", 22f, top + 27f, paint)

            drawActivityBar(c, "SENSORIAL", sensoryDisplay, top + 39f, Color.rgb(52, 195, 110))
            drawActivityBar(c, "INTEGRACIÓN", interDisplay, top + 75f, Color.rgb(75, 145, 225))
            drawActivityBar(c, "MOTOR", motorDisplay, top + 111f, Color.rgb(225, 160, 45))

            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = Color.rgb(225, 225, 225)
            paint.textSize = 13f
            c.drawText("FLUJO NEURONAL", 22f, top + 150f, paint)
            drawFlowNode(c, "SENSORES", flowSensor, 22f, top + 160f, 104f)
            drawFlowArrow(c, 130f, top + 183f)
            drawFlowNode(c, "INTEGRA", flowInter, 155f, top + 160f, 104f)
            drawFlowArrow(c, 263f, top + 183f)
            drawFlowNode(c, "MOTOR", flowMotor, 288f, top + 160f, 104f)
            drawFlowArrow(c, 396f, top + 183f)
            drawFlowNode(c, "ESTADO", flowState, 421f, top + 160f, max(90f, width - 443f))

            val gridTop = top + 203f
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = Color.rgb(225, 225, 225)
            paint.textSize = 13f
            c.drawText("NEURONAS ACTIVAS · muestra de 192 unidades", 22f, gridTop + 13f, paint)
            drawNeuronGrid(c, 22f, gridTop + 23f, width - 44f, max(40f, panelH - 232f))

            paint.typeface = Typeface.DEFAULT
            paint.color = Color.rgb(205, 205, 205)
            paint.textSize = 12f
            c.drawText("Objetivo: ${when(selectedStimulus) { 0 -> "COMIDA"; 1 -> "LUZ"; else -> "PELIGRO" }} · arrastra el estímulo", 22f, height - 9f, paint)
        }

        private fun drawActivityBar(c: Canvas, label: String, value: Float, y: Float, accent: Int) {
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = Color.rgb(235, 235, 235)
            paint.textSize = 14f
            c.drawText(label, 22f, y + 16f, paint)
            val left = 126f
            val right = width - 74f
            paint.color = Color.rgb(62, 67, 70)
            c.drawRoundRect(left, y, right, y + 22f, 8f, 8f, paint)
            paint.color = accent
            c.drawRoundRect(left, y, left + (right - left) * value.coerceIn(0f, 1f), y + 22f, 8f, 8f, paint)
            paint.color = Color.WHITE
            paint.textSize = 14f
            c.drawText("${(value * 100f).toInt()}%", right + 8f, y + 17f, paint)
        }

        private fun drawFlowNode(c: Canvas, label: String, value: Float, x: Float, y: Float, w: Float) {
            paint.color = Color.rgb(53, 58, 61)
            c.drawRoundRect(x, y, x + w, y + 46f, 9f, 9f, paint)
            paint.color = Color.rgb(245, 245, 245)
            paint.textSize = 11f
            paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText(label, x + 8f, y + 17f, paint)
            paint.color = Color.rgb(82, 195, 120)
            c.drawRoundRect(x + 8f, y + 25f, x + 8f + (w - 16f) * value.coerceIn(0f, 1f), y + 36f, 5f, 5f, paint)
        }

        private fun drawFlowArrow(c: Canvas, x: Float, y: Float) {
            paint.color = Color.rgb(130, 135, 138)
            paint.strokeWidth = 3f
            paint.style = Paint.Style.STROKE
            c.drawLine(x, y, x + 15f, y, paint)
            c.drawLine(x + 15f, y, x + 10f, y - 5f, paint)
            c.drawLine(x + 15f, y, x + 10f, y + 5f, paint)
            paint.style = Paint.Style.FILL
        }

        private fun drawNeuronGrid(c: Canvas, x: Float, y: Float, w: Float, h: Float) {
            val cols = 32
            val rows = 6
            val cellW = w / cols
            val cellH = h / rows
            for (r in 0 until rows) {
                for (col in 0 until cols) {
                    val idx = when (r) {
                        0 -> col % 48
                        1 -> 48 + (col * 6) % 200
                        2 -> 248 + (col * 6) % 200
                        3 -> 448 + (col * 6) % 200
                        4 -> 648 + (col * 10) % 632
                        else -> 1280 + (col * 8) % 256
                    }
                    val active = fired[idx]
                    val value = if (active) 1f else ((v[idx] + .72f) / .76f).coerceIn(0f, 1f) * .28f
                    paint.color = if (active) Color.rgb(245, 235, 80) else Color.rgb(70 + (value * 45f).toInt(), 74 + (value * 45f).toInt(), 77 + (value * 45f).toInt())
                    val l = x + col * cellW + 1f
                    val t = y + r * cellH + 1f
                    c.drawRoundRect(l, t, l + cellW - 2f, t + cellH - 2f, 3f, 3f, paint)
                }
            }
            paint.color = Color.rgb(160, 165, 168)
            paint.textSize = 10f
            paint.typeface = Typeface.DEFAULT
            c.drawText("sensor", x, y + h + 11f, paint)
            c.drawText("integración", x + w * .30f, y + h + 11f, paint)
            c.drawText("motor", x + w * .84f, y + h + 11f, paint)
        }

        // Larger, more recognizable Drosophila-like silhouette with wings,
        // segmented abdomen, compound eyes, antennae and six legs.
        private fun drawFly(c: Canvas, px: Float, py: Float, angle: Float) {
            c.save()
            c.rotate(Math.toDegrees(angle.toDouble()).toFloat(), px, py)
            paint.style = Paint.Style.FILL

            // Shadow / body contact.
            paint.color = Color.argb(45, 0, 0, 0)
            c.drawOval(px - 42f, py + 13f, px + 36f, py + 26f, paint)

            // Six articulated legs.
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = 3.2f
            paint.color = Color.rgb(48, 40, 37)
            val ys = floatArrayOf(-13f, 0f, 13f)
            for (yy in ys) {
                c.drawLine(px - 8f, py + yy, px - 31f, py + yy - 15f, paint)
                c.drawLine(px - 31f, py + yy - 15f, px - 47f, py + yy - 1f, paint)
                c.drawLine(px + 4f, py + yy, px + 29f, py + yy - 15f, paint)
                c.drawLine(px + 29f, py + yy - 15f, px + 46f, py + yy - 1f, paint)
            }

            // Transparent wings with veins.
            paint.color = Color.argb(110, 184, 210, 226)
            c.drawOval(px - 14f, py - 55f, px + 31f, py - 5f, paint)
            c.drawOval(px - 14f, py + 5f, px + 31f, py + 55f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.2f
            paint.color = Color.argb(155, 105, 135, 155)
            c.drawOval(px - 14f, py - 55f, px + 31f, py - 5f, paint)
            c.drawOval(px - 14f, py + 5f, px + 31f, py + 55f, paint)
            c.drawLine(px + 1f, py - 51f, px + 18f, py - 10f, paint)
            c.drawLine(px + 1f, py + 51f, px + 18f, py + 10f, paint)
            paint.style = Paint.Style.FILL

            // Abdomen with alternating dark/golden segments.
            paint.color = Color.rgb(49, 45, 43)
            c.drawOval(px - 42f, py - 18f, px + 12f, py + 18f, paint)
            val bands = floatArrayOf(-31f, -20f, -9f, 2f)
            for (x in bands) {
                paint.color = Color.rgb(132, 103, 73)
                c.drawRect(px + x, py - 17f, px + x + 5f, py + 17f, paint)
            }
            paint.color = Color.rgb(33, 31, 30)
            c.drawOval(px - 1f, py - 19f, px + 19f, py + 19f, paint)

            // Thorax and head.
            paint.color = Color.rgb(68, 61, 57)
            c.drawCircle(px + 18f, py, 15f, paint)
            paint.color = Color.rgb(52, 46, 44)
            c.drawCircle(px + 31f, py, 13f, paint)
            paint.color = Color.rgb(142, 34, 31)
            c.drawCircle(px + 37f, py - 7f, 8f, paint)
            c.drawCircle(px + 37f, py + 7f, 8f, paint)
            paint.color = Color.rgb(225, 82, 64)
            c.drawCircle(px + 39f, py - 8f, 2.3f, paint)
            c.drawCircle(px + 39f, py + 6f, 2.3f, paint)

            // Antennae.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = Color.rgb(52, 43, 40)
            c.drawLine(px + 37f, py - 7f, px + 52f, py - 22f, paint)
            c.drawLine(px + 37f, py + 7f, px + 52f, py + 22f, paint)
            paint.style = Paint.Style.FILL
            c.drawCircle(px + 53f, py - 23f, 2.2f, paint)
            c.drawCircle(px + 53f, py + 23f, 2.2f, paint)
            c.restore()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    if (e.y < sceneBottom()) {
                        draggingStimulus = true
                        moveStimulus(e.x / width.toFloat(), e.y / sceneBottom())
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    draggingStimulus = false
                    return true
                }
            }
            return true
        }

        private fun moveStimulus(xRaw: Float, yRaw: Float) {
            val x = xRaw.coerceIn(.06f, .94f)
            val y = yRaw.coerceIn(.10f, .82f)
            when (selectedStimulus) {
                0 -> { foodX = x; foodY = y }
                1 -> { lightX = x; lightY = y }
                else -> { dangerX = x; dangerY = y }
            }
        }
    }
}
