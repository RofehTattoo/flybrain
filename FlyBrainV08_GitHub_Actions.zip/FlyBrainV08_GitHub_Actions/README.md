# FlyBrain V0.8

Evolución del prototipo de cerebro artificial de mosca, centrada en observabilidad neuronal, comportamiento diferenciado, memoria y plasticidad, manteniendo una arquitectura móvil ligera.

- 1.536 neuronas LIF con adaptación.
- 48 neuronas sensoriales: 16 comida, 16 luz, 16 peligro.
- 1.232 neuronas de integración/recurrentes en módulos funcionales.
- 256 neuronas motoras/estado.
- Vías estructuradas sensoriales → integración → motor, sin sustituir el controlador neuronal por reglas directas de movimiento.
- Respuestas diferenciadas a comida/luz/peligro y vía rápida de escape.
- Plasticidad Hebbiana modulada por recompensa sobre conexiones de integración/motor, con límites estables y memoria sináptica persistente durante la simulación.
- Panel cerebral grande y de alto contraste, protegido de la navegación Android mediante WindowInsets.
- Porcentajes visibles de actividad sensorial, integración y motor.
- Diagrama de flujo SENSORES → INTEGRA → MOTOR → ESTADO.
- Matriz visual de 192 neuronas representativas para observar actividad individual.
- Estado interno visible: saciedad, memoria, comidas, escapes y FPS.
- Mosca más grande y detallada: abdomen segmentado, tórax, cabeza, ojos compuestos, alas con venación, seis patas y antenas.
- Locomoción con velocidad suavizada, giro, aproximación, frenado, exploración y respuesta de escape.
- Controles superiores accesibles; pulsar un estímulo lo selecciona y lo activa/desactiva; arrastrar en el escenario mueve el estímulo seleccionado.
- RESET restaura también los pesos aprendidos y el estado interno.
