FlyBrain V0.92

Reduced MaleCNS-informed model with exactly 16,669 simulated neurons (10% of the published 166,691-neuron MaleCNS census). This is a stratified computational reduction, not a literal random 10% subset: functional classes and bilateral pathways are preserved so the model remains computationally tractable.

Source: Berg et al., Cell (2026), MaleCNS v1.0, CC-BY. The simulator uses the published neuron census and reported functional organization as constraints; it does not claim to reproduce the full biological connectome or biological membrane dynamics.
