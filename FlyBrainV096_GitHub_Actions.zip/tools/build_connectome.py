#!/usr/bin/env python3
"""Build a deterministic 16,669-neuron MaleCNS v1.0 reduction.

The reduction is derived from the published MaleCNS v1.0 annotation and weighted
connectivity tables. It keeps exactly 10% of the 166,691-neuron census by
stratifying on the published superclass and selecting the highest-connectivity
cells within each superclass. Only published edges between retained neurons
are embedded; no graph edge is invented here.
"""
from __future__ import annotations

import json
import math
import struct
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.ipc as ipc

BASE = "https://storage.googleapis.com/flyem-male-cns/v1.0/connectome-data/flat-connectome/"
TARGET = 16669
FILES = {
    "annotations": "body-annotations-male-cns-v1.0-minconf-0.5.feather",
    "neurotransmitters": "body-neurotransmitters-male-cns-v1.0.feather",
    "weights": "connectome-weights-male-cns-v1.0-minconf-0.5.feather",
}

NT_SIGN = {
    "acetylcholine": 1.0,
    "ach": 1.0,
    "gaba": -1.0,
    "gamma-aminobutyric acid": -1.0,
    "glutamate": -1.0,
}

SUPERCLASS_CODE = {}

def download(path: Path, name: str) -> None:
    if path.exists() and path.stat().st_size > 0:
        return
    url = BASE + name
    tmp = path.with_suffix(path.suffix + ".partial")
    print(f"Downloading {name} ...", flush=True)
    urllib.request.urlretrieve(url, tmp)
    tmp.replace(path)


def clean(x):
    if pd.isna(x):
        return ""
    return str(x)


def classify_channel(row) -> int:
    """0 visual, 1 olfactory, 2 gustatory, 3 mechanosensory/proprioceptive, 4 other."""
    sc = clean(row.get("superclass", ""))
    cl = clean(row.get("class", "")).lower()
    sub = clean(row.get("subclass", "")).lower()
    typ = clean(row.get("type", "")).lower()
    text = " ".join((cl, sub, typ))
    if sc in {"ol_sensory", "visual_projection", "visual_centrifugal"}:
        return 0
    if "olf" in text or "antennal lobe" in text:
        return 1
    if "gust" in text or "taste" in text:
        return 2
    if sc in {"vnc_sensory", "sensory_ascending", "sensory_descending"}:
        return 3
    if sc.startswith("cb_sensory"):
        return 3
    return 4


def classify_motor_role(row) -> int:
    """Map curated VNC motor annotations to a body output category.
    0=non-motor, 1=leg, 2=wing, 3=haltere, 4=neck, 5=abdomen, 6=jump, 7=other.
    This uses published annotation text, never the runtime neuron index.
    """
    sc = clean(row.get("superclass", ""))
    if sc != "vnc_motor":
        return 0
    fields = []
    for c in ("type", "class", "subclass", "primary_neuropil", "nerve", "target", "muscle", "annotation"):
        if c in row.index:
            fields.append(clean(row.get(c, "")))
    text = " ".join(fields).lower()
    if any(k in text for k in ("tergotrochanteral", "jump", "ttmn")):
        return 6
    if any(k in text for k in ("haltere", "halter")):
        return 3
    if any(k in text for k in ("wing", "dvm", "dlm", "flight", "steering")):
        return 2
    if any(k in text for k in ("neck", "cervical")):
        return 4
    if any(k in text for k in ("abdominal", "abdomen", "abdominal")):
        return 5
    if any(k in text for k in ("leg", "t1", "t2", "t3", "coxa", "femur", "tibia", "tars", "trochanter", "levator", "depressor", "flexor", "extensor")):
        return 1
    return 7


def main(root: Path) -> None:
    raw = root / "build" / "malecns_raw"
    raw.mkdir(parents=True, exist_ok=True)
    for key, name in FILES.items():
        download(raw / name, name)

    annotations = pd.read_feather(raw / FILES["annotations"])
    if "status" in annotations.columns:
        traced = annotations[annotations["status"].astype(str).str.lower().eq("traced")].copy()
    else:
        traced = annotations.copy()
    traced = traced[traced["superclass"].notna()].copy()
    traced["bodyId"] = traced["bodyId"].astype(np.int64)
    traced = traced.drop_duplicates("bodyId").sort_values("bodyId").reset_index(drop=True)
    if len(traced) < TARGET:
        raise RuntimeError(f"Only {len(traced)} traced annotated neurons available; expected >= {TARGET}")

    ids = traced["bodyId"].to_numpy(np.int64)
    degree = np.zeros(len(ids), dtype=np.float64)

    # One streaming pass over the 1.1 GB weighted graph to measure connectivity.
    weights_path = raw / FILES["weights"]
    reader = ipc.open_file(pa.memory_map(str(weights_path), "r"))
    for bi in range(reader.num_record_batches):
        b = reader.get_batch(bi)
        pre = b.column(b.schema.get_field_index("body_pre")).to_numpy(zero_copy_only=False).astype(np.int64)
        post = b.column(b.schema.get_field_index("body_post")).to_numpy(zero_copy_only=False).astype(np.int64)
        w = b.column(b.schema.get_field_index("weight")).to_numpy(zero_copy_only=False).astype(np.float64)
        pi = np.searchsorted(ids, pre)
        po = np.searchsorted(ids, post)
        pv = (pi < len(ids)) & (ids[np.minimum(pi, len(ids)-1)] == pre)
        qv = (po < len(ids)) & (ids[np.minimum(po, len(ids)-1)] == post)
        if pv.any(): np.add.at(degree, pi[pv], w[pv])
        if qv.any(): np.add.at(degree, po[qv], w[qv])
        if bi % 50 == 0:
            print(f"degree pass batch {bi}/{reader.num_record_batches}", flush=True)

    traced["degree"] = degree
    counts = traced.groupby("superclass", sort=True).size().to_dict()
    total = len(traced)

    # Selection strategy for V0.96:
    # 1) retain every curated descending neuron and every curated VNC motor neuron;
    # 2) retain at least one representative of every published neuron type;
    # 3) fill the remaining slots proportionally across superclasses, using
    #    weighted connectivity as the deterministic ranking.
    forced = traced[traced["superclass"].astype(str).isin({"descending_neuron", "vnc_motor"})].copy()

    type_col = "type" if "type" in traced.columns else None
    if type_col is None:
        traced["type"] = traced["bodyId"].astype(str)
        type_col = "type"
    traced[type_col] = traced[type_col].fillna("").astype(str)

    type_rep = (traced.sort_values(["degree", "bodyId"], ascending=[False, True])
                      .drop_duplicates(["superclass", type_col], keep="first"))
    seed = pd.concat([forced, type_rep], ignore_index=True).drop_duplicates("bodyId")

    if len(seed) > TARGET:
        # This should not occur with the current MaleCNS census, but keeps the
        # build deterministic if annotation counts change in a future release.
        forced = forced.drop_duplicates("bodyId")
        remaining_type = (type_rep[~type_rep.bodyId.isin(set(forced.bodyId))]
                          .sort_values(["degree", "bodyId"], ascending=[False, True]))
        seed = pd.concat([forced, remaining_type.head(max(0, TARGET - len(forced)))], ignore_index=True).drop_duplicates("bodyId")

    remaining_slots = TARGET - len(seed)
    if remaining_slots < 0:
        raise AssertionError(("seed exceeds target", len(seed), TARGET))

    seed_ids = set(seed.bodyId.astype(int).tolist())
    pool = traced[~traced.bodyId.isin(seed_ids)].copy()
    pool_counts = pool.groupby("superclass", sort=True).size().to_dict()
    raw_extra = {sc: n * remaining_slots / max(1, len(pool)) for sc, n in pool_counts.items()}
    extra_quota = {sc: int(math.floor(q)) for sc, q in raw_extra.items()}

    while sum(extra_quota.values()) < remaining_slots:
        candidates = [sc for sc in pool_counts if extra_quota[sc] < pool_counts[sc]]
        if not candidates:
            break
        sc = max(candidates, key=lambda x: (raw_extra[x] - extra_quota[x], x))
        extra_quota[sc] += 1

    while sum(extra_quota.values()) > remaining_slots:
        sc = max(extra_quota, key=lambda x: (extra_quota[x], x))
        extra_quota[sc] -= 1

    extras = []
    for sc, group in pool.groupby("superclass", sort=True):
        n = min(extra_quota.get(sc, 0), len(group))
        if n:
            extras.append(group.sort_values(["degree", "bodyId"], ascending=[False, True]).head(n))

    selected = pd.concat([seed] + extras, ignore_index=True).drop_duplicates("bodyId")

    if len(selected) < TARGET:
        selected_ids_now = set(selected.bodyId.astype(int).tolist())
        extra_pool = traced[~traced.bodyId.isin(selected_ids_now)]
        selected = pd.concat([
            selected,
            extra_pool.sort_values(["degree", "bodyId"], ascending=[False, True]).head(TARGET - len(selected))
        ], ignore_index=True)

    if len(selected) > TARGET:
        # Never discard a forced DN/MN or a type representative if avoidable.
        forced_ids = set(forced.bodyId.astype(int).tolist())
        keep_forced = selected[selected.bodyId.isin(forced_ids)]
        optional = selected[~selected.bodyId.isin(forced_ids)].sort_values(["degree", "bodyId"], ascending=[False, True])
        selected = pd.concat([keep_forced, optional.head(max(0, TARGET - len(keep_forced)))], ignore_index=True)

    selected = selected.drop_duplicates("bodyId").reset_index(drop=True)
    if len(selected) != TARGET:
        raise AssertionError((len(selected), TARGET))

    # Stable anatomical ordering: sensory channels first, then descending,
    # ascending, motor and the remaining central/intrinsic populations. This
    # gives the Android runtime contiguous anatomical readout blocks.
    selected["channel"] = selected.apply(classify_channel, axis=1)
    selected["motor_role"] = selected.apply(classify_motor_role, axis=1)
    def block(row):
        sc = str(row["superclass"])
        ch = int(row["channel"])
        if ch < 4:
            return ch
        if sc == "descending_neuron":
            return 4
        if sc == "ascending_neuron":
            return 5
        if sc == "vnc_motor":
            return 6
        return 7
    selected["block"] = selected.apply(block, axis=1)
    selected = selected.sort_values(["block", "superclass", "bodyId"]).reset_index(drop=True)
    selected_ids = selected["bodyId"].to_numpy(np.int64)
    selected_set = set(int(x) for x in selected_ids)
    index = {int(b): i for i, b in enumerate(selected_ids)}

    # Neurotransmitter predictions provide the sign model used by the simulator.
    nt = pd.read_feather(raw / FILES["neurotransmitters"])
    nt_cols = [c for c in ["body", "bodyId"] if c in nt.columns]
    nt_id_col = nt_cols[0] if nt_cols else None
    nt["_id"] = nt[nt_id_col].astype(np.int64) if nt_id_col else -1
    nt_name = None
    for c in ["consensus_nt", "predicted_nt", "celltype_predicted_nt"]:
        if c in nt.columns:
            nt_name = c
            break
    nt_map = dict(zip(nt["_id"].tolist(), nt[nt_name].astype(str).str.strip().str.lower().tolist())) if nt_name else {}

    # Second streaming pass: retain only published edges between selected neurons.
    edges = []
    contacts = 0
    for bi in range(reader.num_record_batches):
        b = reader.get_batch(bi)
        pre = b.column(b.schema.get_field_index("body_pre")).to_numpy(zero_copy_only=False).astype(np.int64)
        post = b.column(b.schema.get_field_index("body_post")).to_numpy(zero_copy_only=False).astype(np.int64)
        w = b.column(b.schema.get_field_index("weight")).to_numpy(zero_copy_only=False).astype(np.int64)
        mask = np.isin(pre, selected_ids) & np.isin(post, selected_ids) & (w > 0)
        if mask.any():
            for a, c, d in zip(pre[mask], post[mask], w[mask]):
                sign = NT_SIGN.get(nt_map.get(int(a), ""), 0.0)
                # Unknown/modulatory transmitter retains the edge but contributes no direct current.
                if sign == 0.0:
                    continue
                edges.append((index[int(a)], index[int(c)], float(d) * sign))
                contacts += int(d)
        if bi % 50 == 0:
            print(f"edge pass batch {bi}/{reader.num_record_batches}", flush=True)

    # Convert raw synapse counts into dimensionless synaptic weights while
    # preserving the published topology and relative contact strengths.
    target_totals = np.zeros(TARGET, dtype=np.float64)
    for src, dst, raw_weight in edges:
        target_totals[dst] += abs(raw_weight)
    normalized_edges = []
    for src, dst, raw_weight in edges:
        denom = max(1.0, target_totals[dst])
        normalized_edges.append((src, dst, float(raw_weight) / denom * 0.42))
    edges = normalized_edges
    edges.sort(key=lambda e: (e[1], e[0]))

    # Metadata/ranges used by the Android sensor interface and brain display.
    channel = selected["channel"].to_numpy(np.int8)
    ranges = {}
    for code, name in [(0,"visual"),(1,"olfactory"),(2,"gustatory"),(3,"mechanosensory"),(4,"other")]:
        idxs = np.where(channel == code)[0]
        ranges[name] = [int(idxs.min()), int(idxs.max()+1)] if len(idxs) else [0,0]

    sc_list = sorted(selected["superclass"].astype(str).unique().tolist())
    SUPERCLASS_CODE.update({s:i for i,s in enumerate(sc_list)})

    # Compact binary: header, neuron records, edge records.
    out = root / "app" / "src" / "main" / "res" / "raw" / "malecns_reduced.bin"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("wb") as f:
        f.write(b"FBC96\0\0\0")
        f.write(struct.pack("<II", TARGET, len(edges)))
        for i, row in selected.iterrows():
            body = int(row.bodyId)
            sc = SUPERCLASS_CODE[str(row.superclass)]
            side = 1 if clean(row.get("somaSide", "")) == "R" else (-1 if clean(row.get("somaSide", "")) == "L" else 0)
            ch = int(channel[i])
            f.write(struct.pack("<qbbbb", body, sc, side, ch, int(row.motor_role)))
        for src, dst, weight in edges:
            f.write(struct.pack("<iif", int(src), int(dst), float(weight)))

    # Compile-time ranges for the anatomical superclasses.
    def superclass_range(name):
        idxs = np.where(selected["superclass"].astype(str).to_numpy() == name)[0]
        return (int(idxs.min()), int(idxs.max()+1)) if len(idxs) else (0,0)
    desc = superclass_range("descending_neuron")
    asc = superclass_range("ascending_neuron")
    vmotor = superclass_range("vnc_motor")
    vsens = superclass_range("vnc_sensory")
    other_idx = np.where(selected["block"].to_numpy() == 7)[0]
    other = (int(other_idx.min()), int(other_idx.max()+1)) if len(other_idx) else (0,0)

    # Generate compile-time metadata so the Kotlin app does not hard-code ranges.
    meta = root / "app" / "src" / "main" / "java" / "com" / "example" / "flybrain" / "GeneratedConnectomeMeta.kt"
    motor_role_counts = {int(k): int(v) for k, v in selected.groupby("motor_role").size().to_dict().items()}

    meta.write_text("""package com.example.flybrain\n\nobject GeneratedConnectomeMeta {\n    const val VERSION = \"MaleCNS v1.0\"\n    const val NEURONS = %d\n    const val EDGES = %d\n    const val CONTACTS_RETAINED = %dL\n    const val VIS_START = %d\n    const val VIS_END = %d\n    const val OLF_START = %d\n    const val OLF_END = %d\n    const val GUST_START = %d\n    const val GUST_END = %d\n    const val MECH_START = %d\n    const val MECH_END = %d\n    const val DESC_START = %d\n    const val DESC_END = %d\n    const val ASC_START = %d\n    const val ASC_END = %d\n    const val VMOTOR_START = %d\n    const val VMOTOR_END = %d\n    const val VSENS_START = %d\n    const val VSENS_END = %d\n    const val OTHER_START = %d\n    const val OTHER_END = %d\n    const val MOTOR_LEG = 1\n    const val MOTOR_WING = 2\n    const val MOTOR_HALTERE = 3\n    const val MOTOR_NECK = 4\n    const val MOTOR_ABDOMEN = 5\n    const val MOTOR_JUMP = 6\n    const val MOTOR_OTHER = 7\n}\n""" % (TARGET, len(edges), contacts,
       ranges["visual"][0], ranges["visual"][1], ranges["olfactory"][0], ranges["olfactory"][1],
       ranges["gustatory"][0], ranges["gustatory"][1], ranges["mechanosensory"][0], ranges["mechanosensory"][1],
       desc[0], desc[1], asc[0], asc[1], vmotor[0], vmotor[1], vsens[0], vsens[1], other[0], other[1]))

    report = {
        "dataset": "MaleCNS v1.0",
        "selection": "exactly 16,669 traced annotated neurons; all descending and VNC motor neurons are retained, every published neuron type is represented where possible, and remaining quota is filled proportionally by superclass with connectivity ranking",
        "source": BASE,
        "neurons_source": int(total),
        "neurons_retained": TARGET,
        "edges_retained": len(edges),
        "contacts_retained_signed": contacts,
        "superclass_counts_source": {str(k): int(v) for k,v in counts.items()},
        "superclass_extra_quota": {str(k): int(v) for k,v in extra_quota.items()},
        "channel_ranges": ranges,
        "edge_signs": NT_SIGN,
        "unknown_modulatory_edges": "retained in source but omitted from direct-current graph when transmitter sign is unresolved",
        "motor_role_counts": motor_role_counts,
        "motor_role_definition": "derived from curated annotation text for vnc_motor cells; runtime movement is driven only by measured vnc_motor activity",
        "license": "CC-BY-4.0",
        "download": "https://male-cns.janelia.org/download/",
        "paper": "Berg et al., Cell 2026, DOI 10.1016/j.cell.2026.08.015",
    }
    (root / "app" / "src" / "main" / "res" / "raw" / "malecns_reduced_report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2), flush=True)

if __name__ == "__main__":
    main(Path(__file__).resolve().parents[1])
