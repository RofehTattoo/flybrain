package com.example.flybrain

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(FlyView())
    }

    inner class FlyView : View(this) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rng = Random(7)

        // V0.2: 64 leaky integrate-and-fire neurons.
        // 0..7 sensory, 8..47 recurrent/interneurons, 48..63 motor/value.
        private val n = 64
        private val v = FloatArray(n)
        private val spike = BooleanArray(n)
        private val input = FloatArray(n)
        private val weights = Array(n) { FloatArray(n) }

        private var x = 0.50f
        private var y = 0.55f
        private var angle = 0f
        private var foodX = 0.78f
        private var foodY = 0.32f
        private var reward = 0f
        private var age = 0f
        private var last = System.nanoTime()
        private var fps = 60f

        init {
            p.typeface = Typeface.create("sans", Typeface.NORMAL)
            setBackgroundColor(Color.rgb(245, 245, 245))
            for (i in 0 until n) {
                for (j in 0 until n) {
                    // Sparse, deterministic recurrent network.
                    val r = rng.nextFloat()
                    if (i != j && r < 0.075f) {
                        weights[i][j] = (rng.nextFloat() * 2f - 1f) * 0.55f
                    }
                }
            }
            for (i in 0 until n) v[i] = -0.65f
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)

            val now = System.nanoTime()
            val rawDt = (now - last) / 1e9
            val dt = min(0.033, max(0.001, rawDt)).toFloat()
            last = now
            fps = fps * 0.95f + (1f / dt) * 0.05f
            age += dt

            senseWorld()
            stepNetwork(dt)
            driveBody(dt)

            drawWorld(c)
            drawFly(c, x * width, y * height, angle)
            postInvalidateOnAnimation()
        }

        private fun senseWorld() {
            java.util.Arrays.fill(input, 0f)

            val dx = foodX - x
            val dy = foodY - y
            val dist = hypot(dx, dy)
            val target = atan2(dy, dx)
            val err = atan2(sin(target - angle), cos(target - angle))

            // Eight sensory channels: near/far, left/right, alignment,
            // plus weak noise. These feed the spiking network.
            input[0] = (1f - (dist / 0.8f)).coerceIn(0f, 1f)
            input[1] = ((-err + 1.2f) / 2.4f).coerceIn(0f, 1f)
            input[2] = (( err + 1.2f) / 2.4f).coerceIn(0f, 1f)
            input[3] = if (dist < 0.10f) 1f else 0f
            input[4] = if (x < foodX) 1f else 0f
            input[5] = if (y < foodY) 1f else 0f
            input[6] = (sin(age * 1.7f) * 0.5f + 0.5f) * 0.15f
            input[7] = rng.nextFloat() * 0.08f
        }

        private fun stepNetwork(dt: Float) {
            // LIF dynamics: membrane leaks toward rest; weighted spikes add current.
            for (i in 0 until n) {
                var current = input[i] * 0.95f
                for (j in 0 until n) {
                    if (spike[j]) current += weights[i][j]
                }

                v[i] += ((-0.65f - v[i]) * 3.0f + current) * dt

                // Tiny spontaneous activity keeps the network alive.
                if (i >= 8 && rng.nextFloat() < 0.012f) v[i] += 0.20f

                spike[i] = v[i] > 0.20f
                if (spike[i]) v[i] = -0.78f
            }

            // A small reward trace reinforces activity when food is reached.
            if (reward > 0f) {
                for (i in 0 until n) {
                    for (j in 0 until n) {
                        if (spike[i] && spike[j] && weights[i][j] != 0f) {
                            weights[i][j] = (weights[i][j] + 0.0035f)
                                .coerceIn(-0.8f, 0.8f)
                        }
                    }
                }
                reward *= 0.92f
            }
        }

        private fun driveBody(dt: Float) {
            // Motor population: left/right turning, forward drive, braking.
            var left = 0f
            var right = 0f
            var forward = 0f
            var brake = 0f

            for (i in 48..51) if (spike[i]) left += 1f
            for (i in 52..55) if (spike[i]) right += 1f
            for (i in 56..59) if (spike[i]) forward += 1f
            for (i in 60..63) if (spike[i]) brake += 1f

            val turn = ((right - left) * 0.08f)
            angle += turn

            val baseSpeed = 0.035f + forward * 0.004f
            val speed = baseSpeed * (1f - brake * 0.02f)
            x += cos(angle) * speed * dt * 8f
            y += sin(angle) * speed * dt * 8f

            if (x < 0.05f || x > 0.95f) {
                angle = Math.PI.toFloat() - angle
                x = x.coerceIn(0.05f, 0.95f)
            }
            if (y < 0.12f || y > 0.94f) {
                angle = -angle
                y = y.coerceIn(0.12f, 0.94f)
            }

            val dist = hypot(foodX - x, foodY - y)
            if (dist < 0.055f) {
                reward = 1f
                foodX = 0.10f + rng.nextFloat() * 0.80f
                foodY = 0.18f + rng.nextFloat() * 0.70f
            }
        }

        private fun drawWorld(c: Canvas) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f
            p.color = Color.LTGRAY
            c.drawRect(18f, 18f, width - 18f, height - 18f, p)

            p.style = Paint.Style.FILL
            p.color = Color.rgb(60, 170, 80)
            c.drawCircle(foodX * width, foodY * height, 14f, p)

            p.color = Color.DKGRAY
            p.textSize = 18f
            c.drawText("FLYBRAIN V0.2", 28f, 48f, p)
            p.textSize = 12f
            c.drawText("64 neuronas LIF · red recurrente · aprendizaje simple", 28f, 68f, p)

            val active = spike.count { it }
            p.textSize = 12f
            c.drawText("spikes: $active / $n     FPS: ${fps.toInt()}", 28f, 88f, p)

            val baseY = height - 34f
            p.color = Color.DKGRAY
            p.textSize = 12f
            c.drawText("actividad neuronal", 28f, baseY - 58f, p)

            val groups = intArrayOf(8, 40, 16)
            val labels = arrayOf("S", "R", "M")
            var index = 0
            var bx = 30f
            for (g in groups.indices) {
                for (k in 0 until groups[g]) {
                    val activeBar = if (spike[index]) 1f else ((v[index] + 0.78f) / 0.98f).coerceIn(0f, 1f)
                    p.color = if (spike[index]) Color.BLACK else Color.LTGRAY
                    c.drawRect(bx, baseY - activeBar * 45f, bx + 7f, baseY, p)
                    bx += 9f
                    index++
                }
                p.color = Color.DKGRAY
                p.textSize = 10f
                c.drawText(labels[g], bx + 2f, baseY + 14f, p)
                bx += 10f
            }

            p.textSize = 11f
            c.drawText("Toca la pantalla para mover la comida", 28f, height - 82f, p)
        }

        private fun drawFly(c: Canvas, px: Float, py: Float, a: Float) {
            c.save()
            c.rotate(Math.toDegrees(a.toDouble()).toFloat(), px, py)

            p.style = Paint.Style.FILL
            p.color = Color.rgb(35, 35, 35)
            c.drawOval(px - 18, py - 9, px + 18, py + 9, p)
            c.drawCircle(px + 15, py, 7f, p)

            p.color = Color.argb(150, 180, 210, 230)
            c.drawOval(px - 10, py - 25, px + 7, py - 3, p)
            c.drawOval(px - 10, py + 3, px + 7, py + 25, p)

            p.color = Color.WHITE
            c.drawCircle(px + 18, py - 3, 2.5f, p)
            c.drawCircle(px + 18, py + 3, 2.5f, p)

            c.restore()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
                foodX = (e.x / width).coerceIn(.06f, .94f)
                foodY = (e.y / height).coerceIn(.12f, .94f)
                return true
            }
            return true
        }
    }
}
