# FlyBrain V0.2

Primera evolución del prototipo.

- 64 neuronas artificiales tipo LIF (leaky integrate-and-fire)
- Red recurrente dispersa
- 8 canales sensoriales
- Población motora para giro, avance y frenado
- Ruido espontáneo
- Traza de recompensa con refuerzo Hebbiano muy simple
- Visualización de actividad neuronal
- Ejecutable como APK Android

Sigue siendo un modelo experimental simplificado, no el connectoma completo de Drosophila.
