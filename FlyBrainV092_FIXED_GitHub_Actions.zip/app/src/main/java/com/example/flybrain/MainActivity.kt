package com.example.flybrain

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247,247,247))
            clipToPadding = true
        }
        root.setOnApplyWindowInsetsListener { view, insets ->
            val bars = if (Build.VERSION.SDK_INT >= 30) insets.getInsets(WindowInsets.Type.systemBars()) else null
            val top = bars?.top ?: insets.systemWindowInsetTop
            val bottom = bars?.bottom ?: insets.systemWindowInsetBottom
            view.setPadding(0, top, 0, bottom)
            insets
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(6.dp(),5.dp(),6.dp(),5.dp()); setBackgroundColor(Color.rgb(226,226,226)) }
        fun makeButton(label:String)=Button(this).apply { text=label; textSize=14f; isAllCaps=false; minHeight=0; minWidth=0; setPadding(1.dp(),0,1.dp(),0) }
        val food=makeButton("COMIDA"); val light=makeButton("LUZ"); val danger=makeButton("PELIGRO"); val reset=makeButton("↻ RESET")
        val bh=62.dp()
        listOf(food,light,danger,reset).forEach { b -> controls.addView(b,LinearLayout.LayoutParams(0,bh,1f).apply{setMargins(2.dp(),0,2.dp(),0)}) }
        root.addView(controls,LinearLayout.LayoutParams(-1,72.dp()))
        val info=TextView(this).apply {
            setPadding(14.dp(),7.dp(),14.dp(),7.dp()); setTextColor(Color.rgb(28,28,28)); textSize=12f
            background=GradientDrawable().apply{setColor(Color.WHITE);setStroke(2.dp(),Color.rgb(145,145,145));cornerRadius=8.dp().toFloat()}
        }
        root.addView(info,LinearLayout.LayoutParams(-1,132.dp()).apply{setMargins(8.dp(),5.dp(),8.dp(),5.dp())})
        val sim=FlyView(info); root.addView(sim,LinearLayout.LayoutParams(-1,0,1f))
        fun refresh(){info.text=sim.infoText();sim.updateButtons()}
        food.setOnClickListener{sim.selectAndToggle(0);refresh()}; light.setOnClickListener{sim.selectAndToggle(1);refresh()}; danger.setOnClickListener{sim.selectAndToggle(2);refresh()}; reset.setOnClickListener{sim.resetSimulation();refresh()}
        sim.foodButton=food;sim.lightButton=light;sim.dangerButton=danger;sim.resetButton=reset
        setContentView(root);root.requestApplyInsets();refresh()
    }

    inner class FlyView(private val info:TextView):View(this){
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG); private val rng=Random(902)
        // V0.92: 10% population model of the published 166,691-neuron MaleCNS census.
        // This is a stratified, connectome-informed reduction rather than a literal random 10% node cut.
        private val N=16669
        private val SENSOR=1600
        private val OLFACTION_START=609
        private val GUSTATION_START=873
        private val MECH_START=1016
        private val CENTRAL_START=SENSOR
        private val KENYON_START=1600
        private val KENYON_END=2006
        private val ALPN_START=2006
        private val ALPN_END=2075
        private val CX_START=2075
        private val CX_END=2370
        private val DESC_START=2370
        private val DESC_END=2502
        private val MOTOR_START=2502
        private val MOTOR_END=2584
        private val INTEGRATION_START=2584
        private val INTEGRATION_END=N

        private val v=FloatArray(N){-0.72f}; private val adapt=FloatArray(N); private val fired=BooleanArray(N); private val prevFired=BooleanArray(N); private val refractory=FloatArray(N)
        private val incoming=Array(N){IntArray(0)}; private val incomingW=Array(N){FloatArray(0)}; private val baseW=Array(N){FloatArray(0)}; private val eligibility=Array(N){FloatArray(0)}
        var foodOn=true;var lightOn=false;var dangerOn=false;var selectedStimulus=0
        var foodButton:Button?=null;var lightButton:Button?=null;var dangerButton:Button?=null;var resetButton:Button?=null
        private var flyX=.24f;private var flyY=.55f;private var heading=-.15f;private var flySpeed=.002f
        private var foodX=.76f;private var foodY=.35f;private var lightX=.72f;private var lightY=.72f;private var dangerX=.30f;private var dangerY=.30f
        private var simTime=0f;private var lastNs=System.nanoTime();private var fps=60f;private var foodHits=0;private var escapeEvents=0;private var satiety=0f;private var memoryTrace=0f;private var lastReward=0f
        private var sensoryDisplay=0f;private var centralDisplay=0f;private var motorDisplay=0f;private var foodSignalDisplay=0f;private var lightSignalDisplay=0f;private var dangerSignalDisplay=0f
        private var visualFlow=0f;private var olfactoryFlow=0f;private var centralFlow=0f;private var motorFlow=0f;private var lastDangerLevel=0f
        private var leftMotor=0f;private var rightMotor=0f;private var forwardMotor=0f;private var escapeMotor=0f;private var brakeMotor=0f;private var exploreMotor=0f

        init{setBackgroundColor(Color.rgb(250,250,250));buildBrain()}
        fun infoText()=buildString{
            append("FLYBRAIN V0.92\n")
            append("16.669 neuronas · modelo reducido MaleCNS · LIF + adaptación + plasticidad\n")
            append("Población = 10% de 166.691 · visual · olfativa · gustativa · integración · VNC\n")
            append("Comida ${if(foodOn)"ON" else "OFF"} · Luz ${if(lightOn)"ON" else "OFF"} · Peligro ${if(dangerOn)"ON" else "OFF"}\n")
            append("Comidas $foodHits · Escapes $escapeEvents · Saciedad ${(satiety*100).toInt()}% · Memoria ${(memoryTrace*100).toInt()}% · FPS ${fps.toInt()}\n")
            append("Conducta: ${behaviorLabel()}")
        }
        private fun behaviorLabel()=when{escapeMotor>.10f->"ESCAPE";brakeMotor>.10f->"FRENO";rightMotor>leftMotor+.06f->"GIRO DERECHA";leftMotor>rightMotor+.06f->"GIRO IZQUIERDA";forwardMotor>.08f->"AVANCE";exploreMotor>.08f->"EXPLORACIÓN";else->"ESPERA / EXPLORACIÓN"}
        fun selectAndToggle(s:Int){if(selectedStimulus==s){when(s){0->foodOn=!foodOn;1->lightOn=!lightOn;else->dangerOn=!dangerOn}}else{selectedStimulus=s;when(s){0->foodOn=true;1->lightOn=true;else->dangerOn=true}};invalidate()}
        private fun styleButton(b:Button,active:Boolean,selected:Boolean,accent:Int){b.background=GradientDrawable().apply{cornerRadius=12.dp().toFloat();setColor(if(active)Color.rgb(232,246,235)else Color.rgb(245,245,245));setStroke(if(selected)4 else 1,if(selected)accent else Color.rgb(155,155,155))};b.alpha=if(active)1f else .68f}
        fun updateButtons(){foodButton?.let{it.text=if(foodOn)"COMIDA  ON" else "COMIDA";styleButton(it,foodOn,selectedStimulus==0,Color.rgb(35,120,70))};lightButton?.let{it.text=if(lightOn)"LUZ  ON" else "LUZ";styleButton(it,lightOn,selectedStimulus==1,Color.rgb(210,145,10))};dangerButton?.let{it.text=if(dangerOn)"PELIGRO  ON" else "PELIGRO";styleButton(it,dangerOn,selectedStimulus==2,Color.rgb(190,45,45))}}
        fun resetSimulation(){for(i in 0 until N){v[i]=-.72f;adapt[i]=0f;fired[i]=false;prevFired[i]=false;refractory[i]=0f;for(k in incomingW[i].indices){incomingW[i][k]=baseW[i][k];eligibility[i][k]=0f}};flyX=.24f;flyY=.55f;heading=-.15f;flySpeed=.002f;foodX=.76f;foodY=.35f;lightX=.72f;lightY=.72f;dangerX=.30f;dangerY=.30f;simTime=0f;foodHits=0;escapeEvents=0;satiety=0f;memoryTrace=0f;lastReward=0f;sensoryDisplay=0f;centralDisplay=0f;motorDisplay=0f;foodSignalDisplay=0f;lightSignalDisplay=0f;dangerSignalDisplay=0f;visualFlow=0f;olfactoryFlow=0f;centralFlow=0f;motorFlow=0f;leftMotor=0f;rightMotor=0f;forwardMotor=0f;escapeMotor=0f;brakeMotor=0f;exploreMotor=0f;lastDangerLevel=0f;lastNs=System.nanoTime();info.text=infoText();invalidate()}
        private fun addEdge(t:Int,s:Int,w:Float,l:Array<MutableList<Int>>,ws:Array<MutableList<Float>>){l[t].add(s);ws[t].add(w)}

        private fun buildBrain(){
            val l=Array(N){mutableListOf<Int>()};val ws=Array(N){mutableListOf<Float>()}
            // Stratified populations follow the published MaleCNS inventory: visual, olfactory,
            // gustatory, mechanosensory/proprioceptive, higher centres, descending and motor.
            // The 10% reduction preserves those functional classes and bilateral pathways.
            for(i in 0 until SENSOR){
                val group=when{i<609->0;i<873->1;i<1016->2;else->3}
                repeat(5){val src=i;val target=INTEGRATION_START+((i*37+it*101)% (N-INTEGRATION_START));val gain=when(group){0->.090f;1->.075f;2->.105f;else->.065f};addEdge(target,src,gain+(it*.004f),l,ws)}
            }
            // Bilateral higher-centre modules: Kenyon cells, antennal-lobe PNs, central-complex-like units.
            for(i in KENYON_START until KENYON_END) repeat(8){val s=SENSOR+((i*13+it*17)% (N-SENSOR));addEdge(i,s,.020f+(it%3)*.006f,l,ws)}
            for(i in ALPN_START until ALPN_END) repeat(10){val s=OLFACTION_START+((i*19+it*11)%264);addEdge(i,s,.055f,l,ws)}
            for(i in CX_START until CX_END) repeat(10){val s=INTEGRATION_START+((i*23+it*7)%6000);addEdge(i,s,if(i%2==0).028f else -.022f,l,ws)}
            // Large recurrent central network, deterministic pseudo-random graph from a fixed seed.
            for(i in INTEGRATION_START until N) repeat(8){var s=INTEGRATION_START+((i*1103515245+it*12345+902) ushr 4)% (N-INTEGRATION_START);if(s==i)s=INTEGRATION_START+((s+17)%(N-INTEGRATION_START));val sign=if(((i+it*7)%100)<66)1f else -1f;addEdge(i,s,sign*(.006f+((i*31+it*17)%100)/100f*.018f),l,ws)}
            // Descending population and VNC motor population are the behavioural bottleneck.
            for(i in DESC_START until DESC_END) repeat(14){val s=INTEGRATION_START+((i*29+it*31)% (N-INTEGRATION_START));addEdge(i,s,if(i%3==0)-.024f else .030f,l,ws)}
            for(i in MOTOR_START until MOTOR_END) repeat(18){val s=DESC_START+((i*17+it*13)%(DESC_END-DESC_START));addEdge(i,s,if(i%4==0)-.030f else .045f,l,ws)}
            // Six stable motor command pools. These are not direct stimulus rules; they are driven by descending activity.
            val pools=arrayOf(0 until 14,14 until 28,28 until 42,42 until 56,56 until 69,69 until 82)
            for((p,range) in pools.withIndex())for(i in range){val target=MOTOR_START+i;for(s in DESC_START until DESC_END step 4){val bias=when(p){0->if(s%2==0).060f else -.025f;1->if(s%2==1).060f else -.025f;2->.050f;3->if(s%5==0).080f else -.020f;4->if(s%7==0)-.060f else .025f;else->.035f};addEdge(target,s,bias,l,ws)}}
            for(i in 0 until N){incoming[i]=l[i].toIntArray();incomingW[i]=ws[i].toFloatArray();baseW[i]=incomingW[i].clone();eligibility[i]=FloatArray(incomingW[i].size)}
        }
        private fun signal(d:Float,r:Float)=exp((-(d*d)/(2f*r*r)).toDouble()).toFloat().coerceIn(0f,1f)
        private fun directional(dx:Float,dy:Float,ang:Float,side:Int):Float{val a=atan2(dy,dx);val e=atan2(sin(a-ang),cos(a-ang));return when(side){-1->(-e/(Math.PI.toFloat()/2f)).coerceIn(0f,1f);1->(e/(Math.PI.toFloat()/2f)).coerceIn(0f,1f);else->1f-(abs(e)/Math.PI.toFloat()).coerceIn(0f,1f)}}
        private fun encode(enabled:Boolean,sx:Float,sy:Float,base:Int,gain:Float):Float{if(!enabled)return 0f;val dx=sx-flyX;val dy=sy-flyY;val d=hypot(dx,dy);val prox=signal(d,.38f);val left=directional(dx,dy,heading,-1);val right=directional(dx,dy,heading,1);val front=directional(dx,dy,heading,0);val cur=floatArrayOf(left*gain,right*gain,front*gain,prox*gain,prox*front*gain,prox*left*gain,prox*right*gain,(1f-prox)*gain*.2f,front*(1f-prox)*gain*.15f,gain*.06f, left*prox*gain*.7f,right*prox*gain*.7f,front*prox*gain*.7f,prox*gain,front*gain*.5f, (1f-prox)*gain*.1f);for(k in cur.indices)v[base+k]+=cur[k];return(cur.sum()/(cur.size*gain)).coerceIn(0f,1f)}
        private fun sense(dt:Float){val f=encode(foodOn,foodX,foodY,0,1.5f*(1f-satiety*.55f));val li=encode(lightOn,lightX,lightY,609,1.35f);val da=encode(dangerOn,dangerX,dangerY,873,3.2f);foodSignalDisplay=.88f*foodSignalDisplay+.12f*f;lightSignalDisplay=.88f*lightSignalDisplay+.12f*li;dangerSignalDisplay=.88f*dangerSignalDisplay+.12f*da;for(i in 0 until SENSOR){v[i]-=adapt[i];adapt[i]*=exp((-dt*1.7f).toDouble()).toFloat()};visualFlow=.9f*visualFlow+.1f*(f+li*.7f);olfactoryFlow=.9f*olfactoryFlow+.1f*f*.35f;val dangerDrive=da*.8f;for(i in INTEGRATION_START until N step 5){v[i]+=((f*.035f)+(li*.028f)+(da*.055f))}}
        private fun stepBrain(dt:Float){for(i in 0 until N)prevFired[i]=fired[i];for(i in 0 until N){if(refractory[i]>0f){refractory[i]-=dt;fired[i]=false;continue};var syn=0f;val src=incoming[i];val w=incomingW[i];for(k in src.indices)if(prevFired[src[k]])syn+=w[k];v[i]+=((-.72f-v[i])*7f-adapt[i])*dt+syn*.72f;if(i>=INTEGRATION_START&&i%97==0)v[i]+=.008f;fired[i]=v[i]>=.035f;if(fired[i]){v[i]=-.84f;adapt[i]=min(.16f,adapt[i]+.028f);refractory[i]=.006f}}}
        private fun count(a:Int,b:Int):Int{var n=0;for(i in a until b)if(fired[i])n++;return n}
        private fun learn(reward:Float,dt:Float){val r=reward.coerceIn(-1f,1f);memoryTrace=(memoryTrace*exp((-dt*.045f).toDouble()).toFloat()+abs(r)*.025f).coerceIn(0f,1f);for(t in MOTOR_START until MOTOR_END){val s=incoming[t];val w=incomingW[t];val b=baseW[t];val e=eligibility[t];for(k in s.indices){val pre=if(prevFired[s[k]])1f else 0f;val post=if(fired[t])1f else 0f;e[k]=(e[k]*.997f+pre*post*.06f).coerceIn(-1f,1f);w[k]+=r*e[k]*dt*.25f;w[k]=w[k].coerceIn(min(b[k]*.6f,b[k]*1.4f),max(b[k]*.6f,b[k]*1.4f))}};lastReward=.94f*lastReward+.06f*r}
        private fun driveBody(dt:Float){
            val left=count(MOTOR_START,MOTOR_START+14);val right=count(MOTOR_START+14,MOTOR_START+28);val forward=count(MOTOR_START+28,MOTOR_START+42);val escape=count(MOTOR_START+42,MOTOR_START+56);val brake=count(MOTOR_START+56,MOTOR_START+69);val explore=count(MOTOR_START+69,MOTOR_START+82)
            // No stimulus->movement shortcut: all commands come from the motor population.
            val turn=(right-left)/14f;val cmdSpeed=(forward*.0018f+explore*.00055f-escape*.0025f-brake*.0018f).coerceIn(-.010f,.014f)
            heading+=turn*dt*2.8f;flySpeed=.92f*flySpeed+.08f*cmdSpeed;flyX+=cos(heading)*flySpeed*dt*30f;flyY+=sin(heading)*flySpeed*dt*30f
            if(flyX<.055f||flyX>.945f){heading=Math.PI.toFloat()-heading;flyX=flyX.coerceIn(.055f,.945f)};if(flyY<.10f||flyY>.79f){heading=-heading;flyY=flyY.coerceIn(.10f,.79f)}
            var reward=0f;val fd=hypot(foodX-flyX,foodY-flyY);if(foodOn&&fd<.065f){foodHits++;satiety=min(1f,satiety+.28f);reward+=1f;foodX=.08f+rng.nextFloat()*.84f;foodY=.14f+rng.nextFloat()*.58f}
            satiety*=exp((-dt*.018f).toDouble()).toFloat();val danger=if(dangerOn)signal(hypot(dangerX-flyX,dangerY-flyY),.36f)else 0f;if(danger>.68f&&lastDangerLevel<=.68f)escapeEvents++;if(dangerOn&&danger<.20f&&lastDangerLevel>.68f)reward+=.5f;lastDangerLevel=danger;learn(reward,dt)
            sensoryDisplay=.84f*sensoryDisplay+.16f*(count(0,SENSOR).toFloat()/SENSOR);centralDisplay=.84f*centralDisplay+.16f*(count(INTEGRATION_START,N).toFloat()/(N-INTEGRATION_START));motorDisplay=.84f*motorDisplay+.16f*(count(MOTOR_START,MOTOR_END).toFloat()/(MOTOR_END-MOTOR_START));centralFlow=.86f*centralFlow+.14f*centralDisplay;motorFlow=.86f*motorFlow+.14f*motorDisplay
            leftMotor=.82f*leftMotor+.18f*(left/14f);rightMotor=.82f*rightMotor+.18f*(right/14f);forwardMotor=.82f*forwardMotor+.18f*(forward/14f);escapeMotor=.82f*escapeMotor+.18f*(escape/14f);brakeMotor=.82f*brakeMotor+.18f*(brake/13f);exploreMotor=.82f*exploreMotor+.18f*(explore/13f);info.text=infoText()
        }
        override fun onDraw(c:Canvas){super.onDraw(c);val now=System.nanoTime();val raw=(now-lastNs)/1e9;val dt=min(.022,max(.003,raw)).toFloat();lastNs=now;fps=fps*.94f+(1f/dt)*.06f;simTime+=dt;sense(dt);stepBrain(dt);driveBody(dt);drawScene(c);drawFly(c,flyX*width,flyY*sceneBottom(),heading);drawBrainPanel(c);postInvalidateOnAnimation()}
        private fun sceneBottom()=height-brainPanelHeight();private fun brainPanelHeight()=min(height*.55f,610.dp().toFloat())
        private fun drawScene(c:Canvas){val b=sceneBottom();paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=Color.rgb(190,190,190);c.drawRect(8f,8f,width-8f,b-6f,paint);paint.style=Paint.Style.FILL;if(foodOn){val x=foodX*width;val y=foodY*b;paint.color=Color.rgb(32,155,70);c.drawCircle(x,y,23f,paint);paint.color=Color.WHITE;paint.textSize=17f;paint.textAlign=Paint.Align.CENTER;paint.typeface=Typeface.DEFAULT_BOLD;c.drawText("F",x,y+6f,paint)};if(lightOn){val x=lightX*width;val y=lightY*b;paint.color=Color.rgb(230,165,15);c.drawCircle(x,y,39f,paint);paint.color=Color.rgb(255,222,75);c.drawCircle(x,y,22f,paint);paint.style=Paint.Style.STROKE;paint.strokeWidth=3f;paint.color=Color.argb(130,235,180,20);c.drawCircle(x,y,54f,paint);paint.style=Paint.Style.FILL};if(dangerOn){val x=dangerX*width;val y=dangerY*b;paint.color=Color.rgb(205,42,42);c.drawCircle(x,y,36f,paint);paint.color=Color.WHITE;paint.textSize=35f;paint.textAlign=Paint.Align.CENTER;paint.typeface=Typeface.DEFAULT_BOLD;c.drawText("!",x,y+12f,paint)}}
        private fun drawBrainPanel(c:Canvas){val ph=brainPanelHeight();val top=height-ph;paint.color=Color.rgb(20,25,28);paint.style=Paint.Style.FILL;c.drawRoundRect(8f,top,width-8f,height.toFloat(),12f,12f,paint);paint.textAlign=Paint.Align.LEFT;paint.typeface=Typeface.DEFAULT_BOLD;paint.color=Color.WHITE;paint.textSize=18f;c.drawText("CEREBRO · MODELO MaleCNS REDUCIDO",20f,top+25f,paint);bar(c,"SENSORIAL",sensoryDisplay,top+34f,Color.rgb(52,195,110));bar(c,"CENTRAL",centralDisplay,top+61f,Color.rgb(80,145,225));bar(c,"MOTOR",motorDisplay,top+88f,Color.rgb(225,160,45));paint.color=Color.rgb(215,220,222);paint.textSize=10f;paint.typeface=Typeface.DEFAULT_BOLD;c.drawText("SEÑALES",20f,top+114f,paint);mini(c,"COMIDA",foodSignalDisplay,20f,top+120f,0);mini(c,"LUZ",lightSignalDisplay,160f,top+120f,1);mini(c,"PELIGRO",dangerSignalDisplay,300f,top+120f,2);val mapTop=top+153f;val mapBottom=height-30f;drawBrainMap(c,14f,mapTop,width-28f,max(150f,mapBottom-mapTop));paint.color=Color.rgb(205,210,212);paint.textSize=10f;paint.typeface=Typeface.DEFAULT;c.drawText("10% MaleCNS · 16.669 neuronas · actividad agregada por región",20f,height-8f,paint)}
        private fun bar(c:Canvas,label:String,value:Float,y:Float,accent:Int){paint.typeface=Typeface.DEFAULT_BOLD;paint.color=Color.WHITE;paint.textSize=12f;c.drawText(label,20f,y+16f,paint);val l=116f;val r=width-55f;paint.color=Color.rgb(62,67,70);c.drawRoundRect(l,y,r,y+21f,7f,7f,paint);paint.color=accent;c.drawRoundRect(l,y,l+(r-l)*value.coerceIn(0f,1f),y+21f,7f,7f,paint);paint.color=Color.WHITE;paint.textSize=12f;c.drawText("${(value*100).toInt()}%",r+6f,y+16f,paint)}
        private fun mini(c:Canvas,label:String,value:Float,x:Float,y:Float,k:Int){val w=(width-52f)/3f;paint.color=Color.rgb(53,58,61);c.drawRoundRect(x,y,x+w,y+24f,6f,6f,paint);paint.color=when(k){0->Color.rgb(52,175,85);1->Color.rgb(238,178,25);else->Color.rgb(215,55,55)};c.drawRoundRect(x+2f,y+2f,x+2f+(w-4f)*value.coerceIn(0f,1f),y+22f,5f,5f,paint);paint.color=Color.WHITE;paint.textSize=10f;paint.typeface=Typeface.DEFAULT_BOLD;c.drawText("$label ${(value*100).toInt()}%",x+7f,y+16f,paint)}
        private fun drawBrainMap(c:Canvas,x:Float,y:Float,w:Float,h:Float){paint.color=Color.rgb(28,33,37);paint.style=Paint.Style.FILL;c.drawRoundRect(x,y,x+w,y+h,14f,14f,paint);val cx=x+w*.5f;val cy=y+h*.52f;val lc=x+w*.21f;val rc=x+w*.79f;paint.color=Color.rgb(55,62,68);c.drawOval(lc-w*.16f,cy-h*.31f,lc+w*.08f,cy+h*.31f,paint);c.drawOval(rc-w*.08f,cy-h*.31f,rc+w*.16f,cy+h*.31f,paint);paint.color=Color.rgb(67,73,79);c.drawOval(cx-w*.23f,cy-h*.27f,cx+w*.23f,cy+h*.27f,paint);paint.color=Color.rgb(83,89,95);c.drawOval(cx-w*.11f,cy-h*.17f,cx-w*.02f,cy+h*.17f,paint);c.drawOval(cx+w*.02f,cy-h*.17f,cx+w*.11f,cy+h*.17f,paint);paint.color=Color.rgb(93,99,105);c.drawOval(cx-w*.065f,cy-h*.075f,cx+w*.065f,cy+h*.075f,paint)
            // Region hubs: visual lobes, central brain, mushroom-body-like learning zones, central-complex-like navigation, VNC motor.
            val hubs=arrayOf(floatArrayOf(lc,cy),floatArrayOf(rc,cy),floatArrayOf(cx,cy-.03f*h),floatArrayOf(cx-w*.13f,cy-.12f*h),floatArrayOf(cx+w*.13f,cy-.12f*h),floatArrayOf(cx,cy+.18f*h),floatArrayOf(cx,cy+.31f*h))
            val hubNames=arrayOf("VIS","VIS","CENTRAL","MB","MB","CX","VNC")
            paint.style=Paint.Style.STROKE;paint.strokeWidth=1.1f;paint.color=Color.argb(80,160,170,178)
            for(i in hubs.indices){for(j in i+1 until hubs.size){if((i+j)%2==0)c.drawLine(hubs[i][0],hubs[i][1],hubs[j][0],hubs[j][1],paint)}}
            val nodeN=260;val nx=FloatArray(nodeN);val ny=FloatArray(nodeN)
            for(i in 0 until nodeN){val r=i%7;val q=i/7;val t=(q%37)/36f-.5f;val side=if(i%2==0)-1f else 1f;val px=when(r){0,1->cx+side*w*(.14f+.15f*(q%20)/19f);2,3->cx+side*w*(.04f+.07f*(q%20)/19f);else->cx+t*w*.16f};val py=when(r){0,1->cy+t*h*.48f;2,3->cy+t*h*.28f;4->cy-h*.17f+t*h*.16f;5->cy+h*.02f+t*h*.18f;else->cy+h*.20f+t*h*.20f};nx[i]=px.coerceIn(x+12f,x+w-12f);ny[i]=py.coerceIn(y+12f,y+h-12f)}
            paint.strokeWidth=0.8f;for(i in 0 until nodeN step 2){val j=(i*37+11)%nodeN;paint.color=Color.argb(65,145,155,162);c.drawLine(nx[i],ny[i],nx[j],ny[j],paint)}
            for(i in 0 until nodeN){val idx=when{ i<70->(i*7)%609; i<130->609+((i*5)%407); i<210->INTEGRATION_START+((i*31)%(N-INTEGRATION_START)); else->MOTOR_START+((i*3)%(MOTOR_END-MOTOR_START))};val active=fired[idx];val level=if(active)1f else ((v[idx]+.72f)/.76f).coerceIn(0f,1f)*.5f;paint.style=Paint.Style.FILL;if(active){paint.color=Color.argb(70,70,220,145);c.drawCircle(nx[i],ny[i],7f,paint)};paint.color=if(active)Color.rgb(255,226,65)else Color.rgb((70+level*80).toInt(),(75+level*75).toInt(),(82+level*70).toInt());c.drawCircle(nx[i],ny[i],if(active)2.8f else 1.8f,paint)}
            paint.color=Color.rgb(210,215,218);paint.textAlign=Paint.Align.CENTER;paint.textSize=9f;paint.typeface=Typeface.DEFAULT_BOLD;c.drawText("ÓPTICO",lc,y+h-8f,paint);c.drawText("ÓPTICO",rc,y+h-8f,paint);c.drawText("CENTRAL",cx,y+13f,paint);c.drawText("VNC / MOTOR",cx,y+h-8f,paint);paint.textAlign=Paint.Align.LEFT
        }
        private fun drawFly(c:Canvas,px:Float,py:Float,a:Float){c.save();c.rotate(Math.toDegrees(a.toDouble()).toFloat(),px,py);paint.style=Paint.Style.FILL;paint.color=Color.argb(40,0,0,0);c.drawOval(px-40f,py+17f,px+37f,py+28f,paint);paint.strokeCap=Paint.Cap.ROUND;paint.strokeWidth=3f;paint.color=Color.rgb(45,37,35);val ys=floatArrayOf(-14f,0f,14f);for((q,yy) in ys.withIndex()){val knee=if(q==1)18f else 22f;c.drawLine(px-5f,py+yy,px-knee,py+yy-18f,paint);c.drawLine(px-knee,py+yy-18f,px-knee-17f,py+yy+2f,paint);c.drawLine(px+6f,py+yy,px+knee,py+yy-18f,paint);c.drawLine(px+knee,py+yy-18f,px+knee+17f,py+yy+2f,paint)};paint.color=Color.argb(105,184,210,226);c.drawOval(px-12f,py-60f,px+36f,py-7f,paint);c.drawOval(px-12f,py+7f,px+36f,py+60f,paint);paint.style=Paint.Style.STROKE;paint.strokeWidth=1.1f;paint.color=Color.argb(160,100,135,155);c.drawOval(px-12f,py-60f,px+36f,py-7f,paint);c.drawOval(px-12f,py+7f,px+36f,py+60f,paint);c.drawLine(px+2f,py-56f,px+22f,py-10f,paint);c.drawLine(px+2f,py+56f,px+22f,py+10f,paint);paint.style=Paint.Style.FILL;paint.color=Color.rgb(48,43,41);c.drawOval(px-43f,py-19f,px+15f,py+19f,paint);for((k,xx) in floatArrayOf(-31f,-20f,-9f,2f).withIndex()){paint.color=if(k%2==0)Color.rgb(142,108,72)else Color.rgb(64,54,49);c.drawRect(px+xx,py-17f,px+xx+5f,py+17f,paint)};paint.color=Color.rgb(60,54,51);c.drawCircle(px+18f,py,16f,paint);paint.color=Color.rgb(50,44,43);c.drawCircle(px+31f,py,13f,paint);paint.color=Color.rgb(150,38,34);c.drawCircle(px+37f,py-7f,8f,paint);c.drawCircle(px+37f,py+7f,8f,paint);paint.color=Color.rgb(230,95,70);c.drawCircle(px+39f,py-8f,2f,paint);c.drawCircle(px+39f,py+6f,2f,paint);paint.style=Paint.Style.STROKE;paint.strokeWidth=1.8f;paint.color=Color.rgb(50,42,39);c.drawLine(px+37f,py-7f,px+53f,py-23f,paint);c.drawLine(px+37f,py+7f,px+53f,py+23f,paint);paint.style=Paint.Style.FILL;c.drawCircle(px+54f,py-24f,2f,paint);c.drawCircle(px+54f,py+24f,2f,paint);c.restore()}
        override fun onTouchEvent(e:MotionEvent):Boolean {
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    if(e.y < sceneBottom()) {
                        moveStimulus(e.x/width.toFloat(), e.y/sceneBottom())
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }
        private fun moveStimulus(xr:Float,yr:Float){val x=xr.coerceIn(.06f,.94f);val y=yr.coerceIn(.10f,.82f);when(selectedStimulus){0->{foodX=x;foodY=y};1->{lightX=x;lightY=y};else->{dangerX=x;dangerY=y}}}
    }
}
