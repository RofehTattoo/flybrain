# FlyBrain V0.94

FlyBrain V0.94 is a mobile computational model of a Drosophila male CNS-inspired sensorimotor system.

## What changed from V0.93

- Exactly 16,669 simulated neurons: 10% of the published 166,691-neuron MaleCNS census.
- Structured populations for visual, olfactory, gustatory, mechanosensory/proprioceptive, higher-order, descending and VNC motor processing.
- Added explicit navigation/action-state populations for left, right, forward, escape, approach and exploration.
- Added bilateral visual and olfactory localisation pathways before action selection.
- Added a six-channel descending action-selection stage and VNC motor bottleneck.
- Added tonic exploratory neural activity so the network does not collapse into a permanently silent/resting state.
- Changed the LIF operating point so synaptic inputs can actually propagate through the reduced network.
- Neural simulation runs at a fixed 50 Hz independent of display refresh rate.
- Motor output is generated only from the simulated motor/VNC population; there is no direct stimulus-to-position movement rule.
- Reward-modulated plasticity remains on the motor synapses.
- Larger and more detailed Drosophila drawing, with segmented abdomen, thorax/head, compound eyes, antennae, six articulated legs and wing veins.
- Brain panel is smaller and leaves more room for the fly/environment.
- Added clearer activity aggregation and behaviour/locomotion indicators.

## V0.94 focus

- Reviewed against the supplied V0.93 runtime video: the fly showed very little displacement while food was active, so food/olfactory localisation, approach-state excitation and locomotor gain were strengthened.
- Kept movement downstream of the simulated motor/VNC populations; no direct stimulus-to-position teleport or hard-coded food-seeking movement was added.
- Increased approach responsiveness and body acceleration while retaining the fixed 50 Hz neural clock.
- Reworked the fly renderer to a larger top-down 2D Drosophila silhouette inspired by the supplied reference: segmented abdomen, broad translucent wings with veins, red compound eyes, antennae, six articulated legs and haltere hints.

## Scientific scope

The published MaleCNS v1.0 contains 166,691 neurons spanning the adult male Drosophila brain and ventral nerve cord, with a connectome graph containing 25.6 million edges between 166,391 neurons. The published resource is a biological connectome, not a ready-made Android neural simulator.

FlyBrain V0.94 therefore uses a **structured computational reduction** constrained by the published organisation of the MaleCNS. It is **not** a literal random 10% extraction of the biological graph and does not claim to reproduce biological membrane dynamics or exact synaptic weights. The Android model preserves functional classes and a plausible sensory -> higher centre -> descending -> VNC motor flow so that behaviour can be inspected interactively.

Source: Berg et al., *Cell* (2026), “Sexual dimorphism in the complete connectome of the Drosophila male central nervous system”.

MaleCNS project: https://male-cns.janelia.org/
MaleCNS v1.0 downloads: https://male-cns.janelia.org/download/
Paper: https://pmc.ncbi.nlm.nih.gov/articles/PMC12636603/

MaleCNS is released under CC BY.
