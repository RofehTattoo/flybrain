package com.example.flybrain

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(FlyView())
    }

    inner class FlyView : View(this) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var x = 0.5f
        private var y = 0.55f
        private var angle = 0f
        private var vx = 0f
        private var vy = 0f
        private var foodX = 0.78f
        private var foodY = 0.32f
        private var neurons = FloatArray(12)
        private var last = System.nanoTime()

        init {
            p.typeface = Typeface.create("sans", Typeface.NORMAL)
            setBackgroundColor(Color.rgb(245,245,245))
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val now = System.nanoTime()
            val dt = min(0.033, (now-last)/1e9).toFloat()
            last = now

            // Tiny artificial spiking network:
            // 0-3 sensory, 4-7 interneurons, 8-11 motor.
            val dx = foodX-x
            val dy = foodY-y
            val dist = hypot(dx,dy)
            val target = atan2(dy,dx)
            var err = atan2(sin(target-angle), cos(target-angle))

            neurons[0] = if (dist < .55f && abs(err) < 1.2f) 1f else 0f
            neurons[1] = if (err > .18f) 1f else 0f
            neurons[2] = if (err < -.18f) 1f else 0f
            neurons[3] = if (dist < .12f) 1f else 0f

            neurons[4] = neurons[0]*.8f + neurons[1]*.5f
            neurons[5] = neurons[0]*.8f + neurons[2]*.5f
            neurons[6] = neurons[3]*1.2f
            neurons[7] = max(0f, 1f-dist*1.5f)

            neurons[8] = neurons[4]
            neurons[9] = neurons[5]
            neurons[10] = neurons[7]
            neurons[11] = neurons[6]

            val turn = (neurons[9]-neurons[8])
            angle += turn * 2.2f * dt
            val speed = (0.10f + neurons[10]*0.22f) * dt
            vx = cos(angle)*speed
            vy = sin(angle)*speed
            x += vx; y += vy

            if (x<.06f || x>.94f) { angle = Math.PI.toFloat()-angle; x=x.coerceIn(.06f,.94f) }
            if (y<.12f || y>.94f) { angle = -angle; y=y.coerceIn(.12f,.94f) }

            if (dist < .045f) {
                foodX = .10f + Math.random().toFloat()*.80f
                foodY = .18f + Math.random().toFloat()*.70f
            }

            drawWorld(c)
            drawFly(c, x*width, y*height, angle)
            postInvalidateOnAnimation()
        }

        private fun drawWorld(c: Canvas) {
            p.style=Paint.Style.STROKE; p.strokeWidth=2f; p.color=Color.LTGRAY
            c.drawRect(18f,18f,width-18f,height-18f,p)

            p.style=Paint.Style.FILL; p.color=Color.rgb(60,170,80)
            c.drawCircle(foodX*width, foodY*height, 14f,p)

            p.color=Color.DKGRAY; p.textSize=18f
            c.drawText("FLYBRAIN V0.1", 28f, 48f, p)
            p.textSize=13f
            c.drawText("12 neuronas artificiales · objetivo: comida", 28f, 68f, p)

            val baseY=height-34f
            p.color=Color.DKGRAY; p.textSize=12f
            c.drawText("actividad neuronal", 28f, baseY-58f, p)
            for(i in neurons.indices){
                val bx=30f+i*25f
                val h=neurons[i]*45f
                p.color=if(neurons[i]>.5f) Color.BLACK else Color.LTGRAY
                c.drawRect(bx,baseY-h,bx+15f,baseY,p)
            }
        }

        private fun drawFly(c: Canvas, px:Float, py:Float, a:Float) {
            c.save(); c.rotate(Math.toDegrees(a.toDouble()).toFloat(),px,py)
            p.style=Paint.Style.FILL
            p.color=Color.rgb(35,35,35)
            c.drawOval(px-18,py-9,px+18,py+9,p)
            c.drawCircle(px+15,py,7f,p)

            p.color=Color.argb(150,180,210,230)
            c.drawOval(px-10,py-25,px+7,py-3,p)
            c.drawOval(px-10,py+3,px+7,py+25,p)

            p.color=Color.WHITE
            c.drawCircle(px+18,py-3,2.5f,p)
            c.drawCircle(px+18,py+3,2.5f,p)
            c.restore()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if(e.action==MotionEvent.ACTION_DOWN){
                foodX=(e.x/width).coerceIn(.06f,.94f)
                foodY=(e.y/height).coerceIn(.12f,.94f)
                return true
            }
            return true
        }
    }
}
