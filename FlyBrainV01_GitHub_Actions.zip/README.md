# FlyBrain V0.1 — Android + GitHub Actions

## Obtener la APK sin Android Studio

1. Crea un repositorio nuevo en GitHub (por ejemplo `FlyBrainV01`).
2. Sube TODO el contenido de esta carpeta al repositorio.
3. En GitHub, entra en **Actions**.
4. Selecciona **Build FlyBrain APK**.
5. Pulsa **Run workflow**.
6. Cuando termine, abre la ejecución y baja hasta **Artifacts**.
7. Descarga `FlyBrain-V0.1-APK`.
8. Descomprime el ZIP del artifact y tendrás `app-debug.apk`.
9. Pasa la APK al móvil Android y ábrela para instalarla.

La APK es una versión de demostración: una mosca virtual con una red neuronal artificial de 12 neuronas que busca un objetivo.
