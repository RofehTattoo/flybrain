# FlyBrain V0.6

Evolución del prototipo de cerebro artificial de mosca.

- 1024 neuronas LIF con adaptación.
- 36 neuronas sensoriales: 12 comida, 12 luz, 12 peligro.
- 796 neuronas de integración/recurrentes.
- 192 neuronas motoras/estado.
- Red dispersa con vías sensoriales -> interneuronas -> motor.
- Respuesta a peligro reforzada y más visible que en V0.5.
- Interfaz rediseñada para móvil: controles arriba, información de alto contraste y barras neuronales legibles.
- Los botones activan/desactivan el estímulo y seleccionan qué estímulo se mueve al tocar/arrastrar el escenario.
- RESET conserva la función de reiniciar todo el estado.
