package com.example.flybrain

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 247, 247))
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8.dp(), 8.dp(), 8.dp(), 8.dp())
            setBackgroundColor(Color.rgb(224, 224, 224))
        }

        fun makeButton(label: String): Button = Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            minHeight = 0
            minWidth = 0
            setPadding(2.dp(), 0, 2.dp(), 0)
        }

        val food = makeButton("COMIDA")
        val light = makeButton("LUZ")
        val danger = makeButton("PELIGRO")
        val reset = makeButton("↻ RESET")

        val buttonHeight = 64.dp()
        controls.addView(food, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(light, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(danger, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(reset, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        root.addView(controls, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 80.dp()))

        val sim = FlyView()
        root.addView(sim, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        food.setOnClickListener {
            sim.selectedStimulus = 0
            sim.foodOn = !sim.foodOn
            sim.updateButtons()
        }
        light.setOnClickListener {
            sim.selectedStimulus = 1
            sim.lightOn = !sim.lightOn
            sim.updateButtons()
        }
        danger.setOnClickListener {
            sim.selectedStimulus = 2
            sim.dangerOn = !sim.dangerOn
            sim.updateButtons()
        }
        reset.setOnClickListener {
            sim.resetSimulation()
            sim.updateButtons()
        }

        sim.foodButton = food
        sim.lightButton = light
        sim.dangerButton = danger
        sim.resetButton = reset

        setContentView(root)
        sim.updateButtons()
    }

    private fun Int.dp(): Int =
        (this * resources.displayMetrics.density).roundToInt()

    inner class FlyView : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rng = Random(506)

        /*
         * FLYBRAIN V0.6
         *
         * Goal: a clearer, stronger artificial fly nervous system.
         * The behaviour is intentionally more visible than V0.5, while
         * preserving the main architecture: sensory spikes -> interneurons
         * -> motor populations -> body movement.
         *
         * 1024 spiking units:
         *   36 sensory (12 food, 12 light, 12 danger)
         *  796 recurrent/intermediate
         *  192 motor/value
         *
         * The network is sparse. There is no direct stimulus -> body
         * steering shortcut. Stimuli alter sensory neuron activity; motor
         * populations are activated through interneuron pathways.
         */
        private val N = 1024
        private val SENSOR = 36
        private val INTER_START = SENSOR
        private val INTER_END = 832
        private val MOTOR_START = INTER_END

        private val v = FloatArray(N) { -0.72f }
        private val adapt = FloatArray(N)
        private val fired = BooleanArray(N)
        private val prevFired = BooleanArray(N)
        private val refractory = FloatArray(N)

        private val incoming = Array(N) { IntArray(0) }
        private val incomingW = Array(N) { FloatArray(0) }

        var foodOn = true
        var lightOn = false
        var dangerOn = false

        var foodButton: Button? = null
        var lightButton: Button? = null
        var dangerButton: Button? = null
        var resetButton: Button? = null

        var selectedStimulus = 0

        private var flyX = .24f
        private var flyY = .58f
        private var heading = -.25f

        private var foodX = .76f
        private var foodY = .36f
        private var lightX = .72f
        private var lightY = .72f
        private var dangerX = .30f
        private var dangerY = .30f

        private var simTime = 0f
        private var lastNs = System.nanoTime()
        private var fps = 60f

        private var foodHits = 0
        private var escapeEvents = 0
        private var lastDangerLevel = 0f
        private var satiety = 0f
        private var fatigue = 0f
        private var novelty = 0f

        init {
            setBackgroundColor(Color.rgb(247, 247, 247))
            isFocusable = true
            buildBrain()
        }

        private fun styleButton(button: Button, active: Boolean, selected: Boolean) {
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 12f
                setColor(if (active) Color.rgb(235, 245, 235) else Color.rgb(245, 245, 245))
                setStroke(if (selected) 4 else 1, if (selected) Color.rgb(40, 120, 70) else Color.rgb(170, 170, 170))
            }
            button.background = bg
            button.alpha = if (active) 1f else .58f
        }

        fun updateButtons() {
            foodButton?.let {
                it.text = if (foodOn) "COMIDA  ON" else "COMIDA"
                styleButton(it, foodOn, selectedStimulus == 0)
            }
            lightButton?.let {
                it.text = if (lightOn) "LUZ  ON" else "LUZ"
                styleButton(it, lightOn, selectedStimulus == 1)
            }
            dangerButton?.let {
                it.text = if (dangerOn) "PELIGRO  ON" else "PELIGRO"
                styleButton(it, dangerOn, selectedStimulus == 2)
            }
            resetButton?.alpha = 1f
            invalidate()
        }

        fun resetSimulation() {
            for (i in 0 until N) {
                v[i] = -.72f
                adapt[i] = 0f
                fired[i] = false
                prevFired[i] = false
                refractory[i] = 0f
            }
            flyX = .24f
            flyY = .58f
            heading = -.25f
            foodX = .76f; foodY = .36f
            lightX = .72f; lightY = .72f
            dangerX = .30f; dangerY = .30f
            simTime = 0f
            foodHits = 0
            escapeEvents = 0
            lastDangerLevel = 0f
            satiety = 0f
            fatigue = 0f
            novelty = 0f
            lastNs = System.nanoTime()
            invalidate()
        }

        private fun addEdge(target: Int, source: Int, weight: Float,
                            lists: Array<MutableList<Int>>, ws: Array<MutableList<Float>>) {
            lists[target].add(source)
            ws[target].add(weight)
        }

        private fun buildBrain() {
            val lists = Array(N) { mutableListOf<Int>() }
            val weights = Array(N) { mutableListOf<Float>() }

            // Four broad intermediate regions. Each receives sensory input
            // and recurrent input, then feeds the motor populations below.
            val regions = arrayOf(
                36 until 220,   // food valuation / approach
                220 until 404,  // light / orientation
                404 until 620,  // danger / escape
                620 until 832   // integration / exploration
            )

            for (regionIndex in regions.indices) {
                val range = regions[regionIndex]
                for (i in range) {
                    val sensoryCount = 5 + rng.nextInt(5)
                    repeat(sensoryCount) {
                        val src = when (regionIndex) {
                            0 -> rng.nextInt(12)
                            1 -> 12 + rng.nextInt(12)
                            2 -> 24 + rng.nextInt(12)
                            else -> rng.nextInt(SENSOR)
                        }
                        addEdge(i, src, .055f + rng.nextFloat() * .055f, lists, weights)
                    }

                    val recurrent = 8 + rng.nextInt(7)
                    repeat(recurrent) {
                        var src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                        while (src == i) src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                        val sign = if (rng.nextFloat() < .76f) 1f else -1f
                        addEdge(i, src, sign * (.018f + rng.nextFloat() * .045f), lists, weights)
                    }
                }
            }

            // Cross-region integration: a smaller number of long-range edges.
            repeat(900) {
                val target = INTER_START + rng.nextInt(INTER_END - INTER_START)
                val source = INTER_START + rng.nextInt(INTER_END - INTER_START)
                if (target != source) {
                    val sign = if (rng.nextFloat() < .72f) 1f else -1f
                    addEdge(target, source, sign * (.012f + rng.nextFloat() * .028f), lists, weights)
                }
            }

            /*
             * Motor populations (24 neurons each unless stated otherwise):
             * 832-855  turn left
             * 856-879  turn right
             * 880-919  forward / approach
             * 920-943  retreat / escape
             * 944-959  braking / avoidance
             * 960-983  exploration / scanning
             * 984-1007 valuation / arousal
             * 1008-1023 state / persistence
             *
             * The strongest paths are still synaptic paths from sensory-
             * tuned interneuron regions, not direct kinematic rules.
             */
            for (i in MOTOR_START until N) {
                repeat(10) {
                    val src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                    val sign = if (rng.nextFloat() < .68f) 1f else -1f
                    addEdge(i, src, sign * (.028f + rng.nextFloat() * .042f), lists, weights)
                }
            }

            // Reliable approach pathways: food and light -> dedicated
            // interneuron regions -> left/right/forward motor groups.
            for (i in 832 until 856) { // left turn
                for (src in 36 until 95 step 2) addEdge(i, src, .12f, lists, weights)
                for (src in 220 until 275 step 2) addEdge(i, src, .07f, lists, weights)
                for (src in 404 until 470 step 2) addEdge(i, src, -.035f, lists, weights)
            }
            for (i in 856 until 880) { // right turn
                for (src in 36 until 95 step 2) addEdge(i, src + 1, .12f, lists, weights)
                for (src in 220 until 275 step 2) addEdge(i, src + 1, .07f, lists, weights)
                for (src in 404 until 470 step 2) addEdge(i, src, -.035f, lists, weights)
            }
            for (i in 880 until 920) { // forward
                for (src in 95 until 180 step 2) addEdge(i, src, .105f, lists, weights)
                for (src in 275 until 360 step 2) addEdge(i, src, .065f, lists, weights)
            }

            // Danger -> escape and braking. The danger region is given
            // substantially stronger inhibitory/excitatory separation.
            for (i in 920 until 944) {
                for (src in 404 until 620 step 2) addEdge(i, src, .16f, lists, weights)
                for (src in 620 until 690 step 3) addEdge(i, src, .07f, lists, weights)
            }
            for (i in 944 until 960) {
                for (src in 404 until 620 step 3) addEdge(i, src, .13f, lists, weights)
            }

            for (i in 960 until 984) {
                for (src in 620 until 832 step 3) addEdge(i, src, .06f, lists, weights)
            }
            for (i in 984 until 1008) {
                for (src in 36 until 832 step 9) addEdge(i, src, .035f, lists, weights)
            }
            for (i in 1008 until 1024) {
                for (src in 404 until 832 step 4) addEdge(i, src, .04f, lists, weights)
            }

            for (i in 0 until N) {
                incoming[i] = lists[i].toIntArray()
                incomingW[i] = weights[i].toFloatArray()
            }
        }

        private fun signal(distance: Float, radius: Float): Float {
            return exp((-(distance * distance) / (2f * radius * radius)).toDouble())
                .toFloat().coerceIn(0f, 1f)
        }

        private fun directionalStrength(dx: Float, dy: Float, angle: Float, side: Int): Float {
            val targetAngle = atan2(dy, dx)
            val error = atan2(sin(targetAngle - angle), cos(targetAngle - angle))
            return when (side) {
                -1 -> (-error / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                1 -> (error / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                else -> 1f - (abs(error) / Math.PI.toFloat()).coerceIn(0f, 1f)
            }
        }

        private fun encodeStimulus(enabled: Boolean, sx: Float, sy: Float, base: Int, gain: Float) {
            if (!enabled) return
            val dx = sx - flyX
            val dy = sy - flyY
            val dist = hypot(dx, dy)
            val proximity = signal(dist, .30f)
            val left = directionalStrength(dx, dy, heading, -1)
            val right = directionalStrength(dx, dy, heading, 1)
            val front = directionalStrength(dx, dy, heading, 0)
            val upper = (0.5f + dy * 2.4f).coerceIn(0f, 1f)
            val lower = (0.5f - dy * 2.4f).coerceIn(0f, 1f)

            // 12 channels per stimulus. The first six are directional,
            // the next six provide distance/intensity bands and contrast.
            val currents = floatArrayOf(
                left * gain, right * gain, front * gain,
                upper * gain * .65f, lower * gain * .65f, proximity * gain,
                proximity * front * gain, proximity * left * gain,
                proximity * right * gain, (1f - proximity) * gain * .22f,
                front * (1f - proximity) * gain * .18f, gain * .08f
            )
            for (k in 0 until 12) v[base + k] += currents[k]
        }

        private fun sense(dt: Float) {
            // Stronger danger response than V0.5: close/central danger can
            // dominate the sensory layer without bypassing the network.
            encodeStimulus(foodOn, foodX, foodY, 0, 1.15f * (1f - satiety * .55f))
            encodeStimulus(lightOn, lightX, lightY, 12, .95f)
            encodeStimulus(dangerOn, dangerX, dangerY, 24, 2.25f)

            for (i in 0 until SENSOR) {
                v[i] -= adapt[i]
                adapt[i] *= exp((-dt * 1.7f).toDouble()).toFloat()
            }

            val foodNovelty = if (foodOn) signal(hypot(foodX - flyX, foodY - flyY), .42f) else 0f
            val lightNovelty = if (lightOn) signal(hypot(lightX - flyX, lightY - flyY), .42f) else 0f
            val dangerNovelty = if (dangerOn) signal(hypot(dangerX - flyX, dangerY - flyY), .48f) else 0f
            novelty = (.95f * novelty + .05f * (foodNovelty + lightNovelty + dangerNovelty).coerceIn(0f, 1f))
        }

        private fun stepBrain(dt: Float) {
            for (i in 0 until N) prevFired[i] = fired[i]

            for (i in 0 until N) {
                if (refractory[i] > 0f) {
                    refractory[i] -= dt
                    fired[i] = false
                    continue
                }

                var syn = 0f
                val sources = incoming[i]
                val ws = incomingW[i]
                for (k in sources.indices) if (prevFired[sources[k]]) syn += ws[k]

                v[i] += ((-.72f - v[i]) * 7.0f - adapt[i]) * dt + syn * 0.22f

                if (i >= INTER_START && i < INTER_END && rng.nextFloat() < .0024f) v[i] += .045f

                fired[i] = v[i] >= .035f
                if (fired[i]) {
                    v[i] = -.84f
                    adapt[i] = min(.16f, adapt[i] + .028f)
                    refractory[i] = .006f
                }
            }
        }

        private fun count(a: Int, b: Int): Int {
            var n = 0
            for (i in a until b) if (fired[i]) n++
            return n
        }

        private fun driveBody(dt: Float) {
            val left = count(832, 856)
            val right = count(856, 880)
            val forward = count(880, 920)
            val escape = count(920, 944)
            val brake = count(944, 960)
            val explore = count(960, 984)
            val value = count(984, 1008)
            val state = count(1008, 1024)

            val turn = (right - left) * .015f
            val propulsion = forward * .0019f
            val escapeTurn = (right - left) * .005f
            var speed = (.003f + propulsion + explore * .0005f) -
                    escape * .0042f - brake * .0020f

            heading += turn + escapeTurn
            if (escape > 2) heading += .030f * sin(simTime * 7f)
            speed += value * .00028f + state * .00008f
            speed = speed.coerceIn(-.028f, .030f)

            flyX += cos(heading) * speed * dt * 14f
            flyY += sin(heading) * speed * dt * 14f

            if (flyX < .04f || flyX > .96f) {
                heading = Math.PI.toFloat() - heading
                flyX = flyX.coerceIn(.04f, .96f)
            }
            if (flyY < .12f || flyY > .92f) {
                heading = -heading
                flyY = flyY.coerceIn(.12f, .92f)
            }

            val foodDist = hypot(foodX - flyX, foodY - flyY)
            if (foodOn && foodDist < .055f) {
                foodHits++
                satiety = min(1f, satiety + .28f)
                foodX = .08f + rng.nextFloat() * .84f
                foodY = .16f + rng.nextFloat() * .68f
            }

            satiety *= exp((-dt * .018f).toDouble()).toFloat()
            fatigue = (fatigue * .995f + escape * .002f).coerceIn(0f, 1f)

            val dangerLevel = if (dangerOn) signal(hypot(dangerX - flyX, dangerY - flyY), .32f) else 0f
            if (dangerLevel > .72f && lastDangerLevel <= .72f) escapeEvents++
            lastDangerLevel = dangerLevel
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val now = System.nanoTime()
            val raw = (now - lastNs) / 1e9
            val dt = min(.022, max(.003, raw)).toFloat()
            lastNs = now
            fps = fps * .94f + (1f / dt) * .06f
            simTime += dt

            sense(dt)
            stepBrain(dt)
            driveBody(dt)
            drawScene(c)
            drawFly(c, flyX * width, flyY * height, heading)
            postInvalidateOnAnimation()
        }

        private fun drawScene(c: Canvas) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = Color.rgb(185, 185, 185)
            c.drawRect(10f, 10f, width - 10f, height - 10f, paint)
            paint.style = Paint.Style.FILL

            if (foodOn) {
                paint.color = Color.rgb(35, 155, 70)
                c.drawCircle(foodX * width, foodY * height, 18f, paint)
                paint.color = Color.WHITE
                paint.textSize = 13f
                paint.textAlign = Paint.Align.CENTER
                c.drawText("F", foodX * width, foodY * height + 5f, paint)
            }
            if (lightOn) {
                paint.color = Color.rgb(235, 175, 25)
                c.drawCircle(lightX * width, lightY * height, 31f, paint)
                paint.color = Color.rgb(255, 225, 90)
                c.drawCircle(lightX * width, lightY * height, 17f, paint)
            }
            if (dangerOn) {
                paint.color = Color.rgb(205, 45, 45)
                c.drawCircle(dangerX * width, dangerY * height, 30f, paint)
                paint.color = Color.WHITE
                paint.textSize = 30f
                paint.textAlign = Paint.Align.CENTER
                c.drawText("!", dangerX * width, dangerY * height + 10f, paint)
            }

            // High-contrast information panel.
            paint.textAlign = Paint.Align.LEFT
            paint.color = Color.rgb(30, 30, 30)
            paint.textSize = 20f
            c.drawText("FLYBRAIN V0.6", 24f, 34f, paint)
            paint.textSize = 13f
            c.drawText("1024 neuronas · red dispersa · LIF + adaptación", 24f, 55f, paint)
            c.drawText("36 sensoriales · 796 integración · 192 motor/estado", 24f, 74f, paint)
            c.drawText("COMIDA ${if(foodOn) "ON" else "OFF"}   LUZ ${if(lightOn) "ON" else "OFF"}   PELIGRO ${if(dangerOn) "ON" else "OFF"}", 24f, 93f, paint)
            c.drawText("Comidas $foodHits   Escapes $escapeEvents   Saciedad ${(satiety * 100).toInt()}%   FPS ${fps.toInt()}", 24f, 112f, paint)

            // Neural activity panel: large enough to read on a phone.
            val panelTop = max(130f, height - 142f)
            paint.color = Color.argb(238, 255, 255, 255)
            c.drawRect(14f, panelTop - 8f, width - 14f, height - 14f, paint)
            paint.color = Color.rgb(35, 35, 35)
            paint.textSize = 14f
            c.drawText("ACTIVIDAD DEL CEREBRO", 24f, panelTop + 14f, paint)

            val sensoryActivity = activeFraction(0, SENSOR)
            val interActivity = activeFraction(INTER_START, INTER_END)
            val motorActivity = activeFraction(MOTOR_START, N)
            drawActivityBar(c, "SENSORIAL", sensoryActivity, panelTop + 34f)
            drawActivityBar(c, "INTEGRACIÓN", interActivity, panelTop + 66f)
            drawActivityBar(c, "MOTOR", motorActivity, panelTop + 98f)

            paint.color = Color.rgb(65, 65, 65)
            paint.textSize = 12f
            c.drawText("Objetivo: ${when(selectedStimulus) { 0 -> "COMIDA"; 1 -> "LUZ"; else -> "PELIGRO" }} · toca y arrastra para moverlo", 24f, height - 20f, paint)
        }

        private fun activeFraction(a: Int, b: Int): Float {
            var n = 0
            for (i in a until b) if (fired[i]) n++
            return n.toFloat() / (b - a).toFloat()
        }

        private fun drawActivityBar(c: Canvas, label: String, value: Float, y: Float) {
            paint.color = Color.rgb(70, 70, 70)
            paint.textSize = 12f
            c.drawText(label, 24f, y + 13f, paint)
            val left = 115f
            val right = width - 24f
            paint.color = Color.rgb(215, 215, 215)
            c.drawRect(left, y, right, y + 18f, paint)
            paint.color = Color.rgb(40, 115, 75)
            c.drawRect(left, y, left + (right - left) * value.coerceIn(0f, 1f), y + 18f, paint)
            paint.color = Color.rgb(30, 30, 30)
            paint.textSize = 11f
            c.drawText("${(value * 100f).toInt()}%", right - 35f, y + 13f, paint)
        }

        private fun drawFly(c: Canvas, px: Float, py: Float, angle: Float) {
            c.save()
            c.rotate(Math.toDegrees(angle.toDouble()).toFloat(), px, py)
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(25, 25, 25)
            c.drawOval(px - 19, py - 9, px + 19, py + 9, paint)
            c.drawCircle(px + 16, py, 7f, paint)
            paint.color = Color.argb(160, 170, 205, 225)
            c.drawOval(px - 10, py - 26, px + 8, py - 3, paint)
            c.drawOval(px - 10, py + 3, px + 8, py + 26, paint)
            paint.color = Color.WHITE
            c.drawCircle(px + 18, py - 3, 2.5f, paint)
            c.drawCircle(px + 18, py + 3, 2.5f, paint)
            c.restore()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    moveStimulus(e.x / width.toFloat(), e.y / height.toFloat())
                    return true
                }
            }
            return true
        }

        private fun moveStimulus(xRaw: Float, yRaw: Float) {
            val x = xRaw.coerceIn(.06f, .94f)
            val y = yRaw.coerceIn(.10f, .88f)
            when (selectedStimulus) {
                0 -> { foodX = x; foodY = y }
                1 -> { lightX = x; lightY = y }
                else -> { dangerX = x; dangerY = y }
            }
        }
    }
}
