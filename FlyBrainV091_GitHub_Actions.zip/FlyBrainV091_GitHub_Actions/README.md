# FlyBrain V0.911

Prototipo Android de cerebro artificial inspirado en Drosophila.

V0.911 mantiene 1.536 neuronas LIF con adaptación y plasticidad modulada por recompensa. Añade un monitor neuronal en tiempo real con actividad poblacional legible, entradas sensoriales, flujo SENSORES→INTEGRACIÓN→MOTOR→ESTADO, salidas motoras, conducta actual y una matriz de 192 neuronas representativas.
