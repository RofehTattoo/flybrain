package com.example.flybrain

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 247, 247))
            clipToPadding = true
        }

        root.setOnApplyWindowInsetsListener { view, insets ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                top = bars.top
                bottom = bars.bottom
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            view.setPadding(0, top, 0, bottom)
            insets
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6.dp(), 6.dp(), 6.dp(), 6.dp())
            setBackgroundColor(Color.rgb(226, 226, 226))
        }

        fun makeButton(label: String): Button = Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            minHeight = 0
            minWidth = 0
            setPadding(1.dp(), 0, 1.dp(), 0)
        }

        val food = makeButton("COMIDA")
        val light = makeButton("LUZ")
        val danger = makeButton("PELIGRO")
        val reset = makeButton("↻ RESET")
        val buttonHeight = 64.dp()

        controls.addView(food, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(light, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(danger, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        controls.addView(reset, LinearLayout.LayoutParams(0, buttonHeight, 1f).apply { setMargins(2.dp(), 0, 2.dp(), 0) })
        root.addView(controls, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 76.dp()))

        val info = TextView(this).apply {
            setPadding(14.dp(), 7.dp(), 14.dp(), 7.dp())
            setTextColor(Color.rgb(28, 28, 28))
            textSize = 13f
            typeface = Typeface.create("sans", Typeface.NORMAL)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                setStroke(2.dp(), Color.rgb(145, 145, 145))
                cornerRadius = 8.dp().toFloat()
            }
        }
        root.addView(info, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 106.dp()).apply {
            setMargins(8.dp(), 6.dp(), 8.dp(), 5.dp())
        })

        val sim = FlyView(info)
        root.addView(sim, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        fun refresh() {
            info.text = sim.infoText()
            sim.updateButtons()
        }

        food.setOnClickListener {
            sim.selectedStimulus = 0
            sim.foodOn = !sim.foodOn
            refresh()
        }
        light.setOnClickListener {
            sim.selectedStimulus = 1
            sim.lightOn = !sim.lightOn
            refresh()
        }
        danger.setOnClickListener {
            sim.selectedStimulus = 2
            sim.dangerOn = !sim.dangerOn
            refresh()
        }
        reset.setOnClickListener {
            sim.resetSimulation()
            refresh()
        }

        sim.foodButton = food
        sim.lightButton = light
        sim.dangerButton = danger
        sim.resetButton = reset

        setContentView(root)
        root.requestApplyInsets()
        refresh()
    }

    inner class FlyView(private val info: TextView) : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rng = Random(507)

        // V0.7: 1,536 spiking units. The network remains sparse and modular.
        private val N = 1536
        private val SENSOR = 48
        private val INTER_START = SENSOR
        private val INTER_END = 1280
        private val MOTOR_START = INTER_END

        private val v = FloatArray(N) { -0.72f }
        private val adapt = FloatArray(N)
        private val fired = BooleanArray(N)
        private val prevFired = BooleanArray(N)
        private val refractory = FloatArray(N)
        private val incoming = Array(N) { IntArray(0) }
        private val incomingW = Array(N) { FloatArray(0) }

        var foodOn = true
        var lightOn = false
        var dangerOn = false
        var selectedStimulus = 0
        var foodButton: Button? = null
        var lightButton: Button? = null
        var dangerButton: Button? = null
        var resetButton: Button? = null

        private var flyX = .24f
        private var flyY = .55f
        private var heading = -.15f
        private var foodX = .76f
        private var foodY = .35f
        private var lightX = .72f
        private var lightY = .72f
        private var dangerX = .30f
        private var dangerY = .30f
        private var simTime = 0f
        private var lastNs = System.nanoTime()
        private var fps = 60f
        private var foodHits = 0
        private var escapeEvents = 0
        private var lastDangerLevel = 0f
        private var satiety = 0f
        private var fatigue = 0f
        private var novelty = 0f
        private var sensoryDisplay = 0f
        private var interDisplay = 0f
        private var motorDisplay = 0f

        init {
            setBackgroundColor(Color.rgb(250, 250, 250))
            isFocusable = true
            buildBrain()
        }

        fun infoText(): String = buildString {
            append("FLYBRAIN V0.7\n")
            append("1.536 neuronas · red modular dispersa · LIF + adaptación\n")
            append("48 sensoriales · 1.232 integración · 256 motor/estado\n")
            append("COMIDA ${if (foodOn) "ON" else "OFF"}   LUZ ${if (lightOn) "ON" else "OFF"}   PELIGRO ${if (dangerOn) "ON" else "OFF"}\n")
            append("Comidas $foodHits   Escapes $escapeEvents   Saciedad ${(satiety * 100f).toInt()}%   FPS ${fps.toInt()}")
        }

        private fun styleButton(button: Button, active: Boolean, selected: Boolean) {
            button.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 12.dp().toFloat()
                setColor(if (active) Color.rgb(232, 246, 235) else Color.rgb(245, 245, 245))
                setStroke(if (selected) 4 else 1, if (selected) Color.rgb(35, 120, 70) else Color.rgb(155, 155, 155))
            }
            button.alpha = if (active) 1f else .68f
        }

        fun updateButtons() {
            foodButton?.let { it.text = if (foodOn) "COMIDA  ON" else "COMIDA"; styleButton(it, foodOn, selectedStimulus == 0) }
            lightButton?.let { it.text = if (lightOn) "LUZ  ON" else "LUZ"; styleButton(it, lightOn, selectedStimulus == 1) }
            dangerButton?.let { it.text = if (dangerOn) "PELIGRO  ON" else "PELIGRO"; styleButton(it, dangerOn, selectedStimulus == 2) }
            resetButton?.alpha = 1f
            invalidate()
        }

        fun resetSimulation() {
            for (i in 0 until N) {
                v[i] = -.72f; adapt[i] = 0f; fired[i] = false; prevFired[i] = false; refractory[i] = 0f
            }
            flyX = .24f; flyY = .55f; heading = -.15f
            foodX = .76f; foodY = .35f; lightX = .72f; lightY = .72f; dangerX = .30f; dangerY = .30f
            simTime = 0f; foodHits = 0; escapeEvents = 0; lastDangerLevel = 0f; satiety = 0f; fatigue = 0f; novelty = 0f
            sensoryDisplay = 0f; interDisplay = 0f; motorDisplay = 0f
            lastNs = System.nanoTime()
            info.text = infoText()
            invalidate()
        }

        private fun addEdge(target: Int, source: Int, weight: Float, lists: Array<MutableList<Int>>, ws: Array<MutableList<Float>>) {
            lists[target].add(source); ws[target].add(weight)
        }

        private fun buildBrain() {
            val lists = Array(N) { mutableListOf<Int>() }
            val weights = Array(N) { mutableListOf<Float>() }

            // 6 integration modules: food, light, danger, multisensory,
            // memory/state and exploration. Each module receives its own
            // sensory population plus recurrent and cross-module inputs.
            val regions = arrayOf(
                48 until 250, 250 until 452, 452 until 654,
                654 until 856, 856 until 1068, 1068 until 1280
            )
            for (regionIndex in regions.indices) {
                val range = regions[regionIndex]
                for (i in range) {
                    repeat(6 + rng.nextInt(5)) {
                        val src = when (regionIndex) {
                            0 -> rng.nextInt(16)
                            1 -> 16 + rng.nextInt(16)
                            2 -> 32 + rng.nextInt(16)
                            else -> rng.nextInt(SENSOR)
                        }
                        val gain = when (regionIndex) {
                            0 -> .055f; 1 -> .050f; 2 -> .075f; else -> .030f
                        }
                        addEdge(i, src, gain + rng.nextFloat() * .045f, lists, weights)
                    }
                    repeat(9 + rng.nextInt(7)) {
                        var src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                        while (src == i) src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                        val sign = if (rng.nextFloat() < .75f) 1f else -1f
                        addEdge(i, src, sign * (.014f + rng.nextFloat() * .035f), lists, weights)
                    }
                }
            }

            repeat(1400) {
                val target = INTER_START + rng.nextInt(INTER_END - INTER_START)
                val source = INTER_START + rng.nextInt(INTER_END - INTER_START)
                if (target != source) {
                    val sign = if (rng.nextFloat() < .72f) 1f else -1f
                    addEdge(target, source, sign * (.010f + rng.nextFloat() * .024f), lists, weights)
                }
            }

            // Motor groups: left, right, forward, escape, brake, explore,
            // value and state. Dedicated pathways make the three behaviours
            // observable while retaining the neural chain.
            for (i in MOTOR_START until N) {
                repeat(12) {
                    val src = INTER_START + rng.nextInt(INTER_END - INTER_START)
                    val sign = if (rng.nextFloat() < .70f) 1f else -1f
                    addEdge(i, src, sign * (.025f + rng.nextFloat() * .035f), lists, weights)
                }
            }

            // Food/light approach and orientation.
            for (i in 1280 until 1312) {
                for (src in 48 until 125 step 2) addEdge(i, src, .11f, lists, weights)
                for (src in 250 until 325 step 2) addEdge(i, src, .065f, lists, weights)
            }
            for (i in 1312 until 1344) {
                for (src in 48 until 125 step 2) addEdge(i, src + 1, .11f, lists, weights)
                for (src in 250 until 325 step 2) addEdge(i, src + 1, .065f, lists, weights)
            }
            for (i in 1344 until 1384) {
                for (src in 125 until 220 step 2) addEdge(i, src, .095f, lists, weights)
                for (src in 325 until 420 step 2) addEdge(i, src, .060f, lists, weights)
            }

            // Strong, fast threat pathway through the danger integration module.
            for (i in 1384 until 1416) {
                for (src in 452 until 654 step 2) addEdge(i, src, .155f, lists, weights)
                for (src in 654 until 730 step 3) addEdge(i, src, .075f, lists, weights)
            }
            for (i in 1416 until 1440) for (src in 452 until 654 step 3) addEdge(i, src, .13f, lists, weights)
            for (i in 1440 until 1464) for (src in 856 until 1280 step 3) addEdge(i, src, .055f, lists, weights)
            for (i in 1464 until 1496) for (src in 654 until 1280 step 4) addEdge(i, src, .042f, lists, weights)
            for (i in 1496 until 1536) for (src in 452 until 1280 step 5) addEdge(i, src, .038f, lists, weights)

            for (i in 0 until N) { incoming[i] = lists[i].toIntArray(); incomingW[i] = weights[i].toFloatArray() }
        }

        private fun signal(distance: Float, radius: Float): Float = exp((-(distance * distance) / (2f * radius * radius)).toDouble()).toFloat().coerceIn(0f, 1f)

        private fun directionalStrength(dx: Float, dy: Float, angle: Float, side: Int): Float {
            val targetAngle = atan2(dy, dx)
            val error = atan2(sin(targetAngle - angle), cos(targetAngle - angle))
            return when (side) {
                -1 -> (-error / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                1 -> (error / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                else -> 1f - (abs(error) / Math.PI.toFloat()).coerceIn(0f, 1f)
            }
        }

        private fun encodeStimulus(enabled: Boolean, sx: Float, sy: Float, base: Int, gain: Float) {
            if (!enabled) return
            val dx = sx - flyX; val dy = sy - flyY
            val dist = hypot(dx, dy)
            val proximity = signal(dist, .34f)
            val left = directionalStrength(dx, dy, heading, -1)
            val right = directionalStrength(dx, dy, heading, 1)
            val front = directionalStrength(dx, dy, heading, 0)
            val upper = (0.5f + dy * 2.4f).coerceIn(0f, 1f)
            val lower = (0.5f - dy * 2.4f).coerceIn(0f, 1f)
            val currents = floatArrayOf(
                left * gain, right * gain, front * gain, upper * gain * .7f, lower * gain * .7f, proximity * gain,
                proximity * front * gain, proximity * left * gain, proximity * right * gain,
                (1f - proximity) * gain * .22f, front * (1f - proximity) * gain * .18f, gain * .08f,
                left * proximity * gain * .8f, right * proximity * gain * .8f, front * proximity * gain * .8f, proximity * gain
            )
            for (k in 0 until 16) v[base + k] += currents[k]
        }

        private fun sense(dt: Float) {
            encodeStimulus(foodOn, foodX, foodY, 0, 1.45f * (1f - satiety * .55f))
            encodeStimulus(lightOn, lightX, lightY, 16, 1.20f)
            encodeStimulus(dangerOn, dangerX, dangerY, 32, 2.90f)
            for (i in 0 until SENSOR) { v[i] -= adapt[i]; adapt[i] *= exp((-dt * 1.7f).toDouble()).toFloat() }

            val foodNovelty = if (foodOn) signal(hypot(foodX - flyX, foodY - flyY), .44f) else 0f
            val lightNovelty = if (lightOn) signal(hypot(lightX - flyX, lightY - flyY), .44f) else 0f
            val dangerNovelty = if (dangerOn) signal(hypot(dangerX - flyX, dangerY - flyY), .52f) else 0f
            novelty = .95f * novelty + .05f * (foodNovelty + lightNovelty + dangerNovelty).coerceIn(0f, 1f)
        }

        private fun stepBrain(dt: Float) {
            for (i in 0 until N) prevFired[i] = fired[i]
            for (i in 0 until N) {
                if (refractory[i] > 0f) { refractory[i] -= dt; fired[i] = false; continue }
                var syn = 0f
                val sources = incoming[i]; val ws = incomingW[i]
                for (k in sources.indices) if (prevFired[sources[k]]) syn += ws[k]
                v[i] += ((-.72f - v[i]) * 7.0f - adapt[i]) * dt + syn * .22f
                if (i in INTER_START until INTER_END && rng.nextFloat() < .0028f) v[i] += .050f
                fired[i] = v[i] >= .035f
                if (fired[i]) { v[i] = -.84f; adapt[i] = min(.16f, adapt[i] + .028f); refractory[i] = .006f }
            }
        }

        private fun count(a: Int, b: Int): Int { var n = 0; for (i in a until b) if (fired[i]) n++; return n }

        private fun driveBody(dt: Float) {
            val left = count(1280, 1312)
            val right = count(1312, 1344)
            val forward = count(1344, 1384)
            val escape = count(1384, 1416)
            val brake = count(1416, 1440)
            val explore = count(1440, 1464)
            val value = count(1464, 1496)
            val state = count(1496, 1536)

            val turn = (right - left) * .018f
            val propulsion = forward * .0021f
            var speed = (.0022f + propulsion + explore * .00055f) - escape * .0058f - brake * .0022f
            heading += turn
            if (escape > 2) { heading += .050f * sin(simTime * 8.0f); speed -= .004f }
            speed += value * .00022f + state * .00007f
            speed = speed.coerceIn(-.035f, .035f)
            flyX += cos(heading) * speed * dt * 15f
            flyY += sin(heading) * speed * dt * 15f

            if (flyX < .055f || flyX > .945f) { heading = Math.PI.toFloat() - heading; flyX = flyX.coerceIn(.055f, .945f) }
            if (flyY < .10f || flyY > .89f) { heading = -heading; flyY = flyY.coerceIn(.10f, .89f) }

            val foodDist = hypot(foodX - flyX, foodY - flyY)
            if (foodOn && foodDist < .065f) { foodHits++; satiety = min(1f, satiety + .28f); foodX = .08f + rng.nextFloat() * .84f; foodY = .14f + rng.nextFloat() * .70f }
            satiety *= exp((-dt * .018f).toDouble()).toFloat()
            fatigue = (fatigue * .995f + escape * .002f).coerceIn(0f, 1f)
            val dangerLevel = if (dangerOn) signal(hypot(dangerX - flyX, dangerY - flyY), .34f) else 0f
            if (dangerLevel > .72f && lastDangerLevel <= .72f) escapeEvents++
            lastDangerLevel = dangerLevel

            sensoryDisplay = .82f * sensoryDisplay + .18f * (count(0, SENSOR).toFloat() / SENSOR)
            interDisplay = .82f * interDisplay + .18f * (count(INTER_START, INTER_END).toFloat() / (INTER_END - INTER_START))
            motorDisplay = .82f * motorDisplay + .18f * (count(MOTOR_START, N).toFloat() / (N - MOTOR_START))
            info.text = infoText()
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val now = System.nanoTime()
            val raw = (now - lastNs) / 1e9
            val dt = min(.022, max(.003, raw)).toFloat()
            lastNs = now
            fps = fps * .94f + (1f / dt) * .06f
            simTime += dt
            sense(dt); stepBrain(dt); driveBody(dt)
            drawScene(c)
            drawFly(c, flyX * width, flyY * height, heading)
            drawBrainPanel(c)
            postInvalidateOnAnimation()
        }

        private fun drawScene(c: Canvas) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.rgb(190, 190, 190)
            c.drawRect(8f, 8f, width - 8f, height - 8f, paint); paint.style = Paint.Style.FILL

            if (foodOn) {
                val x = foodX * width; val y = foodY * height
                paint.color = Color.rgb(32, 155, 70); c.drawCircle(x, y, 22f, paint)
                paint.color = Color.WHITE; paint.textSize = 16f; paint.textAlign = Paint.Align.CENTER; c.drawText("F", x, y + 6f, paint)
            }
            if (lightOn) {
                val x = lightX * width; val y = lightY * height
                paint.color = Color.rgb(230, 165, 15); c.drawCircle(x, y, 36f, paint)
                paint.color = Color.rgb(255, 222, 75); c.drawCircle(x, y, 20f, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = Color.argb(120, 235, 180, 20)
                c.drawCircle(x, y, 50f, paint); paint.style = Paint.Style.FILL
            }
            if (dangerOn) {
                val x = dangerX * width; val y = dangerY * height
                paint.color = Color.rgb(205, 42, 42); c.drawCircle(x, y, 34f, paint)
                paint.color = Color.WHITE; paint.textSize = 34f; paint.textAlign = Paint.Align.CENTER; c.drawText("!", x, y + 12f, paint)
            }
        }

        private fun drawBrainPanel(c: Canvas) {
            val panelH = 164f
            val top = height - panelH - 10f
            paint.color = Color.argb(245, 24, 27, 29); c.drawRoundRect(10f, top, width - 10f, height - 10f, 12f, 12f, paint)
            paint.textAlign = Paint.Align.LEFT; paint.color = Color.WHITE; paint.textSize = 17f; paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("ACTIVIDAD DEL CEREBRO", 24f, top + 26f, paint)
            paint.typeface = Typeface.DEFAULT
            drawActivityBar(c, "SENSORIAL", sensoryDisplay, top + 40f)
            drawActivityBar(c, "INTEGRACIÓN", interDisplay, top + 75f)
            drawActivityBar(c, "MOTOR", motorDisplay, top + 110f)
            paint.color = Color.rgb(215, 215, 215); paint.textSize = 12f
            c.drawText("Objetivo: ${when(selectedStimulus) { 0 -> "COMIDA"; 1 -> "LUZ"; else -> "PELIGRO" }} · arrastra el estímulo", 24f, top + 145f, paint)
        }

        private fun drawActivityBar(c: Canvas, label: String, value: Float, y: Float) {
            paint.color = Color.rgb(235, 235, 235); paint.textSize = 13f; c.drawText(label, 24f, y + 14f, paint)
            val left = 124f; val right = width - 70f
            paint.color = Color.rgb(65, 68, 70); c.drawRoundRect(left, y, right, y + 20f, 7f, 7f, paint)
            paint.color = if (value > .10f) Color.rgb(50, 190, 105) else Color.rgb(95, 100, 103)
            c.drawRoundRect(left, y, left + (right - left) * value.coerceIn(0f, 1f), y + 20f, 7f, 7f, paint)
            paint.color = Color.WHITE; paint.textSize = 12f; c.drawText("${(value * 100f).toInt()}%", right + 8f, y + 15f, paint)
        }

        // Larger, anatomically suggestive fly: segmented abdomen/thorax,
        // head and compound eyes, translucent wings, six legs and antennae.
        private fun drawFly(c: Canvas, px: Float, py: Float, angle: Float) {
            c.save(); c.rotate(Math.toDegrees(angle.toDouble()).toFloat(), px, py)
            paint.style = Paint.Style.FILL

            // Legs: three pairs, with joints and fine lower segments.
            paint.strokeCap = Paint.Cap.ROUND; paint.strokeWidth = 3f; paint.color = Color.rgb(55, 45, 40)
            val legPairs = floatArrayOf(-13f, -6f, 0f, 7f, 14f)
            for (i in 0..2) {
                val yy = legPairs[i * 2]
                c.drawLine(px - 8f, py + yy, px - 30f, py + yy - 14f, paint)
                c.drawLine(px - 30f, py + yy - 14f, px - 42f, py + yy + 2f, paint)
                c.drawLine(px + 5f, py + yy, px + 28f, py + yy - 14f, paint)
                c.drawLine(px + 28f, py + yy - 14f, px + 41f, py + yy + 2f, paint)
            }

            // Wings behind the body.
            paint.color = Color.argb(125, 175, 205, 225)
            c.drawOval(px - 16f, py - 42f, px + 22f, py - 5f, paint)
            c.drawOval(px - 16f, py + 5f, px + 22f, py + 42f, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.5f; paint.color = Color.argb(150, 105, 135, 155)
            c.drawOval(px - 16f, py - 42f, px + 22f, py - 5f, paint); c.drawOval(px - 16f, py + 5f, px + 22f, py + 42f, paint)
            paint.style = Paint.Style.FILL

            // Abdomen, segmented and tapered.
            val abdomen = RectF(px - 28f, py - 12f, px + 15f, py + 12f)
            paint.color = Color.rgb(52, 48, 46); c.drawOval(abdomen, paint)
            paint.color = Color.rgb(132, 105, 76)
            for (x in floatArrayOf(-20f, -10f, 0f)) c.drawRect(px + x, py - 11f, px + x + 4f, py + 11f, paint)
            paint.color = Color.rgb(35, 32, 31); c.drawOval(px - 5f, py - 12f, px + 18f, py + 12f, paint)

            // Thorax and head with large compound eyes.
            paint.color = Color.rgb(68, 61, 57); c.drawCircle(px + 16f, py, 12f, paint)
            paint.color = Color.rgb(145, 35, 32); c.drawCircle(px + 24f, py - 6f, 7f, paint); c.drawCircle(px + 24f, py + 6f, 7f, paint)
            paint.color = Color.rgb(210, 80, 65); c.drawCircle(px + 26f, py - 7f, 2f, paint); c.drawCircle(px + 26f, py + 5f, 2f, paint)

            // Antennae.
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.rgb(55, 45, 40)
            c.drawLine(px + 22f, py - 7f, px + 37f, py - 18f, paint); c.drawLine(px + 22f, py + 7f, px + 37f, py + 18f, paint)
            paint.style = Paint.Style.FILL; paint.color = Color.rgb(55, 45, 40)
            c.drawCircle(px + 38f, py - 19f, 2f, paint); c.drawCircle(px + 38f, py + 19f, 2f, paint)
            c.restore()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    moveStimulus(e.x / width.toFloat(), e.y / height.toFloat()); return true
                }
            }
            return true
        }

        private fun moveStimulus(xRaw: Float, yRaw: Float) {
            val x = xRaw.coerceIn(.06f, .94f); val y = yRaw.coerceIn(.10f, .82f)
            when (selectedStimulus) {
                0 -> { foodX = x; foodY = y }
                1 -> { lightX = x; lightY = y }
                else -> { dangerX = x; dangerY = y }
            }
        }
    }
}
