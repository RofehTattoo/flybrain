# FlyBrain V0.7

Evolución del prototipo de cerebro artificial de mosca, centrada en legibilidad móvil, interacción y una representación visual más reconocible de la mosca.

- 1.536 neuronas LIF con adaptación.
- 48 neuronas sensoriales: 16 comida, 16 luz, 16 peligro.
- 1.232 neuronas de integración/recurrentes.
- 256 neuronas motoras/estado.
- Red modular y dispersa con vías sensoriales → integración → motor.
- Respuesta a peligro reforzada y separada en una vía de escape observable.
- Panel de información superior con texto grande y alto contraste.
- Barras de actividad cerebral grandes, oscuras y legibles, colocadas dentro de la zona segura sobre la navegación Android.
- Gestión de barras del sistema mediante WindowInsets para evitar que la navegación inferior tape la información.
- Mosca dibujada con mayor tamaño y más detalle: abdomen segmentado, tórax, cabeza, ojos compuestos, alas, seis patas y antenas.
- Controles superiores y accesibles; RESET se mantiene.
- Pulsar COMIDA/LUZ/PELIGRO activa o desactiva el estímulo y lo selecciona para moverlo arrastrando en el escenario.
