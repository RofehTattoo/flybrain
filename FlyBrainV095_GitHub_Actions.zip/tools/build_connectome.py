#!/usr/bin/env python3
"""Build a deterministic 16,669-neuron MaleCNS v1.0 reduction.

The reduction is derived from the published MaleCNS v1.0 annotation and weighted
connectivity tables. It keeps exactly 10% of the 166,691-neuron census by
stratifying on the published superclass and selecting the highest-connectivity
cells within each superclass. Only published edges between retained neurons
are embedded; no graph edge is invented here.
"""
from __future__ import annotations

import json
import math
import struct
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.ipc as ipc

BASE = "https://storage.googleapis.com/flyem-male-cns/v1.0/connectome-data/flat-connectome/"
TARGET = 16669
FILES = {
    "annotations": "body-annotations-male-cns-v1.0-minconf-0.5.feather",
    "neurotransmitters": "body-neurotransmitters-male-cns-v1.0.feather",
    "weights": "connectome-weights-male-cns-v1.0-minconf-0.5.feather",
}

NT_SIGN = {
    "acetylcholine": 1.0,
    "gaba": -1.0,
    "glutamate": -1.0,
}

SUPERCLASS_CODE = {}

def download(path: Path, name: str) -> None:
    if path.exists() and path.stat().st_size > 0:
        return
    url = BASE + name
    tmp = path.with_suffix(path.suffix + ".partial")
    print(f"Downloading {name} ...", flush=True)
    urllib.request.urlretrieve(url, tmp)
    tmp.replace(path)


def clean(x):
    if pd.isna(x):
        return ""
    return str(x)


def classify_channel(row) -> int:
    """0 visual, 1 olfactory, 2 gustatory, 3 mechanosensory/proprioceptive, 4 other."""
    sc = clean(row.get("superclass", ""))
    cl = clean(row.get("class", "")).lower()
    sub = clean(row.get("subclass", "")).lower()
    typ = clean(row.get("type", "")).lower()
    text = " ".join((cl, sub, typ))
    if sc in {"ol_sensory", "visual_projection", "visual_centrifugal"}:
        return 0
    if "olf" in text or "antennal lobe" in text:
        return 1
    if "gust" in text or "taste" in text:
        return 2
    if sc in {"vnc_sensory", "sensory_ascending", "sensory_descending"}:
        return 3
    if sc.startswith("cb_sensory"):
        return 3
    return 4


def main(root: Path) -> None:
    raw = root / "build" / "malecns_raw"
    raw.mkdir(parents=True, exist_ok=True)
    for key, name in FILES.items():
        download(raw / name, name)

    annotations = pd.read_feather(raw / FILES["annotations"])
    if "status" in annotations.columns:
        traced = annotations[annotations["status"].astype(str).str.lower().eq("traced")].copy()
    else:
        traced = annotations.copy()
    traced = traced[traced["superclass"].notna()].copy()
    traced["bodyId"] = traced["bodyId"].astype(np.int64)
    traced = traced.drop_duplicates("bodyId").sort_values("bodyId").reset_index(drop=True)
    if len(traced) < TARGET:
        raise RuntimeError(f"Only {len(traced)} traced annotated neurons available; expected >= {TARGET}")

    ids = traced["bodyId"].to_numpy(np.int64)
    degree = np.zeros(len(ids), dtype=np.float64)

    # One streaming pass over the 1.1 GB weighted graph to measure connectivity.
    weights_path = raw / FILES["weights"]
    reader = ipc.open_file(pa.memory_map(str(weights_path), "r"))
    for bi in range(reader.num_record_batches):
        b = reader.get_batch(bi)
        pre = b.column(b.schema.get_field_index("body_pre")).to_numpy(zero_copy_only=False).astype(np.int64)
        post = b.column(b.schema.get_field_index("body_post")).to_numpy(zero_copy_only=False).astype(np.int64)
        w = b.column(b.schema.get_field_index("weight")).to_numpy(zero_copy_only=False).astype(np.float64)
        pi = np.searchsorted(ids, pre)
        po = np.searchsorted(ids, post)
        pv = (pi < len(ids)) & (ids[np.minimum(pi, len(ids)-1)] == pre)
        qv = (po < len(ids)) & (ids[np.minimum(po, len(ids)-1)] == post)
        if pv.any(): np.add.at(degree, pi[pv], w[pv])
        if qv.any(): np.add.at(degree, po[qv], w[qv])
        if bi % 50 == 0:
            print(f"degree pass batch {bi}/{reader.num_record_batches}", flush=True)

    traced["degree"] = degree
    counts = traced.groupby("superclass", sort=True).size().to_dict()
    total = len(traced)

    # Proportional quota, corrected to exactly TARGET using largest remainders.
    raw_q = {k: v * TARGET / total for k, v in counts.items()}
    quota = {k: max(1, int(math.floor(v))) for k, v in raw_q.items()}
    while sum(quota.values()) > TARGET:
        candidates = [k for k in quota if quota[k] > 1]
        k = max(candidates, key=lambda x: quota[x] - raw_q[x])
        quota[k] -= 1
    while sum(quota.values()) < TARGET:
        k = max(raw_q, key=lambda x: raw_q[x] - quota[x])
        quota[k] += 1

    selected_frames = []
    for sc, group in traced.groupby("superclass", sort=True):
        n = quota[sc]
        selected_frames.append(group.sort_values(["degree", "bodyId"], ascending=[False, True]).head(n))
    selected = pd.concat(selected_frames, ignore_index=True)
    if len(selected) != TARGET:
        raise AssertionError((len(selected), TARGET))

    # Stable anatomical ordering: sensory channels first, then descending,
    # ascending, motor and the remaining central/intrinsic populations. This
    # gives the Android runtime contiguous anatomical readout blocks.
    selected["channel"] = selected.apply(classify_channel, axis=1)
    def block(row):
        sc = str(row["superclass"])
        ch = int(row["channel"])
        if ch < 4:
            return ch
        if sc == "descending_neuron":
            return 4
        if sc == "ascending_neuron":
            return 5
        if sc == "vnc_motor":
            return 6
        return 7
    selected["block"] = selected.apply(block, axis=1)
    selected = selected.sort_values(["block", "superclass", "bodyId"]).reset_index(drop=True)
    selected_ids = selected["bodyId"].to_numpy(np.int64)
    selected_set = set(int(x) for x in selected_ids)
    index = {int(b): i for i, b in enumerate(selected_ids)}

    # Neurotransmitter predictions provide the sign model used by the simulator.
    nt = pd.read_feather(raw / FILES["neurotransmitters"])
    nt_cols = [c for c in ["body", "bodyId"] if c in nt.columns]
    nt_id_col = nt_cols[0] if nt_cols else None
    nt["_id"] = nt[nt_id_col].astype(np.int64) if nt_id_col else -1
    nt_name = None
    for c in ["consensus_nt", "predicted_nt", "celltype_predicted_nt"]:
        if c in nt.columns:
            nt_name = c
            break
    nt_map = dict(zip(nt["_id"].tolist(), nt[nt_name].astype(str).tolist())) if nt_name else {}

    # Second streaming pass: retain only published edges between selected neurons.
    edges = []
    contacts = 0
    for bi in range(reader.num_record_batches):
        b = reader.get_batch(bi)
        pre = b.column(b.schema.get_field_index("body_pre")).to_numpy(zero_copy_only=False).astype(np.int64)
        post = b.column(b.schema.get_field_index("body_post")).to_numpy(zero_copy_only=False).astype(np.int64)
        w = b.column(b.schema.get_field_index("weight")).to_numpy(zero_copy_only=False).astype(np.int64)
        mask = np.isin(pre, selected_ids) & np.isin(post, selected_ids) & (w > 0)
        if mask.any():
            for a, c, d in zip(pre[mask], post[mask], w[mask]):
                sign = NT_SIGN.get(nt_map.get(int(a), ""), 0.0)
                # Unknown/modulatory transmitter retains the edge but contributes no direct current.
                if sign == 0.0:
                    continue
                edges.append((index[int(a)], index[int(c)], float(d) * sign))
                contacts += int(d)
        if bi % 50 == 0:
            print(f"edge pass batch {bi}/{reader.num_record_batches}", flush=True)

    # Convert raw synapse counts into dimensionless synaptic weights while
    # preserving the published topology and relative contact strengths.
    target_totals = np.zeros(TARGET, dtype=np.float64)
    for src, dst, raw_weight in edges:
        target_totals[dst] += abs(raw_weight)
    normalized_edges = []
    for src, dst, raw_weight in edges:
        denom = max(1.0, target_totals[dst])
        normalized_edges.append((src, dst, float(raw_weight) / denom * 0.42))
    edges = normalized_edges
    edges.sort(key=lambda e: (e[1], e[0]))

    # Metadata/ranges used by the Android sensor interface and brain display.
    channel = selected["channel"].to_numpy(np.int8)
    ranges = {}
    for code, name in [(0,"visual"),(1,"olfactory"),(2,"gustatory"),(3,"mechanosensory"),(4,"other")]:
        idxs = np.where(channel == code)[0]
        ranges[name] = [int(idxs.min()), int(idxs.max()+1)] if len(idxs) else [0,0]

    sc_list = sorted(selected["superclass"].astype(str).unique().tolist())
    SUPERCLASS_CODE.update({s:i for i,s in enumerate(sc_list)})

    # Compact binary: header, neuron records, edge records.
    out = root / "app" / "src" / "main" / "res" / "raw" / "malecns_reduced.bin"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("wb") as f:
        f.write(b"FBC95\0\0\0")
        f.write(struct.pack("<II", TARGET, len(edges)))
        for i, row in selected.iterrows():
            body = int(row.bodyId)
            sc = SUPERCLASS_CODE[str(row.superclass)]
            side = 1 if clean(row.get("somaSide", "")) == "R" else (-1 if clean(row.get("somaSide", "")) == "L" else 0)
            ch = int(channel[i])
            f.write(struct.pack("<qbbb", body, sc, side, ch))
        for src, dst, weight in edges:
            f.write(struct.pack("<iif", int(src), int(dst), float(weight)))

    # Compile-time ranges for the anatomical superclasses.
    def superclass_range(name):
        idxs = np.where(selected["superclass"].astype(str).to_numpy() == name)[0]
        return (int(idxs.min()), int(idxs.max()+1)) if len(idxs) else (0,0)
    desc = superclass_range("descending_neuron")
    asc = superclass_range("ascending_neuron")
    vmotor = superclass_range("vnc_motor")
    vsens = superclass_range("vnc_sensory")
    other_idx = np.where(selected["block"].to_numpy() == 7)[0]
    other = (int(other_idx.min()), int(other_idx.max()+1)) if len(other_idx) else (0,0)

    # Generate compile-time metadata so the Kotlin app does not hard-code ranges.
    meta = root / "app" / "src" / "main" / "java" / "com" / "example" / "flybrain" / "GeneratedConnectomeMeta.kt"
    meta.write_text("""package com.example.flybrain\n\nobject GeneratedConnectomeMeta {\n    const val VERSION = \"MaleCNS v1.0\"\n    const val NEURONS = %d\n    const val EDGES = %d\n    const val CONTACTS_RETAINED = %dL\n    const val VIS_START = %d\n    const val VIS_END = %d\n    const val OLF_START = %d\n    const val OLF_END = %d\n    const val GUST_START = %d\n    const val GUST_END = %d\n    const val MECH_START = %d\n    const val MECH_END = %d\n    const val DESC_START = %d\n    const val DESC_END = %d\n    const val ASC_START = %d\n    const val ASC_END = %d\n    const val VMOTOR_START = %d\n    const val VMOTOR_END = %d\n    const val VSENS_START = %d\n    const val VSENS_END = %d\n    const val OTHER_START = %d\n    const val OTHER_END = %d\n}\n""" % (TARGET, len(edges), contacts,
       ranges["visual"][0], ranges["visual"][1], ranges["olfactory"][0], ranges["olfactory"][1],
       ranges["gustatory"][0], ranges["gustatory"][1], ranges["mechanosensory"][0], ranges["mechanosensory"][1],
       desc[0], desc[1], asc[0], asc[1], vmotor[0], vmotor[1], vsens[0], vsens[1], other[0], other[1]))

    report = {
        "dataset": "MaleCNS v1.0",
        "selection": "exactly 10% of traced annotated neurons, stratified by published superclass and selected by total weighted connectivity",
        "source": BASE,
        "neurons_source": int(total),
        "neurons_retained": TARGET,
        "edges_retained": len(edges),
        "contacts_retained_signed": contacts,
        "superclass_counts_source": {str(k): int(v) for k,v in counts.items()},
        "superclass_quota": {str(k): int(v) for k,v in quota.items()},
        "channel_ranges": ranges,
        "edge_signs": NT_SIGN,
        "unknown_modulatory_edges": "retained in source but omitted from direct-current graph when transmitter sign is unresolved",
        "license": "CC-BY-4.0",
        "download": "https://male-cns.janelia.org/download/",
        "paper": "Berg et al., Cell 2026, DOI 10.1016/j.cell.2026.08.015",
    }
    (root / "app" / "src" / "main" / "res" / "raw" / "malecns_reduced_report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2), flush=True)

if __name__ == "__main__":
    main(Path(__file__).resolve().parents[1])
