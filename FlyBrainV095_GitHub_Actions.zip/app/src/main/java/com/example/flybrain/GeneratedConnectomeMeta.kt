package com.example.flybrain

/** Placeholder overwritten by tools/build_connectome.py in the V0.95 build. */
object GeneratedConnectomeMeta {
    const val VERSION = "MaleCNS v1.0"
    const val NEURONS = 16669
    const val EDGES = 0
    const val CONTACTS_RETAINED = 0L
    const val VIS_START = 0
    const val VIS_END = 1000
    const val OLF_START = 1000
    const val OLF_END = 1100
    const val GUST_START = 1100
    const val GUST_END = 1200
    const val MECH_START = 1200
    const val MECH_END = 1300
    const val DESC_START = 1300
    const val DESC_END = 1431
    const val ASC_START = 1431
    const val ASC_END = 1531
    const val VMOTOR_START = 1531
    const val VMOTOR_END = 1602
    const val VSENS_START = 1200
    const val VSENS_END = 1300
    const val OTHER_START = 1602
    const val OTHER_END = 16669
}
