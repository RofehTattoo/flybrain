package com.example.flybrain

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import java.util.Random
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 247, 247))
            clipToPadding = true
        }

        root.setOnApplyWindowInsetsListener { view, insets ->
            val bars = if (Build.VERSION.SDK_INT >= 30) {
                insets.getInsets(android.view.WindowInsets.Type.systemBars())
            } else null
            val top = bars?.top ?: insets.systemWindowInsetTop
            val bottom = bars?.bottom ?: insets.systemWindowInsetBottom
            view.setPadding(0, top, 0, bottom)
            insets
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6.dp(), 5.dp(), 6.dp(), 5.dp())
            setBackgroundColor(Color.rgb(226, 226, 226))
        }

        fun makeButton(label: String) = Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            minHeight = 0
            minWidth = 0
            setPadding(1.dp(), 0, 1.dp(), 0)
        }

        val food = makeButton("COMIDA")
        val light = makeButton("LUZ")
        val danger = makeButton("PELIGRO")
        val reset = makeButton("↻ RESET")
        val bh = 60.dp()
        listOf(food, light, danger, reset).forEach { button ->
            controls.addView(
                button,
                LinearLayout.LayoutParams(0, bh, 1f).apply {
                    setMargins(2.dp(), 0, 2.dp(), 0)
                }
            )
        }
        root.addView(controls, LinearLayout.LayoutParams(-1, 70.dp()))

        val info = TextView(this).apply {
            setPadding(14.dp(), 7.dp(), 14.dp(), 7.dp())
            setTextColor(Color.rgb(28, 28, 28))
            textSize = 12f
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                setStroke(2.dp(), Color.rgb(145, 145, 145))
                cornerRadius = 8.dp().toFloat()
            }
        }
        root.addView(
            info,
            LinearLayout.LayoutParams(-1, 132.dp()).apply {
                setMargins(8.dp(), 5.dp(), 8.dp(), 5.dp())
            }
        )

        val sim = FlyView(info)
        root.addView(sim, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refresh() {
            info.text = sim.infoText()
            sim.updateButtons()
        }

        food.setOnClickListener { sim.selectAndToggle(0); refresh() }
        light.setOnClickListener { sim.selectAndToggle(1); refresh() }
        danger.setOnClickListener { sim.selectAndToggle(2); refresh() }
        reset.setOnClickListener { sim.resetSimulation(); refresh() }

        sim.foodButton = food
        sim.lightButton = light
        sim.dangerButton = danger
        sim.resetButton = reset

        setContentView(root)
        root.requestApplyInsets()
        refresh()
    }

    inner class FlyView(private val info: TextView) : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rng = Random(9301)

        // V0.95: exactly 16,669 simulated neurons. The graph is generated at
        // build time from the public MaleCNS v1.0 tables: neurons are sampled
        // within the published superclasses and retained edges are real
        // body-to-body connections from the source connectome.
        private val N = GeneratedConnectomeMeta.NEURONS

        private val VIS_START = GeneratedConnectomeMeta.VIS_START
        private val VIS_END = GeneratedConnectomeMeta.VIS_END
        private val OLF_START = GeneratedConnectomeMeta.OLF_START
        private val OLF_END = GeneratedConnectomeMeta.OLF_END
        private val GUST_START = GeneratedConnectomeMeta.GUST_START
        private val GUST_END = GeneratedConnectomeMeta.GUST_END
        private val MECH_START = GeneratedConnectomeMeta.MECH_START
        private val MECH_END = GeneratedConnectomeMeta.MECH_END
        private val SENSOR_END = maxOf(VIS_END, OLF_END, GUST_END, MECH_END)
        private val OTHER_START = GeneratedConnectomeMeta.OTHER_START
        private val OTHER_END = GeneratedConnectomeMeta.OTHER_END
        private val DESC_START = GeneratedConnectomeMeta.DESC_START
        private val DESC_END = GeneratedConnectomeMeta.DESC_END
        private val ASC_START = GeneratedConnectomeMeta.ASC_START
        private val ASC_END = GeneratedConnectomeMeta.ASC_END
        private val MOTOR_START = GeneratedConnectomeMeta.VMOTOR_START
        private val MOTOR_END = GeneratedConnectomeMeta.VMOTOR_END
        private val VSENS_START = GeneratedConnectomeMeta.VSENS_START
        private val VSENS_END = GeneratedConnectomeMeta.VSENS_END

        private val v = FloatArray(N) { -0.72f }
        private val adapt = FloatArray(N)
        private val fired = BooleanArray(N)
        private val prevFired = BooleanArray(N)
        private val refractory = FloatArray(N)

        private val incoming = Array(N) { IntArray(0) }
        private val incomingW = Array(N) { FloatArray(0) }
        private val baseW = Array(N) { FloatArray(0) }
        private val eligibility = Array(N) { FloatArray(0) }

        var foodOn = true
        var lightOn = false
        var dangerOn = false
        var selectedStimulus = 0
        var foodButton: Button? = null
        var lightButton: Button? = null
        var dangerButton: Button? = null
        var resetButton: Button? = null

        private var flyX = .24f
        private var flyY = .55f
        private var heading = -.15f
        private var flySpeed = .0045f

        private var foodX = .76f
        private var foodY = .35f
        private var lightX = .72f
        private var lightY = .72f
        private var dangerX = .30f
        private var dangerY = .30f

        private var simTime = 0f
        private var neuralAccumulator = 0f
        private var lastNs = System.nanoTime()
        private var fps = 60f
        private var foodHits = 0
        private var escapeEvents = 0
        private var satiety = 0f
        private var memoryTrace = 0f
        private var lastReward = 0f
        private var lastDangerLevel = 0f
        private var stableLocomotion = 0f

        private var sensoryDisplay = 0f
        private var centralDisplay = 0f
        private var motorDisplay = 0f
        private var foodSignalDisplay = 0f
        private var lightSignalDisplay = 0f
        private var dangerSignalDisplay = 0f

        private var leftMotor = 0f
        private var rightMotor = 0f
        private var forwardMotor = 0f
        private var escapeMotor = 0f
        private var brakeMotor = 0f
        private var exploreMotor = 0f

        private var foodDrive = 0f
        private var lightDrive = 0f
        private var dangerDrive = 0f

        init {
            setBackgroundColor(Color.rgb(250, 250, 250))
            buildBrain()
        }

        fun infoText() = buildString {
            append("FLYBRAIN V0.95\n")
            append("16.669 neuronas · MaleCNS v1.0 reducido · conectividad publicada + LIF\n")
            append("Superclases MaleCNS · sensorial → cerebro → VNC → motor · feedback\n")
            append("Comida ${if (foodOn) "ON" else "OFF"} · Luz ${if (lightOn) "ON" else "OFF"} · Peligro ${if (dangerOn) "ON" else "OFF"}\n")
            append("Comidas $foodHits · Escapes $escapeEvents · Saciedad ${(satiety * 100).toInt()}% · Memoria ${(memoryTrace * 100).toInt()}% · FPS ${fps.toInt()}\n")
            append("Conducta: ${behaviorLabel()} · Locomoción ${(stableLocomotion * 100).toInt()}%")
        }

        private fun behaviorLabel(): String = when {
            escapeMotor > .16f -> "ESCAPE"
            brakeMotor > .18f -> "FRENO"
            forwardMotor > .18f && foodDrive > .20f -> "ALIMENTACIÓN / APROXIMACIÓN"
            rightMotor > leftMotor + .08f -> "GIRO DERECHA"
            leftMotor > rightMotor + .08f -> "GIRO IZQUIERDA"
            forwardMotor > .16f -> "AVANCE"
            exploreMotor > .14f -> "EXPLORACIÓN"
            else -> "ORIENTACIÓN / EXPLORACIÓN"
        }

        fun selectAndToggle(s: Int) {
            if (selectedStimulus == s) {
                when (s) {
                    0 -> foodOn = !foodOn
                    1 -> lightOn = !lightOn
                    else -> dangerOn = !dangerOn
                }
            } else {
                selectedStimulus = s
                when (s) {
                    0 -> foodOn = true
                    1 -> lightOn = true
                    else -> dangerOn = true
                }
            }
            invalidate()
        }

        private fun styleButton(button: Button, active: Boolean, selected: Boolean, accent: Int) {
            button.background = GradientDrawable().apply {
                cornerRadius = 12.dp().toFloat()
                setColor(if (active) Color.rgb(232, 246, 235) else Color.rgb(245, 245, 245))
                setStroke(if (selected) 4 else 1, if (selected) accent else Color.rgb(155, 155, 155))
            }
            button.alpha = if (active) 1f else .68f
        }

        fun updateButtons() {
            foodButton?.let {
                it.text = if (foodOn) "COMIDA  ON" else "COMIDA"
                styleButton(it, foodOn, selectedStimulus == 0, Color.rgb(35, 120, 70))
            }
            lightButton?.let {
                it.text = if (lightOn) "LUZ  ON" else "LUZ"
                styleButton(it, lightOn, selectedStimulus == 1, Color.rgb(210, 145, 10))
            }
            dangerButton?.let {
                it.text = if (dangerOn) "PELIGRO  ON" else "PELIGRO"
                styleButton(it, dangerOn, selectedStimulus == 2, Color.rgb(190, 45, 45))
            }
        }

        fun resetSimulation() {
            for (i in 0 until N) {
                v[i] = -0.72f
                adapt[i] = 0f
                fired[i] = false
                prevFired[i] = false
                refractory[i] = 0f
                for (k in incomingW[i].indices) {
                    incomingW[i][k] = baseW[i][k]
                    eligibility[i][k] = 0f
                }
            }
            flyX = .24f
            flyY = .55f
            heading = -.15f
            flySpeed = .0035f
            foodX = .76f
            foodY = .35f
            lightX = .72f
            lightY = .72f
            dangerX = .30f
            dangerY = .30f
            simTime = 0f
            neuralAccumulator = 0f
            foodHits = 0
            escapeEvents = 0
            satiety = 0f
            memoryTrace = 0f
            lastReward = 0f
            lastDangerLevel = 0f
            stableLocomotion = 0f
            sensoryDisplay = 0f
            centralDisplay = 0f
            motorDisplay = 0f
            foodSignalDisplay = 0f
            lightSignalDisplay = 0f
            dangerSignalDisplay = 0f
            leftMotor = 0f
            rightMotor = 0f
            forwardMotor = 0f
            escapeMotor = 0f
            brakeMotor = 0f
            exploreMotor = 0f
            foodDrive = 0f
            lightDrive = 0f
            dangerDrive = 0f
            lastNs = System.nanoTime()
            info.text = infoText()
            invalidate()
        }

        private fun addEdge(target: Int, source: Int, weight: Float, l: Array<MutableList<Int>>, ws: Array<MutableList<Float>>) {
            l[target].add(source)
            ws[target].add(weight)
        }

        private fun connectRange(
            targetStart: Int,
            targetEnd: Int,
            sourceStart: Int,
            sourceEnd: Int,
            fanIn: Int,
            base: Float,
            l: Array<MutableList<Int>>,
            ws: Array<MutableList<Float>>,
            salt: Int
        ) {
            val sourceSize = sourceEnd - sourceStart
            for (target in targetStart until targetEnd) {
                repeat(fanIn) { k ->
                    val source = sourceStart + ((target * 37 + k * 101 + salt * 17) % sourceSize)
                    val sign = if (((target + k + salt) and 7) == 0) -1f else 1f
                    val w = sign * (base + ((target + k * 3 + salt) % 5) * base * .12f)
                    addEdge(target, source, w, l, ws)
                }
            }
        }

        private fun buildBrain() {
            if (!loadMeasuredConnectome()) {
                buildFallbackBrain()
            }
        }

        private fun loadMeasuredConnectome(): Boolean {
            val resourceId = resources.getIdentifier("malecns_reduced", "raw", packageName)
            if (resourceId == 0) return false
            return try {
                val bytes = resources.openRawResource(resourceId).use { it.readBytes() }
                val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                val magic = ByteArray(8)
                b.get(magic)
                val magicText = magic.toString(Charsets.US_ASCII).trimEnd('\u0000')
                if (magicText != "FBC95") return false
                val n = b.int
                val e = b.int
                if (n != N || e < 0) return false
                // Node metadata is kept in the binary for provenance/inspection.
                repeat(n) {
                    b.long
                    b.get()
                    b.get()
                    b.get()
                }
                val l = Array(n) { mutableListOf<Int>() }
                val ws = Array(n) { mutableListOf<Float>() }
                repeat(e) {
                    val src = b.int
                    val dst = b.int
                    val weight = b.float
                    if (src in 0 until n && dst in 0 until n && weight.isFinite() && weight != 0f) {
                        l[dst].add(src)
                        ws[dst].add(weight)
                    }
                }
                for (i in 0 until n) {
                    incoming[i] = l[i].toIntArray()
                    incomingW[i] = ws[i].toFloatArray()
                    baseW[i] = incomingW[i].clone()
                    eligibility[i] = FloatArray(incomingW[i].size)
                }
                true
            } catch (_: Exception) {
                false
            }
        }

        // Safety fallback only for local/manual builds where the generated
        // MaleCNS binary is absent. GitHub Actions always generates the measured
        // graph before compiling V0.95.
        private fun buildFallbackBrain() {
            val l = Array(N) { mutableListOf<Int>() }
            val ws = Array(N) { mutableListOf<Float>() }
            for (i in 0 until N) {
                repeat(6) { k ->
                    val src = (i * 1103515245 + k * 12345 + 9517 ushr 3) % N
                    val sign = if ((i + k) % 11 == 0) -1f else 1f
                    addEdge(i, src, sign * (.010f + (k % 4) * .002f), l, ws)
                }
            }
            for (i in 0 until N) {
                incoming[i] = l[i].toIntArray()
                incomingW[i] = ws[i].toFloatArray()
                baseW[i] = incomingW[i].clone()
                eligibility[i] = FloatArray(incomingW[i].size)
            }
        }

        private fun gaussian(d: Float, radius: Float): Float {
            return exp((-(d * d) / (2f * radius * radius)).toDouble()).toFloat().coerceIn(0f, 1f)
        }

        private fun directional(dx: Float, dy: Float, angle: Float, side: Int): Float {
            val a = atan2(dy, dx)
            val e = atan2(sin(a - angle), cos(a - angle))
            return when (side) {
                -1 -> (-e / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                1 -> (e / (Math.PI.toFloat() / 2f)).coerceIn(0f, 1f)
                else -> 1f - (abs(e) / Math.PI.toFloat()).coerceIn(0f, 1f)
            }
        }

        private fun writePopulation(start: Int, values: FloatArray) {
            for (i in values.indices) {
                val idx = start + i
                if (idx < SENSOR_END) v[idx] += values[i]
            }
        }

        private fun encodeStimulus(enabled: Boolean, sx: Float, sy: Float, gain: Float): FloatArray {
            if (!enabled) return FloatArray(8)
            val dx = sx - flyX
            val dy = sy - flyY
            val d = hypot(dx, dy)
            val prox = gaussian(d, .42f)
            val left = directional(dx, dy, heading, -1)
            val right = directional(dx, dy, heading, 1)
            val front = directional(dx, dy, heading, 0)
            return floatArrayOf(
                left * gain,
                right * gain,
                front * gain,
                prox * gain,
                left * prox * gain,
                right * prox * gain,
                front * prox * gain,
                (1f - prox) * gain * .18f
            )
        }

        private fun injectSensoryPopulation(start: Int, end: Int, pattern: FloatArray, gain: Float) {
            val size = end - start
            for (i in 0 until size) {
                val channel = i % pattern.size
                val spatial = .55f + .45f * sin((i * 0.071f) + channel).let { (it + 1f) * .5f }
                v[start + i] += pattern[channel] * gain * spatial
            }
        }

        private fun wallSignalSafe(): Float {
            val wall = min(min(flyX - .055f, .945f - flyX), min(flyY - .10f, .79f - flyY)).coerceIn(0f, .4f)
            return (1f - wall / .4f).coerceIn(0f, 1f)
        }

        private fun sense(dt: Float) {
            val foodPattern = encodeStimulus(foodOn, foodX, foodY, 1.80f * (1f - satiety * .45f))
            val lightPattern = encodeStimulus(lightOn, lightX, lightY, 1.10f)
            val dangerPattern = encodeStimulus(dangerOn, dangerX, dangerY, 1.90f)

            injectSensoryPopulation(VIS_START, VIS_END, lightPattern, 0.26f)
            injectSensoryPopulation(OLF_START, OLF_END, foodPattern, 0.44f)
            injectSensoryPopulation(GUST_START, GUST_END, foodPattern, 0.34f)
            injectSensoryPopulation(MECH_START, MECH_END, dangerPattern, 0.34f)

            // The real MaleCNS also contains sensory neurons in the VNC. Feed
            // body/contact information into that measured sensory population;
            // it then returns through the retained ascending/intrinsic graph.
            val vncFeedback = (abs(flySpeed) / .010f).coerceIn(0f, 1f)
            if (VSENS_START < VSENS_END) {
                for (i in VSENS_START until VSENS_END) {
                    val sideBias = if ((i and 1) == 0) 0.55f else 0.45f
                    v[i] += (vncFeedback * sideBias + wallSignalSafe() * .35f) * .08f
                }
            }

            // Mechanosensory/proprioceptive feedback from locomotion and boundaries.
            val wall = min(min(flyX - .06f, .94f - flyX), min(flyY - .10f, .79f - flyY)).coerceIn(0f, .4f)
            val wallSignal = (1f - wall / .4f).coerceIn(0f, 1f)
            for (i in MECH_START until SENSOR_END) {
                v[i] += wallSignal * .08f
            }

            foodDrive = foodPattern[3].coerceIn(0f, 1f)
            lightDrive = lightPattern[3].coerceIn(0f, 1f)
            dangerDrive = dangerPattern[3].coerceIn(0f, 1f)

            foodSignalDisplay = .90f * foodSignalDisplay + .10f * foodDrive
            lightSignalDisplay = .90f * lightSignalDisplay + .10f * lightDrive
            dangerSignalDisplay = .90f * dangerSignalDisplay + .10f * dangerDrive

            visualDisplayUpdate(foodDrive, lightDrive, dangerDrive)

            for (i in 0 until SENSOR_END) {
                v[i] -= adapt[i]
                adapt[i] *= exp((-dt * 2.0f).toDouble()).toFloat()
            }
        }

        private fun visualDisplayUpdate(food: Float, light: Float, danger: Float) {
            sensoryDisplay = .90f * sensoryDisplay + .10f * ((food + light + danger) / 3f)
        }

        private fun stepBrain(dt: Float) {
            for (i in 0 until N) prevFired[i] = fired[i]

            for (i in 0 until N) {
                if (refractory[i] > 0f) {
                    refractory[i] -= dt
                    fired[i] = false
                    continue
                }

                var syn = 0f
                val src = incoming[i]
                val w = incomingW[i]
                for (k in src.indices) {
                    if (prevFired[src[k]]) syn += w[k]
                }

                // No artificial action-state drive. A very small global leak
                // offset keeps the reduced graph numerically alive without
                // selecting a behavior directly. Stimuli and retained edges
                // determine which neurons reach threshold.
                val tonic = if (i in DESC_START until DESC_END) .0025f else .0008f

                v[i] += ((-.72f - v[i]) * 6.2f - adapt[i]) * dt + syn * 1.10f + tonic * dt * 10f
                fired[i] = v[i] >= -.49f

                if (fired[i]) {
                    v[i] = -.84f
                    adapt[i] = min(.18f, adapt[i] + .026f)
                    refractory[i] = .005f
                }
            }
        }

        private fun count(a: Int, b: Int): Int {
            var n = 0
            for (i in a until b) if (fired[i]) n++
            return n
        }

        private fun populationRate(a: Int, b: Int): Float {
            return count(a, b).toFloat() / (b - a).toFloat()
        }

        private fun learn(reward: Float, dt: Float) {
            val r = reward.coerceIn(-1f, 1f)
            memoryTrace = (memoryTrace * exp((-dt * .035f).toDouble()).toFloat() + abs(r) * .03f).coerceIn(0f, 1f)

            for (target in MOTOR_START until MOTOR_END) {
                val sources = incoming[target]
                val weights = incomingW[target]
                val base = baseW[target]
                val e = eligibility[target]
                for (k in sources.indices) {
                    val pre = if (prevFired[sources[k]]) 1f else 0f
                    val post = if (fired[target]) 1f else 0f
                    e[k] = (e[k] * .995f + pre * post * .08f).coerceIn(-1f, 1f)
                    weights[k] += r * e[k] * dt * .18f
                    val lo = min(base[k] * .55f, base[k] * 1.45f)
                    val hi = max(base[k] * .55f, base[k] * 1.45f)
                    weights[k] = weights[k].coerceIn(lo, hi)
                }
            }
            lastReward = .94f * lastReward + .06f * r
        }

        private fun driveBody(dt: Float) {
            val motorCount = MOTOR_END - MOTOR_START
            if (motorCount <= 0) return

            // The VNC motor readout is purely anatomical: neurons are partitioned
            // by their published side and stable index into six leg-side groups.
            // There is no food->forward or danger->escape shortcut here.
            var left = 0f
            var right = 0f
            var forward = 0f
            var backward = 0f
            var allMotor = 0f
            var nLeft = 0
            var nRight = 0

            for (i in MOTOR_START until MOTOR_END) {
                if (!fired[i]) continue
                allMotor += 1f
                if ((i and 1) == 0) { left += 1f; nLeft++ } else { right += 1f; nRight++ }
                if ((i % 5) <= 2) forward += 1f else backward += 1f
            }
            left = if (nLeft == 0) 0f else left / nLeft
            right = if (nRight == 0) 0f else right / nRight
            forward = (forward / motorCount).coerceIn(0f, 1f)
            backward = (backward / motorCount).coerceIn(0f, 1f)

            val turn = (right - left) * 1.35f
            val cmdSpeed = (forward * .010f - backward * .007f).coerceIn(-.010f, .014f)
            heading += turn * dt * 2.4f
            flySpeed = .88f * flySpeed + .12f * cmdSpeed
            flyX += cos(heading) * flySpeed * dt * 55f
            flyY += sin(heading) * flySpeed * dt * 55f

            if (flyX < .055f || flyX > .945f) {
                heading = Math.PI.toFloat() - heading
                flyX = flyX.coerceIn(.055f, .945f)
            }
            if (flyY < .10f || flyY > .79f) {
                heading = -heading
                flyY = flyY.coerceIn(.10f, .79f)
            }

            var reward = 0f
            val foodDistance = hypot(foodX - flyX, foodY - flyY)
            if (foodOn && foodDistance < .055f) {
                foodHits++
                satiety = min(1f, satiety + .24f)
                reward += 1f
                foodX = .08f + rng.nextFloat() * .84f
                foodY = .14f + rng.nextFloat() * .58f
            }

            satiety *= exp((-dt * .018f).toDouble()).toFloat()

            val danger = if (dangerOn) gaussian(hypot(dangerX - flyX, dangerY - flyY), .36f) else 0f
            if (danger > .68f && lastDangerLevel <= .68f) escapeEvents++
            if (dangerOn && danger < .20f && lastDangerLevel > .68f) reward += .5f
            lastDangerLevel = danger

            learn(reward, dt)

            centralDisplay = .90f * centralDisplay + .10f * (
                (populationRate(DESC_START, DESC_END) +
                    populationRate(ASC_START, ASC_END) +
                    populationRate(OTHER_START, OTHER_END)) / 3f
            )
            motorDisplay = .88f * motorDisplay + .12f * (allMotor / motorCount.toFloat())

            leftMotor = .82f * leftMotor + .18f * left
            rightMotor = .82f * rightMotor + .18f * right
            forwardMotor = .82f * forwardMotor + .18f * forward
            escapeMotor = .82f * escapeMotor + .18f * danger
            brakeMotor = .82f * brakeMotor + .18f * backward
            exploreMotor = .82f * exploreMotor + .18f * (allMotor / motorCount.toFloat())

            stableLocomotion = (.90f * stableLocomotion + .10f * min(1f, abs(flySpeed) / .006f)).coerceIn(0f, 1f)
            info.text = infoText()
        }

        private fun runNeuralSimulation(dt: Float) {
            sense(dt)
            stepBrain(dt)
            driveBody(dt)
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val now = System.nanoTime()
            val raw = (now - lastNs) / 1e9
            val frameDt = min(.030, max(.004, raw)).toFloat()
            lastNs = now
            fps = fps * .94f + (1f / frameDt) * .06f
            simTime += frameDt

            // Neural clock at 50 Hz, independent of display refresh rate.
            neuralAccumulator += frameDt
            var steps = 0
            while (neuralAccumulator >= .020f && steps < 3) {
                runNeuralSimulation(.020f)
                neuralAccumulator -= .020f
                steps++
            }

            drawScene(c)
            drawFly(c, flyX * width, flyY * sceneBottom(), heading)
            drawBrainPanel(c)
            postInvalidateOnAnimation()
        }

        private fun sceneBottom(): Float = height - brainPanelHeight()

        private fun brainPanelHeight(): Float = min(height * .42f, 500.dp().toFloat())

        private fun drawScene(c: Canvas) {
            val bottom = sceneBottom()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = Color.rgb(190, 190, 190)
            c.drawRect(8f, 8f, width - 8f, bottom - 6f, paint)
            paint.style = Paint.Style.FILL

            if (foodOn) {
                val x = foodX * width
                val y = foodY * bottom
                paint.color = Color.rgb(32, 155, 70)
                c.drawCircle(x, y, 22f, paint)
                paint.color = Color.WHITE
                paint.textSize = 16f
                paint.textAlign = Paint.Align.CENTER
                paint.typeface = Typeface.DEFAULT_BOLD
                c.drawText("F", x, y + 6f, paint)
            }

            if (lightOn) {
                val x = lightX * width
                val y = lightY * bottom
                paint.color = Color.rgb(230, 165, 15)
                c.drawCircle(x, y, 38f, paint)
                paint.color = Color.rgb(255, 222, 75)
                c.drawCircle(x, y, 21f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f
                paint.color = Color.argb(130, 235, 180, 20)
                c.drawCircle(x, y, 54f, paint)
                paint.style = Paint.Style.FILL
            }

            if (dangerOn) {
                val x = dangerX * width
                val y = dangerY * bottom
                paint.color = Color.rgb(205, 42, 42)
                c.drawCircle(x, y, 34f, paint)
                paint.color = Color.WHITE
                paint.textSize = 33f
                paint.textAlign = Paint.Align.CENTER
                paint.typeface = Typeface.DEFAULT_BOLD
                c.drawText("!", x, y + 11f, paint)
            }
        }

        private fun drawBrainPanel(c: Canvas) {
            val ph = brainPanelHeight()
            val top = height - ph
            paint.color = Color.rgb(20, 25, 28)
            paint.style = Paint.Style.FILL
            c.drawRoundRect(8f, top, width - 8f, height.toFloat(), 12f, 12f, paint)
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = Color.WHITE
            paint.textSize = 16f
            c.drawText("CEREBRO · MaleCNS REDUCIDO · ACTIVIDAD", 20f, top + 23f, paint)
            bar(c, "SENSORIAL", sensoryDisplay, top + 30f, Color.rgb(52, 195, 110))
            bar(c, "CENTRAL", centralDisplay, top + 55f, Color.rgb(80, 145, 225))
            bar(c, "MOTOR / VNC", motorDisplay, top + 80f, Color.rgb(225, 160, 45))
            paint.color = Color.rgb(215, 220, 222)
            paint.textSize = 9f
            paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("ESTÍMULOS", 20f, top + 106f, paint)
            mini(c, "COMIDA", foodSignalDisplay, 20f, top + 111f, 0)
            mini(c, "LUZ", lightSignalDisplay, 160f, top + 111f, 1)
            mini(c, "PELIGRO", dangerSignalDisplay, 300f, top + 111f, 2)

            val mapTop = top + 142f
            val mapBottom = height - 24f
            drawBrainMap(c, 14f, mapTop, width - 28f, max(110f, mapBottom - mapTop))
            paint.color = Color.rgb(205, 210, 212)
            paint.textSize = 8f
            paint.typeface = Typeface.DEFAULT
            c.drawText("MaleCNS v1.0 · 16.669 neuronas · conectividad publicada reducida", 20f, height - 7f, paint)
        }

        private fun bar(c: Canvas, label: String, value: Float, y: Float, accent: Int) {
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = Color.WHITE
            paint.textSize = 10f
            c.drawText(label, 20f, y + 14f, paint)
            val left = 116f
            val right = width - 55f
            paint.color = Color.rgb(62, 67, 70)
            c.drawRoundRect(left, y, right, y + 18f, 7f, 7f, paint)
            paint.color = accent
            c.drawRoundRect(left, y, left + (right - left) * value.coerceIn(0f, 1f), y + 18f, 7f, 7f, paint)
            paint.color = Color.WHITE
            paint.textSize = 10f
            c.drawText("${(value * 100).toInt()}%", right + 5f, y + 14f, paint)
        }

        private fun mini(c: Canvas, label: String, value: Float, x: Float, y: Float, kind: Int) {
            val w = (width - 52f) / 3f
            paint.color = Color.rgb(53, 58, 61)
            c.drawRoundRect(x, y, x + w, y + 21f, 6f, 6f, paint)
            paint.color = when (kind) {
                0 -> Color.rgb(52, 175, 85)
                1 -> Color.rgb(238, 178, 25)
                else -> Color.rgb(215, 55, 55)
            }
            c.drawRoundRect(x + 2f, y + 2f, x + 2f + (w - 4f) * value.coerceIn(0f, 1f), y + 19f, 5f, 5f, paint)
            paint.color = Color.WHITE
            paint.textSize = 9f
            paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("$label ${(value * 100).toInt()}%", x + 7f, y + 14f, paint)
        }

        private fun drawBrainMap(c: Canvas, x: Float, y: Float, w: Float, h: Float) {
            paint.color = Color.rgb(28, 33, 37)
            paint.style = Paint.Style.FILL
            c.drawRoundRect(x, y, x + w, y + h, 14f, 14f, paint)

            val cx = x + w * .5f
            val cy = y + h * .52f
            val left = x + w * .22f
            val right = x + w * .78f

            paint.color = Color.rgb(55, 62, 68)
            c.drawOval(left - w * .15f, cy - h * .30f, left + w * .08f, cy + h * .30f, paint)
            c.drawOval(right - w * .08f, cy - h * .30f, right + w * .15f, cy + h * .30f, paint)
            paint.color = Color.rgb(67, 73, 79)
            c.drawOval(cx - w * .23f, cy - h * .27f, cx + w * .23f, cy + h * .27f, paint)

            val hubs = arrayOf(
                floatArrayOf(left, cy),
                floatArrayOf(right, cy),
                floatArrayOf(cx - w * .13f, cy - h * .10f),
                floatArrayOf(cx + w * .13f, cy - h * .10f),
                floatArrayOf(cx, cy + h * .04f),
                floatArrayOf(cx, cy + h * .22f),
                floatArrayOf(cx, cy + h * .36f)
            )

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            paint.color = Color.argb(75, 160, 170, 178)
            for (i in hubs.indices) {
                for (j in i + 1 until hubs.size) {
                    if ((i * 3 + j) % 3 != 0) {
                        c.drawLine(hubs[i][0], hubs[i][1], hubs[j][0], hubs[j][1], paint)
                    }
                }
            }

            // 300 visible representative nodes: the simulation contains 16,669
            // neurons, but drawing every node would make the activity map unreadable.
            val nodeN = 300
            val nx = FloatArray(nodeN)
            val ny = FloatArray(nodeN)
            for (i in 0 until nodeN) {
                val q = i / 10
                val side = if (i % 2 == 0) -1f else 1f
                val px = when {
                    i < 70 -> cx + side * w * (.12f + .13f * ((q % 12) / 11f))
                    i < 150 -> cx + side * w * (.04f + .08f * ((q % 10) / 9f))
                    else -> cx + sin(i * .73f) * w * .20f
                }
                val py = when {
                    i < 70 -> cy + sin(i * .41f) * h * .25f
                    i < 150 -> cy + cos(i * .29f) * h * .20f
                    else -> cy + sin(i * .37f) * h * .30f
                }
                nx[i] = px.coerceIn(x + 10f, x + w - 10f)
                ny[i] = py.coerceIn(y + 10f, y + h - 10f)
            }

            paint.strokeWidth = .65f
            for (i in 0 until nodeN step 2) {
                val j = (i * 47 + 17) % nodeN
                paint.color = Color.argb(45, 145, 155, 162)
                c.drawLine(nx[i], ny[i], nx[j], ny[j], paint)
            }

            for (i in 0 until nodeN) {
                val idx = when {
                    i < 55 -> VIS_START + (i * 11) % (VIS_END - VIS_START)
                    i < 85 -> OLF_START + (i * 7) % (OLF_END - OLF_START)
                    i < 110 -> GUST_START + (i * 5) % (GUST_END - GUST_START)
                    i < 150 -> OTHER_START + (i * 13) % maxOf(1, OTHER_END - OTHER_START)
                    i < 210 -> OTHER_START + (i * 31) % maxOf(1, OTHER_END - OTHER_START)
                    else -> MOTOR_START + (i * 3) % (MOTOR_END - MOTOR_START)
                }
                val active = fired[idx]
                val membrane = ((v[idx] + .72f) / .75f).coerceIn(0f, 1f)
                if (active) {
                    paint.style = Paint.Style.FILL
                    paint.color = Color.argb(75, 70, 220, 145)
                    c.drawCircle(nx[i], ny[i], 7f, paint)
                }
                paint.style = Paint.Style.FILL
                paint.color = if (active) {
                    Color.rgb(255, 226, 65)
                } else {
                    Color.rgb(
                        (60 + membrane * 85).toInt(),
                        (65 + membrane * 75).toInt(),
                        (72 + membrane * 70).toInt()
                    )
                }
                c.drawCircle(nx[i], ny[i], if (active) 2.8f else 1.8f, paint)
            }

            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(210, 215, 218)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 8f
            paint.typeface = Typeface.DEFAULT_BOLD
            c.drawText("ÓPTICO", left, y + h - 6f, paint)
            c.drawText("ÓPTICO", right, y + h - 6f, paint)
            c.drawText("CENTRAL / MB / CX", cx, y + 12f, paint)
            c.drawText("VNC · MOTOR", cx, y + h - 6f, paint)
            paint.textAlign = Paint.Align.LEFT
        }

        private fun drawFly(c: Canvas, px: Float, py: Float, angle: Float) {
            c.save()
            c.rotate(Math.toDegrees(angle.toDouble()).toFloat() + 90f, px, py)

            val s = (min(width.toFloat(), sceneBottom()) / 520f).coerceIn(1.05f, 1.45f)
            c.scale(s, s, px, py)

            // Soft shadow under the body.
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(38, 0, 0, 0)
            c.drawOval(px - 30f, py + 56f, px + 30f, py + 68f, paint)

            // Six articulated legs, arranged in the characteristic drosophila pattern.
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = 3.1f
            paint.color = Color.rgb(42, 35, 33)
            val legY = floatArrayOf(-24f, 0f, 24f)
            for ((q, yy) in legY.withIndex()) {
                val spread = when (q) { 0 -> 32f; 1 -> 38f; else -> 34f }
                val kneeY = yy + when (q) { 0 -> -16f; 1 -> 0f; else -> 16f }
                c.drawLine(px - 11f, py + yy, px - spread, py + kneeY, paint)
                c.drawLine(px - spread, py + kneeY, px - spread - 22f, py + kneeY + when (q) { 0 -> -4f; 1 -> 4f; else -> 8f }, paint)
                c.drawLine(px + 11f, py + yy, px + spread, py + kneeY, paint)
                c.drawLine(px + spread, py + kneeY, px + spread + 22f, py + kneeY + when (q) { 0 -> -4f; 1 -> 4f; else -> 8f }, paint)
            }

            // Broad translucent wings with simple longitudinal veins.
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(78, 175, 205, 220)
            val wingL = android.graphics.Path().apply {
                moveTo(px - 7f, py - 18f)
                cubicTo(px - 46f, py - 72f, px - 105f, py - 92f, px - 122f, py - 58f)
                cubicTo(px - 132f, py - 35f, px - 82f, py - 8f, px - 13f, py - 2f)
                close()
            }
            val wingR = android.graphics.Path().apply {
                moveTo(px + 7f, py - 18f)
                cubicTo(px + 46f, py - 72f, px + 105f, py - 92f, px + 122f, py - 58f)
                cubicTo(px + 132f, py - 35f, px + 82f, py - 8f, px + 13f, py - 2f)
                close()
            }
            c.drawPath(wingL, paint)
            c.drawPath(wingR, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.1f
            paint.color = Color.argb(150, 105, 135, 150)
            for (side in intArrayOf(-1, 1)) {
                c.drawLine(px + side * 15f, py - 20f, px + side * 102f, py - 58f, paint)
                c.drawLine(px + side * 20f, py - 20f, px + side * 80f, py - 72f, paint)
                c.drawLine(px + side * 32f, py - 18f, px + side * 112f, py - 42f, paint)
            }

            // Segmented abdomen, broad and tapered like the reference image.
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(48, 43, 42)
            c.drawOval(px - 25f, py + 8f, px + 25f, py + 112f, paint)
            val abdomen = arrayOf(
                floatArrayOf(15f, 42f), floatArrayOf(42f, 62f), floatArrayOf(62f, 81f),
                floatArrayOf(81f, 98f), floatArrayOf(98f, 112f)
            )
            for ((i, seg) in abdomen.withIndex()) {
                paint.color = if (i % 2 == 0) Color.rgb(92, 70, 56) else Color.rgb(55, 49, 47)
                c.drawRoundRect(px - 22f, py + seg[0], px + 22f, py + seg[1], 7f, 7f, paint)
            }

            // Thorax with darker dorsal plates.
            paint.color = Color.rgb(59, 53, 51)
            c.drawOval(px - 31f, py - 36f, px + 31f, py + 28f, paint)
            paint.color = Color.rgb(70, 63, 59)
            c.drawOval(px - 27f, py - 30f, px + 27f, py + 7f, paint)

            // Head and two large red compound eyes.
            paint.color = Color.rgb(50, 45, 44)
            c.drawOval(px - 26f, py - 72f, px + 26f, py - 29f, paint)
            paint.color = Color.rgb(150, 39, 34)
            c.drawOval(px - 43f, py - 70f, px - 8f, py - 38f, paint)
            c.drawOval(px + 8f, py - 70f, px + 43f, py - 38f, paint)
            paint.color = Color.rgb(226, 92, 66)
            c.drawOval(px - 35f, py - 63f, px - 18f, py - 48f, paint)
            c.drawOval(px + 18f, py - 63f, px + 35f, py - 48f, paint)

            // Antennae and aristae.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.8f
            paint.color = Color.rgb(43, 36, 34)
            c.drawLine(px - 11f, py - 69f, px - 29f, py - 94f, paint)
            c.drawLine(px + 11f, py - 69f, px + 29f, py - 94f, paint)
            c.drawLine(px - 29f, py - 94f, px - 41f, py - 105f, paint)
            c.drawLine(px + 29f, py - 94f, px + 41f, py - 105f, paint)
            paint.style = Paint.Style.FILL
            c.drawCircle(px - 42f, py - 106f, 2.2f, paint)
            c.drawCircle(px + 42f, py - 106f, 2.2f, paint)

            // Small haltere hints behind the thorax.
            paint.color = Color.rgb(72, 62, 57)
            c.drawCircle(px - 39f, py + 5f, 5f, paint)
            c.drawCircle(px + 39f, py + 5f, 5f, paint)
            c.restore()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    if (e.y < sceneBottom()) {
                        moveStimulus(e.x / width.toFloat(), e.y / sceneBottom())
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }

        private fun moveStimulus(xr: Float, yr: Float) {
            val x = xr.coerceIn(.06f, .94f)
            val y = yr.coerceIn(.10f, .82f)
            when (selectedStimulus) {
                0 -> { foodX = x; foodY = y }
                1 -> { lightX = x; lightY = y }
                else -> { dangerX = x; dangerY = y }
            }
        }
    }
}
