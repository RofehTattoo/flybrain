# FlyBrain V0.95 — connectome-driven reduction

FlyBrain V0.95 changes the project goal from a hand-designed behavioural controller to a **connectome-derived neural model**.

## What is new

- Exactly **16,669 simulated neurons**.
- Build-time extraction from **MaleCNS v1.0** public annotation and weighted-connectivity tables.
- The 16,669 neurons are selected deterministically from published superclasses, using total weighted connectivity to retain highly connected cells within each superclass.
- Only directed neuron-to-neuron edges that exist in the published MaleCNS graph are embedded. No synthetic action-state edges are added to the measured graph.
- Neurotransmitter predictions are used for the current sign model: acetylcholine positive, GABA/glutamate negative; unresolved/modulatory transmitter edges are not given direct current.
- Sensory input is injected into anatomical visual, olfactory, gustatory and mechanosensory/proprioceptive blocks.
- VNC sensory activity receives body/proprioceptive feedback.
- Motor output is read from the retained `vnc_motor` population rather than from a hand-written APPROACH/ESCAPE/EXPLORE state machine.
- Food reward changes internal satiety/learning but does not directly command forward movement.
- The 2D fly remains based on the V0.94 visual design.

## Scientific scope

This is **not yet a literal whole-CNS simulation**. It is a 16,669-neuron, connectome-derived reduction of MaleCNS v1.0. The reduction is stratified by published superclass and connectivity, so it is not a random 10% sample. Physiological parameters, sensory encoding, body mechanics and the interpretation of motor-neuron activity remain modelling assumptions.

MaleCNS v1.0 contains 166,691 neurons spanning the brain and ventral nerve cord, with a connectome graph containing about 25.6 million directed edges. The public dataset provides neuron annotations, neurotransmitter predictions and weighted connectivity. The official download page documents the bulk data used by this build.

Sources:
- https://male-cns.janelia.org/
- https://male-cns.janelia.org/download/
- Berg et al., Cell (2026), DOI 10.1016/j.cell.2026.08.015

MaleCNS is released under CC-BY.

## Build note

The GitHub Actions workflow downloads the official public MaleCNS v1.0 bulk tables during the build and creates the compact `malecns_reduced.bin` resource before Gradle compiles the APK. This deliberately makes the scientific data preparation reproducible instead of shipping a hand-written substitute graph.
